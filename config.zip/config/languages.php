<?php
/**
 * Created by PhpStorm.
 * User: lola
 * Date: 11/18/2017
 * Time: 7:06 PM
 */
return [
    'en' => 'En',
    'ar' => 'ع',
];