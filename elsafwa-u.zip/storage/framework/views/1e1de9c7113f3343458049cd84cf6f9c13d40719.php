<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>
</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<!--Body-->
<div class="container-fluid">


    <!--Content area-->
    <div class="ads-area row mar-top">

        <div class="col-xs-12 cus-12">
            <div class="area">

                <div class="trading-area">
                    <div class="trading-boxes">

                        <div class="container cus-width">
                            <div class="row regestration">
                                <div class="col-xs-12 cus-12">
                                    <h2>
                                        <?php echo e(__('strings.update')); ?>

                                    </h2>

                                    <p>
                                        <?php echo e(__('strings.register-brief')); ?>

                                    </p>
                                </div>

                                <div class="col-xs-12 cus-12">

                                    <?php if(count($errors) > 0): ?>
                                        <div class="alert alert-danger">
                                            <strong>Whoops!</strong> There is a problem with Your input:
                                            <br><br>
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>

                                    <form method="post" action="<?php echo e(url('/user/'.$user->id)); ?>" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('PUT')); ?>

                                        <div class="container-fluid">
                                            <div class="row">

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label ><?php echo e(__('strings.user-name')); ?> *</label>
                                                        <input type="text" class="form-control"  placeholder="Enter User Name" name="UserName" value="<?php echo e($user->user_name); ?>">
                                                    </div>
                                                </div>


                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label ><?php echo e(__('strings.register-name')); ?> </label>
                                                        <input type="text" class="form-control"  placeholder="Enter Full Name" name="fullName" value="<?php echo e($user->name); ?>">
                                                    </div>
                                                </div>


                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label ><?php echo e(__('strings.password')); ?> *</label>
                                                        <input type="password" class="form-control"  placeholder="********" name="password">
                                                    </div>
                                                </div>

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label ><?php echo e(__('strings.retype-password')); ?> *</label>
                                                        <input type="password" class="form-control"  placeholder="********" name="rewrite_password">
                                                    </div>
                                                </div>

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('strings.email')); ?> *</label>
                                                        <input type="email" class="form-control"  placeholder="Your Email" name="email" value="<?php echo e($user->email); ?>">
                                                    </div>
                                                </div>

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('strings.gender')); ?></label>
                                                        <div class="materialSelect inline empty ">
                                                            <ul class="select">
                                                                <input type="hidden" name="gender"  value="<?php echo e($user->gender); ?>">
                                                                <?php if($user->gender == 0): ?>
                                                                    <li data-value="0" value="0" data-selected="true"><?php echo e(__('strings.male')); ?></li>
                                                                    <li data-value="1" value="1"><?php echo e(__('strings.female')); ?></li>
                                                                <?php else: ?>
                                                                    <li data-value="0" value="0"><?php echo e(__('strings.male')); ?></li>
                                                                    <li data-value="1" value="1" data-selected="true"><?php echo e(__('strings.female')); ?></li>
                                                                <?php endif; ?>
                                                                <li data-selected="true"><?php echo e(__('strings.gender')); ?></li>
                                                            </ul>
                                                            <div class="message">Please select something</div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('strings.dob')); ?></label>
                                                        <input type="text" class="form-control"  placeholder="<?php echo e(__('strings.dob')); ?>" id='datetimepicker' name="dob" value="<?php echo e($user->birth_date); ?>">
                                                    </div>
                                                </div>

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('strings.City')); ?></label>
                                                        <div class="materialSelect inline empty ">
                                                            <ul class="select">
                                                                <input type="hidden" name="city" value="<?php echo e($user->city); ?>">
                                                                <?php if($user->city > 0): ?>
                                                                    <?php $__currentLoopData = $citys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($user->city == $city->id ): ?>
                                                                            <li data-value="0" value="<?php echo e($city->id); ?>" data-selected="true"><?php echo e($city->name); ?></li>
                                                                        <?php else: ?>
                                                                            <li data-value="0" value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></li>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php else: ?>
                                                                    <li data-selected="true"><?php echo e(__('strings.chose-city')); ?></li>
                                                                    <?php $__currentLoopData = $citys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <li data-value="0" value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            </ul>
                                                            <div class="message">Please select something</div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('strings.Phone')); ?></label>
                                                        <input type="text" class="form-control"  placeholder="<?php echo e(__('strings.Phone')); ?>" name="phone" onkeypress="return allowNumbers(event)" maxlength="11" value="<?php echo e($user->phone); ?>" >
                                                    </div>

                                                    <div class="form-group">
                                                        <label><?php echo e(__('strings.profile-pic')); ?></label>
                                                        <div class="uploader-contain">
                                                            <span style="color: #999999;">
                                                               

                                                                <?php echo e(__('strings.profile-pic')); ?></span>
                                                            <input type="file" name="file" class="upload-hid"  onchange="readURL(this);" value="<?php echo e($user->img_url); ?>"/>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <img id="profile-img" src="<?php echo e(url('uploads/'.$user->img_url)); ?>" alt="" style="width:180px;height: 180px;border: 1px dashed #0080c4"/>

                                                    </div>
                                                </div>

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('strings.description')); ?></label>
                                                        <textarea placeholder="<?php echo e(__('strings.description')); ?>" name="desc" rows="5"><?php echo e($user->description); ?>

                                                        </textarea>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="row text-center reg">
                                                <button class="btn btn-default add-stuff" type="submit">
                                                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

                                                    <span>
                                        <?php echo e(__('strings.update')); ?>

                                    </span>

                                                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
                                                </button>
                                            </div>
                                        </div>
                                    </form>


                                </div>

                            </div>




                        </div>


                    </div>
                </div>

            </div>
        </div>

    </div>



</div>
<!--Body-->




<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>

