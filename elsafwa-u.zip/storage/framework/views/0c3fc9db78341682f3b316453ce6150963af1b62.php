<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
    </script>

    <script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>

</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<div class="container-fluid">
    <div class="row add-cyber">

        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were problems with input:
                <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


            <form class="cyber_form" method="post" action="<?php echo e(url('update_pass')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="user" value="<?php echo e($user); ?>">
            <div class="col-xs-12 cus-12">
                <div class="form-group">
                    <label for="name">Type New Password *</label>
                    <input type="password" class="form-control"  placeholder="type new password" name="password" style="width: 100%!important;">
                </div>
            </div>

            <div class="col-xs-12 cus-12">
                <div class="form-group">
                    <label for="Phone">ReType New Password *</label>
                    <input type="password" class="form-control"  placeholder="type new password" name="rewrite_password" style="width: 100%!important;">                </div>
            </div>



            <div class="text-center reg" style="width: 30%!important;margin:auto">
                <button class="btn btn-default add-stuff" type="submit" style="margin: 20px auto">
                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

                    <span>
                                        Submit
                                    </span>

                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
                </button>
            </div>
        </form>
    </div>
</div>



<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>
