<?php $__env->startSection('lay_out'); ?>

    <div class="blog_details">
        <div class="container">

            <div class="row">
                <div class="col-xs-12">
                    <h2>
                       <?php echo e($blog->name); ?> :
                    </h2>
                </div>
            </div>

            <div class="articles">
                <h3 class="text-center">
                    المقالات
                </h3>

                <?php if(count($blog->blog_article)>0): ?>
                    <div class="row">

                        <?php $__currentLoopData = $blog->blog_article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 col-sm-6 col-xs-12 btm-margin">
                                <div>
                                    <img src="<?php echo e(url('front/images/article-icon.jpg')); ?>" class="img-responsive">

                                    <div class="content text-center">
                                        <h5 class="text-center">
                                            <?php echo e($article->name); ?>

                                        </h5>
                                        <p class="text-center">
                                            <?php echo html_entity_decode($article->description); ?>

                                        </p>
                                        <a href="<?php echo e(url('blog_articles/'.$article->id)); ?>">
                                            التفاصيل
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                <?php endif; ?>


            </div>


        </div>



    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>