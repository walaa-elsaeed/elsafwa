<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
</script>


<script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>

<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 6%">
        <div class="col-md-offset-1 col-md-10 col-xs-12">
            <div class="box box-primary">

                <div class="box-header with-border">
                    <h3 class="box-title">
                        Add Cyber
                    </h3>
                </div>

                <form method="post" action="<?php echo e(url('storejoined')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                        <div class="form-group">
                            <label for="text">Select Tournament *</label>
                            <div class="materialSelect inline empty ">
                                <ul class="select">
                                    <input type="hidden" name="tourn">
                                    <li data-selected="true">Select Tourn</li>
                                    <?php $__currentLoopData = $tourns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tourn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li data-value="0" value="<?php echo e($tourn->id); ?>"><?php echo e($tourn->name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                                <div class="message">Please select something</div>
                            </div>
                        </div>

                        <div class="form-group">
                            <select class="form-control select2" style="width: 100%;" name="cyber">
                                <option selected disabled>Select Cyber</option>
                                <?php $__currentLoopData = $tourn_cybers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tourn_cyber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tourn_cyber->id); ?>">
                                        <?php echo e($tourn_cyber->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="name">User Name *</label>
                            <input type="text" class="form-control" id="name" placeholder="User Name" name="user_name"
                                   style="width: 100%">
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-xs-12 cus-12">
                                <div class="form-group">
                                    <label for="name">Password *</label>
                                    <input type="password" class="form-control" id="name" placeholder="Password" name="Password"
                                           style="width: 100%">
                                </div>
                            </div>

                            <div class="col-md-6 col-xs-12 cus-12">
                                <div class="form-group">
                                    <label for="name">Retype Password *</label>
                                    <input type="password" class="form-control" id="name" placeholder="Retype Password" name="retype_Password"
                                           style="width: 100%">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="box-footer">
                        <div class="col-xs-12">
                            <button class="btn btn-primary " type="submit">
                                        <span>
                                                Join
                                            </span>
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>