<p>
    Your Cyber Is Decline Due To,<br>
    <?php echo e($decline_reason); ?>

</p>