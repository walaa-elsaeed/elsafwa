<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
</script>


<script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>

<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 6%">
        <div class="col-md-offset-1 col-md-10 col-xs-12">
            <div class="box box-primary">

                <div class="box-header with-border">
                    <h3 class="box-title">
                        Add Account
                    </h3>
                </div>

                <form method="post" action="<?php echo e('account'); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>


                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were problems with input:
                            <br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>


                    <div class="box-body">

                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label ><?php echo e(__('strings.user-name')); ?> *</label>
                                <input type="text" class="form-control"  placeholder="<?php echo e(__('strings.user-name')); ?>" name="UserName" value="<?php echo e(old('UserName')); ?>" required>
                            </div>
                        </div>


                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label ><?php echo e(__('strings.register-name')); ?> </label>
                                <input type="text" class="form-control"  placeholder="<?php echo e(__('strings.register-name')); ?>" name="fullName" value="<?php echo e(old('fullName')); ?>">
                            </div>
                        </div>



                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label ><?php echo e(__('strings.password')); ?> *</label>
                                <input type="password" class="form-control"  placeholder="<?php echo e(__('strings.password')); ?>" name="password" required>
                            </div>
                        </div>

                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label ><?php echo e(__('strings.retype-password')); ?>*</label>
                                <input type="password" class="form-control"  placeholder="<?php echo e(__('strings.retype-password')); ?>" name="rewrite_password" required>
                            </div>
                        </div>

                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label><?php echo e(__('strings.email')); ?> *</label>
                                <input type="email" class="form-control"  placeholder="<?php echo e(__('strings.email')); ?>" name="email" value="<?php echo e(old('mail')); ?>" required>
                            </div>
                        </div>

                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label>Account Type *</label>
                                <div class="materialSelect inline empty ">
                                    <ul class="select">
                                        <input type="hidden" name="type"  required>
                                        <li data-selected="true">Choose Type</li>
                                        <li data-value="1" value="1">Admin</li>
                                        <li data-value="2" value="2">Cyber Admin</li>
                                        <li data-value="3" value="3">Trade Admin</li>
                                    </ul>
                                    <div class="message">Please select something</div>
                                </div>
                            </div>
                        </div>


                    </div>

                    <div class="box-footer">
                        <div class="col-xs-12">
                            <button class="btn btn-primary " type="submit">
                                        <span>
                                                Submit
                                            </span>
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>