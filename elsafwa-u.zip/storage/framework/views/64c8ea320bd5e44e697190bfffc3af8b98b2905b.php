<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
</script>

<script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>
<script>
    var deletedIds = [];
    function deleteImage(imageId)
    {
        //var fd = new FormData(document.getElementById("updateCyber"));
        //fd.append('deletedImages[]',imageId);
        deletedIds.push(imageId);
        var oldValue = $('#deletedImages').val();
        $('#deletedImages').attr("value",deletedIds.join(', '));
        $('#'+imageId).remove();
    }
</script>


<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 2%">
        <div class="col-md-offset-1 col-md-10 col-xs-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">
                        Edit <?php echo e($trade->name); ?>

                    </h3>
                </div>

                <form id="updateCyber"  method="post" action="<?php echo e(url('/trade/'.$trade->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="box-body">
                        <div class="form-group">
                            <?php if($trade->status == 1): ?>

                            <?php elseif($trade->status == 0): ?>

                                <div class="col-md-6 col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="name" style="display: inline">Approve</label>
                                        <div class="checkbox" style="display: inline">
                                            <label>
                                                <input type="checkbox" name="approve">
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6 col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="name" style="display: inline">Decline</label>
                                        <div class="checkbox" style="display: inline">
                                            <label>
                                                <input type="checkbox" name="decline">
                                            </label>
                                            <textarea name="decline_reason" style="display: block;height: 150px!important;width: 100%"></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="name" style="display: inline">Approve</label>
                                        <div class="checkbox" style="display: inline">
                                            <label>
                                                <input type="checkbox" name="approve">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab_1" data-toggle="tab" aria-expanded="true">
                                        EN
                                    </a>
                                </li>
                                <li>
                                    <a href="#tab_2" data-toggle="tab" aria-expanded="false">
                                        ع
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">

                            <div class="tab-pane active" id="tab_1">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" class="form-control" id="name" placeholder="Place Name" name="name" value="<?php echo e($trade->translate('en')->name); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="tab_2">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group form-ar">
                                        <label for="name">الاسم *</label>
                                        <input type="text" class="form-control" id="name" placeholder="الاسم" name="name_ar" value="<?php echo e($trade->translateOrDefault('ar')->name); ?>" style="width: 100%">
                                    </div>
                                </div>
                            </div>

                        </div>


                        <div class="clearfix"></div>


                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label for="government">City</label>
                                <div class="materialSelect inline empty ">
                                    <ul class="select">
                                        <input type="hidden" name="government" id="government" value="<?php echo e($trade->city_id); ?>">
                                        <?php if($trade->city_id > 0): ?>
                                            <?php $__currentLoopData = $allzones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($trade->city_id == $zone->id ): ?>
                                                    <li data-value="0" value="<?php echo e($zone->id); ?>" data-selected="true"><?php echo e($zone->name); ?></li>
                                                <?php else: ?>
                                                    <li data-value="0" value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <li data-selected="true">Choose Your City</li>

                                            <?php $__currentLoopData = $allzones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li data-value="0" value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>


                                    </ul>
                                    <div class="message">Please select something</div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label for="government">Zone</label>
                                <div class="materialSelect inline empty ">
                                    <ul class="select" id="city">
                                        <input type="hidden" name="zone" value="<?php echo e($trade->zone_id); ?>">
                                        <a id="t" name="_token" value="<?php echo e(csrf_token()); ?>" style="display: none"></a>
                                        <a id="u"  value="<?php echo e(url("cityCyber")); ?>" style="display: none"></a>
                                        <?php $__currentLoopData = $allcitys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($trade->zone_id == $city->id): ?>
                                                <li data-selected="true"><?php echo e($city->name); ?></li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </ul>
                                    <div class="message">Please select something</div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label>Category  *</label>
                                <div class="materialSelect inline empty ">
                                    <ul class="select">
                                        <input type="hidden" name="category" id="Category" value="<?php echo e($trade->category_id); ?>">
                                        <?php if($trade->category_id > 0): ?>
                                            <?php $__currentLoopData = $alldevices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($trade->category_id == $device->id): ?>
                                                    <li data-value="0" value="<?php echo e($device->id); ?>" data-selected="true"><?php echo e($device->name); ?></li>
                                                <?php else: ?>
                                                    <li data-value="0" value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <li data-selected="true">Select Category</li>
                                        <?php endif; ?>

                                    </ul>
                                    <div class="message">Please select something</div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label class="select-ope">Operation  *</label>
                                <div class="materialSelect inline empty ">
                                    <ul class="select">
                                        <input type="hidden" name="operation" id="operation" value="<?php echo e($trade->operation_id); ?>">
                                        <?php if($trade->operation_id > 0): ?>
                                            <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($trade->operation_id == $operation->id): ?>
                                                    <li data-value="0" value="<?php echo e($operation->id); ?>" data-selected="true"><?php echo e($operation->name); ?></li>
                                                <?php else: ?>
                                                    <li data-value="0" value="<?php echo e($operation->id); ?>"><?php echo e($operation->name); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <li data-selected="true">Select operation</li>
                                        <?php endif; ?>
                                    </ul>
                                    <div class="message">Please select something</div>
                                </div>
                            </div>
                        </div>


                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab_5" data-toggle="tab" aria-expanded="true">
                                        EN
                                    </a>
                                </li>
                                <li>
                                    <a href="#tab_6" data-toggle="tab" aria-expanded="false">
                                        ع
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">

                            <div class="tab-pane active" id="tab_5">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control" id="description" placeholder="Description" name="desc" rows="5"><?php echo e($trade->translate('en')->description); ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane" id="tab_6">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group form-ar">
                                        <label for="name">الوصف *</label>
                                        <textarea type="text" class="form-control" id="description" placeholder="الوصف" name="desc_ar" rows="5"><?php echo e($trade->translateOrDefault('ar')->description); ?></textarea>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="clearfix"></div>


                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label for="name">Price</label>
                                <input type="text" class="form-control" id="name" placeholder="Price" name="price" value="<?php echo e($trade->price); ?>">
                            </div>
                        </div>

                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group reli">
                                <label for="image">Upload </label>
                                <input type="file" id="gallery-photo-add" class="upload-hidden" name="images[]" multiple accept="jpg, gif, png" value="<?php echo e(url('uploads/')); ?>.1508533048aqar-test.png"/>
                                <button class="btn btn-default upload">
                                    upload
                                </button>

                                <input type="hidden" name="deletedImages[]" id="deletedImages" />

                                <div class="gallery">
                                    <?php $__currentLoopData = $trade->tradeImg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div style="position: relative;display: inline-block" id="<?php echo e($image->id); ?>">
                                            <img src="<?php echo e(url('uploads/' . $image->img_url)); ?>" style="width: 100px;height: 100px">
                                            <button type="button" class="delete-btn" value="<?php echo e($image->id); ?>" onclick="deleteImage(this.value)" style="position: absolute;top: 0;right: 0;z-index: 99999">
                                                X
                                            </button>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>



                    </div>




                    <div class="box-footer">
                        <div class="col-xs-12">
                            <button class="btn btn-primary " type="submit">
                                        <span>
                                                Submit
                                            </span>
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>