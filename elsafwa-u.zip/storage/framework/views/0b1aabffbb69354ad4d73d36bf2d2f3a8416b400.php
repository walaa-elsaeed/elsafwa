<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
</script>


<script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>

<?php $__env->startSection('content'); ?>
    <div class="row add-cyber" style="background: #192231;margin-top: 0;padding-top: 10%;padding-bottom: 4%;height: 100%">

        <form class="cyber_form" method="post" action="<?php echo e('storecity'); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                    <label for="government">City *</label>
                    <div class="materialSelect inline empty ">
                        <ul class="select">
                            <input type="hidden" name="government" id="government">
                            <li data-selected="true">Choose Your City </li>

                            <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li data-value="0" value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                        <div class="message">Please select something</div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                    <label for="name">Name *</label>
                    <input type="text" class="form-control" id="name" placeholder="Name" name="city"  style="width: 100%">
                </div>
            </div>

            <div class="col-xs-12 text-center reg" style="margin-top: 20px; margin-bottom: 20px">
                <button class="btn btn-default add-stuff" type="submit" style="width: 30%">
                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

                    <span>
                                        Submit
                                    </span>

                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
                </button>
            </div>
        </form>

    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>