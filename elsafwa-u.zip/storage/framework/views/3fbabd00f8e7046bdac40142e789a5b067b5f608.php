<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
</script>

<script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>
<script>
    var deletedIds = [];
    function deleteImage(imageId)
    {
        //var fd = new FormData(document.getElementById("updateCyber"));
        //fd.append('deletedImages[]',imageId);
        deletedIds.push(imageId);
        var oldValue = $('#deletedImages').val();
        $('#deletedImages').attr("value",deletedIds.join(', '));
        $('#'+imageId).remove();
    }
</script>


<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 2%">
        <div class="col-md-offset-1 col-md-10 col-xs-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">
                        Edit <?php echo e($cyber->name); ?>

                    </h3>
                </div>

                <form id="updateCyber"  method="post" action="<?php echo e(url('/cyber/'.$cyber->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="box-body">
                        <div class="form-group">
                            <?php if($cyber->status == 1): ?>

                            <?php elseif($cyber->status == 0): ?>

                                <div class="col-md-6 col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="name" style="display: inline">Approve</label>
                                        <div class="checkbox" style="display: inline">
                                            <label>
                                                <input type="checkbox" name="approve">
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6 col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="name" style="display: inline">Decline</label>
                                        <div class="checkbox" style="display: inline">
                                            <label>
                                                <input type="checkbox" name="decline">
                                            </label>
                                            <textarea name="decline_reason" style="display: block;height: 150px!important;width: 100%"></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="name" style="display: inline">Approve</label>
                                        <div class="checkbox" style="display: inline">
                                            <label>
                                                <input type="checkbox" name="approve">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab_1" data-toggle="tab" aria-expanded="true">
                                        EN
                                    </a>
                                </li>
                                <li>
                                    <a href="#tab_2" data-toggle="tab" aria-expanded="false">
                                        ع
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">

                            <div class="tab-pane active" id="tab_1">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" class="form-control" id="name" placeholder="Place Name" name="name" value="<?php echo e($cyber->translate('en')->name); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="tab_2">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group form-ar">
                                        <label for="name">الاسم *</label>
                                        <input type="text" class="form-control" id="name" placeholder="الاسم" name="name_ar" value="<?php echo e($cyber->translateOrDefault('ar')->name); ?>" style="width: 100%">
                                    </div>
                                </div>
                            </div>

                        </div>



                        <div class="col-xs-12 cus-12">
                            <div class="form-group">
                                <label for="Phone">Phone</label>
                                <input type="text" class="form-control" id="Phone" placeholder="Phone" name="phone" maxlength="11" onkeypress="return allowNumbers(event)" value="<?php echo e($cyber->phone); ?>">
                            </div>
                        </div>


                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label for="government">City</label>
                                <div class="materialSelect inline empty ">
                                    <ul class="select">
                                        <input type="hidden" name="government" id="government" value="<?php echo e($cyber->government); ?>">
                                        <?php if($cyber->government > 0): ?>
                                            <?php $__currentLoopData = $allzones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($cyber->government == $zone->id ): ?>
                                                    <li data-value="0" value="<?php echo e($zone->id); ?>" data-selected="true"><?php echo e($zone->name); ?></li>
                                                <?php else: ?>
                                                    <li data-value="0" value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <li data-selected="true">Choose Your City</li>

                                            <?php $__currentLoopData = $allzones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li data-value="0" value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>


                                    </ul>
                                    <div class="message">Please select something</div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label for="government">Zone</label>
                                <div class="materialSelect inline empty ">
                                    <ul class="select" id="city">
                                        <input type="hidden" name="zone" value="<?php echo e($cyber->zone); ?>">
                                        <a id="t" name="_token" value="<?php echo e(csrf_token()); ?>" style="display: none"></a>
                                        <a id="u"  value="<?php echo e(url("cityCyber")); ?>" style="display: none"></a>
                                        <?php $__currentLoopData = $allcitys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($cyber->zone == $city->id): ?>
                                                <li data-selected="true"><?php echo e($city->name); ?></li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </ul>
                                    <div class="message">Please select something</div>
                                </div>
                            </div>
                        </div>

                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab_3" data-toggle="tab" aria-expanded="true">
                                        EN
                                    </a>
                                </li>
                                <li>
                                    <a href="#tab_4" data-toggle="tab" aria-expanded="false">
                                        ع
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">

                            <div class="tab-pane active" id="tab_3">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="address">Address</label>
                                        <input type="text" class="form-control" id="address" placeholder="Address" name="address" value="<?php echo e($cyber->translate('en')->address); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="tab_4">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group form-ar">
                                        <label for="name">العنوان *</label>
                                        <input type="text" class="form-control" id="address" placeholder="العنوان" name="address_ar" value="<?php echo e($cyber->translateOrDefault('ar')->address); ?>">
                                    </div>
                                </div>
                            </div>

                        </div>


                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label>Working From</label>
                                <input type="text" class="form-control" id="workhourfrom" placeholder="from" name="hourFrom" value="<?php echo e($cyber->working_from); ?>">
                            </div>
                        </div>

                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label>Working To</label>
                                <input type="text" class="form-control" id="workhourto" placeholder="to" name="hourTo" value="<?php echo e($cyber->working_to); ?>">
                            </div>
                        </div>

                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group">
                                <label for="screens" >Screens</label>
                                <input type="text" placeholder="num" class="form-control" name="screenNum" onkeypress="return allowNumbers(event)" value="<?php echo e($cyber->screens_num); ?>">

                            </div>
                        </div>

                        <div class="col-md-6 col-xs-12 cus-12" style="height: 74px;padding-top: 26px">
                            <?php if($cyber->screens_type == 1): ?>
                                <label class="radio-inline">
                                    <input type="radio" name="screens" value="1" checked>Open
                                </label>

                                <label class="radio-inline">
                                    <input type="radio" name="screens" value="0">Rooms
                                </label>

                                <label class="radio-inline">
                                    <input type="radio" name="screens" value="2">Both
                                </label>
                            <?php elseif($cyber->screens_type == 0): ?>
                                <label class="radio-inline">
                                    <input type="radio" name="screens" value="1">Open
                                </label>

                                <label class="radio-inline">
                                    <input type="radio" name="screens" value="0" checked>Rooms
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="screens" value="2">Both
                                </label>
                            <?php else: ?>
                                <label class="radio-inline">
                                    <input type="radio" name="screens" value="1">Open
                                </label>

                                <label class="radio-inline">
                                    <input type="radio" name="screens" value="0">Rooms
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="screens" value="2" checked>Both
                                </label>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 col-xs-12 cus-12">

                            <div class="form-group">
                                <label for="exampleInputEmail1">Devices</label>
                                <div class="checkbox">
                                    <div class="form-group">
                                        <div class="checkbox">
                                            <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($selecteddevices[$device->id])): ?>
                                                    <?php 
                                                        $cyberDevice = $cyber->devices->where('id',$device->id)->first();
                                                     ?>
                                                    <label style="display: block;margin-bottom: 10px">
                                                        <input type="checkbox" name="<?php echo e($device->translate('en')->name); ?>" checked> <?php echo e($device->name); ?>

                                                        <?php if(!is_null($cyberDevice)): ?>
                                                            <input name="<?php echo e($device->translate('en')->name); ?>_price"
                                                                   type="text" placeholder="price"
                                                                   style="float: right;"
                                                                   class="price" onkeypress="return allowNumbers(event)"
                                                                   value="<?php echo e($cyberDevice->price); ?>"
                                                            >
                                                        <?php else: ?>
                                                            <input name="<?php echo e($device->translate('en')->name); ?>_price"
                                                                   type="text" placeholder="price"
                                                                   style="float: right;"
                                                                   class="price" onkeypress="return allowNumbers(event)"
                                                                   value=""
                                                            >
                                                        <?php endif; ?>
                                                    </label>
                                                <?php else: ?>
                                                    <label style="display: block;margin-bottom: 10px">
                                                        <input type="checkbox" name="<?php echo e($device->translate('en')->name); ?>" class="device" > <?php echo e($device->name); ?>

                                                        <input name="<?php echo e($device->name); ?>_price"
                                                               type="text" placeholder="price"
                                                               style="float: right;display: none"
                                                               class="price" onkeypress="return allowNumbers(event)"
                                                        >
                                                    </label>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>

                                </div>
                            </div>

                        </div>

                        <div class="col-md-6 col-xs-12 cus-12">

                            <div class="form-group">
                                <label>Options</label>
                                <div class="checkbox">
                                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($selectedOptions[$option->id])): ?>
                                            <label>
                                                <input type="checkbox" name="<?php echo e($option->translate('en')->name); ?>" checked> <?php echo e($option->name); ?>

                                            </label>
                                        <?php else: ?>
                                            <label>
                                                <input type="checkbox" name="<?php echo e($option->translate('en')->name); ?>"> <?php echo e($option->name); ?>

                                            </label>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>


                        <div class="clearfix"></div>

                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab_5" data-toggle="tab" aria-expanded="true">
                                        EN
                                    </a>
                                </li>
                                <li>
                                    <a href="#tab_6" data-toggle="tab" aria-expanded="false">
                                        ع
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">

                            <div class="tab-pane active" id="tab_5">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control" id="description" placeholder="Description" name="desc" rows="5"><?php echo e($cyber->translate('en')->description); ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane" id="tab_6">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group form-ar">
                                        <label for="name">الوصف *</label>
                                        <textarea type="text" class="form-control" id="description" placeholder="الوصف" name="desc_ar" rows="5"><?php echo e($cyber->translateOrDefault('ar')->description); ?></textarea>
                                    </div>
                                </div>
                            </div>

                        </div>




                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group reli">
                                <label for="image">Upload </label>
                                <input type="file" id="gallery-photo-add" class="upload-hidden" name="images[]" multiple accept="jpg, gif, png" value="<?php echo e(url('uploads/')); ?>.1508533048aqar-test.png"/>
                                <button class="btn btn-default upload">
                                    upload
                                </button>

                                <input type="hidden" name="deletedImages[]" id="deletedImages" />

                                <div class="gallery">
                                    <?php $__currentLoopData = $cyber->cyberImg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div style="position: relative;display: inline-block" id="<?php echo e($image->id); ?>">
                                            <img src="<?php echo e(url('uploads/' . $image->img_url)); ?>" style="width: 100px;height: 100px">
                                            <button type="button" class="delete-btn" value="<?php echo e($image->id); ?>" onclick="deleteImage(this.value)" style="position: absolute;top: 0;right: 0;z-index: 99999">
                                                X
                                            </button>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group map">
                                <label class="control-label">Location:</label>

                                <input type="text" class="form-control" id="us3-address"/>


                                <div id="us3" style="width: 96%; height: 400px;"></div>

                                <div class="m-t-small">
                                    <input type="hidden" class="form-control"  id="us3-lat" name="lat" value="<?php echo e($cyber->lat); ?>"/>

                                    <input type="hidden" class="form-control"  id="us3-lon" name="lng" value="<?php echo e($cyber->long); ?>"/>
                                </div>


                            </div>
                        </div>

                    </div>




                    <div class="box-footer">
                        <div class="col-xs-12">
                            <button class="btn btn-primary " type="submit">
                                        <span>
                                                Submit
                                            </span>
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>