
Hi <?php echo e($name); ?>,
<p>
    welcome,<br>
    Your Account is active now
</p>




Thanks,<br>
<?php echo e('THE GAME'); ?>


