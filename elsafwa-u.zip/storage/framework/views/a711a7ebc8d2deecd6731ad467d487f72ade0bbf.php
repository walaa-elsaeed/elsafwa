<?php $__currentLoopData = $cybers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cyber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12 col-sm-6 col-xs-12">
    <div class="center-box" id="box1">
        <h4 class="pull-left">
            <a href="<?php echo e('cyber/'.$cyber->id); ?>">
                <?php echo e($cyber->name); ?>

            </a>
        </h4>

        <h4 class="pull-right">
            <a href="<?php echo e('cyber/'.$cyber->id); ?>">
                <?php if($cyber->tourn_cyber_status() == 0): ?>
                    <i class="fa fa-trophy join"></i>
                <?php elseif($cyber->tourn_cyber_status() == 1): ?>
                    <i class="fa fa-trophy block"></i>
                <?php endif; ?>
            </a>
        </h4>
        <div class="clearfix"></div>
        <p class="address">
            <?php echo e($cyber->address); ?>

        </p>
        <div class="heart">
            <?php for($i=0;$i<$cyber->rate;$i++): ?>
                <i class="fa fa-heart" aria-hidden="true"></i>
            <?php endfor; ?>
            <?php for($i;$i<5;$i++): ?>
                <i class="fa fa-heart-o" aria-hidden="true"></i>
            <?php endfor; ?>
        </div>

        <div class="options pull-left">

            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cyber->options->contains('id',$option->id)): ?>
                    <img src="<?php echo e(url('uploads/' . $option->img_url)); ?>">
                <?php else: ?>
                    <img src="<?php echo e(url('uploads/' . $option->img_url)); ?>" class="grayscale">
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        
        <div class="clearfix"></div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
