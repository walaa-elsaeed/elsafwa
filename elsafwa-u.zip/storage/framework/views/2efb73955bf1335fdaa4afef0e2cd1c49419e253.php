<?php $__currentLoopData = $tourn_cybers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tourn_cyber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 col-sm-6 col-xs-12">
        <div class="cyber-item">
            <div class="media">
                <div class="media-left">
                    <a href="<?php echo e('cyber/'.$tourn_cyber->id); ?>">
                        <img class="media-object img-responsive" src="<?php echo e(url('uploads/'.$tourn_cyber->cyberImg[0]->img_url)); ?>">
                    </a>
                </div>
                <div class="media-body">
                    <?php if($tourn_cyber->tourn_cyber_status() == 0): ?>
                        <h5>
                            <?php echo e($tourn_cyber->name); ?>

                        </h5>
                        <p class="rate">
                            <?php for($i=0;$i<$tourn_cyber->tourn_rate();$i++): ?>
                                <i class="fa fa-heart" aria-hidden="true"></i>
                            <?php endfor; ?>
                            <?php for($i;$i<5;$i++): ?>
                                <i class="fa fa-heart-o" aria-hidden="true"></i>
                            <?php endfor; ?>
                            <span>(<?php echo e($tourn_cyber->count_tourn_rates()); ?>)</span>
                        </p>

                        <p class="add">
                            <?php echo e($tourn_cyber->address); ?>

                            <br>
                            <?php echo e($tourn_cyber->phone); ?>

                        </p>
                    <?php elseif($tourn_cyber->tourn_cyber_status() == 1): ?>
                        <h5 class="cyber-gray">
                            <?php echo e($tourn_cyber->name); ?>

                        </h5>
                        <p class="block-text">
                            Out Of Service
                        </p>
                    <?php endif; ?>


                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>