<footer>
    <div class="container">
        <div class="row footer">
            <div class="col-md-4 col-xs-12">
                <div class="footer-1">
                    <img src="<?php echo e(url('img/2d-final.png')); ?>" class="img-responsive">
                    <p>
                        <?php echo e(__('strings.footer-info')); ?>

                        <br>
                        <span>
                            <?php echo e(__('strings.footer-social')); ?>

                        </span>
                    </p>
                    <div class="icons-soc">
                        <a href="https://www.facebook.com/gameofficialpage/" target="_blank">
                            <i class="fa fa-facebook" aria-hidden="true"></i>
                        </a>

                        <a href="https://www.instagram.com/gameofficialpage/" target="_blank">
                            <i class="fa fa-instagram" aria-hidden="true"></i>
                        </a>

                        <a href="https://www.youtube.com/channel/UCjcHPe1PzdoRxnl35KxM-VQ " target="_blank">
                            <i class="fa fa-youtube" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-xs-12">
                <div class="news">
                    <h3>
                        <?php echo e(__('strings.contact')); ?>

                        <hr>
                    </h3>

                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were problems with input:
                            <br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form  method="post" action="<?php echo e(url('storemessage')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="input-group">
                            <input type="email" class="form-control" placeholder="<?php echo e(__('strings.email')); ?>"
                                   aria-describedby="basic-addon2"
                                   name="email">
                            <textarea placeholder="<?php echo e(__('strings.msg')); ?>" name="message"></textarea>

                            <button type="submit"><?php echo e(__('strings.send')); ?></button>
                        </div>
                    </form>

                </div>
            </div>

            <div class="col-md-4 col-xs-12">
                <div class="tabs">
                    <ul class="nav nav-tabs" id="myTab">
                        <li class="active"><a href="#top-games"><?php echo e(__('strings.latest_cybers')); ?></a></li>
                        <li><a href="#top-rate"><?php echo e(__('strings.latest_trades')); ?></a></li>
                        <li><a href="#three"><?php echo e(__('strings.latest_news')); ?></a></li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane active" id="top-games">
                            <div class="container">

                                <div class="row">
                                    <?php $__currentLoopData = $latestCybers->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestCyber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
                                            <div class="col-xs-5">
                                                <a href="<?php echo e(url('cyber/'.$latestCyber->id)); ?>">
                                                    <img src="<?php echo e(url('uploads/'.$latestCyber->cyberImg->first()->img_url)); ?>"
                                                         class="img-responsive">
                                                </a>

                                            </div>

                                            <div class="col-xs-7">
                                                <a href="<?php echo e(url('cyber/'.$latestCyber->id)); ?>">
                                                    <h6>
                                                        <?php echo e($latestCyber->name); ?>

                                                    </h6>
                                                </a>

                                                <span><?php echo e($latestCyber->created_at); ?></span>
                                                <p>
                                                    <?php echo e($latestCyber->description); ?>

                                                </p>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>

                            </div>
                        </div>
                        <div class="tab-pane" id="top-rate">
                            <div class="container">
                                <div class="row">
                                    <?php $__currentLoopData = $latesttrades->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latesttrade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
                                            <div class="col-xs-5">
                                                <a href="<?php echo e(url('trade/'.$latesttrade->id)); ?>">
                                                    <img src="<?php echo e(url('uploads/'.$latesttrade->tradeImg->first()->img_url)); ?>"
                                                         class="img-responsive">
                                                </a>

                                            </div>

                                            <div class="col-xs-7">
                                                <a href="<?php echo e(url('trade/'.$latesttrade->id)); ?>">
                                                    <h6>
                                                        <?php echo e($latesttrade->name); ?>

                                                    </h6>
                                                </a>

                                                <span><?php echo e($latesttrade->created_at); ?></span>
                                                <p>
                                                    <?php echo e($latesttrade->description); ?>

                                                </p>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                            </div>
                        </div>


                        <div class="tab-pane" id="three">
                            <div class="container">
                                <?php $__currentLoopData = $latestnews->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestnew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-xs-5">
                                            <a href="<?php echo e(url('new/'.$latestnew['id'])); ?>">
                                                <img src="<?php echo e(url('uploads/'.$latestnew->img_url)); ?>"
                                                     class="img-responsive">
                                            </a>

                                        </div>

                                        <div class="col-xs-7">
                                            <a href="<?php echo e(url('new/'.$latestnew['id'])); ?>">
                                                <h6>
                                                    <?php echo e($latestnew->tittle); ?>

                                                </h6>
                                            </a>

                                            <span><?php echo e($latestnew->created_at); ?></span>
                                            <p>
                                                <?php echo e($latestnew->description); ?>

                                            </p>
                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>