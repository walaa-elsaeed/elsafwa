<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>
    <style>
        #trades .col-xs-12
        {
            height: 300px;
        }
    </style>
</head>


<script>
    var view = $('#trades');
    function gettradesfront(zone) {
        $.ajax({
            url: '<?php echo e(url("citytradesfront")); ?>',
            type: 'post',
            data: {
                city_id: zone,
                _token : $('#t').attr('value')

            },
            success: function (data) {
                /*console.log(data);*/
                var d = JSON.parse(data);
                $('#cities_filter').children('option').remove();
                $('#cities_filter').append("<option disabled selected><?php echo e(__('strings.chose-city')); ?></option>");
                for (var i = 0; i < d.length; i++) {
                    $('#cities_filter').append("<option  value='"+d[i].id+"'>"+d[i].name+"</option>");
                }
            },
            failure: function(e){

            },
            complete: function () {
                updateTable();
            }
        });
    }



    function getoperationTradefront(ope) {
        $.ajax({
            url: '<?php echo e(url("tradesfront")); ?>',
            type: 'post',
            data: {
                operation_id:ope,
                _token : $('#t').attr('value')

            },
            success: function (data) {
                /*console.log(data);*/
                var d = JSON.parse(data);
            },
            failure: function(e){

            },
            complete: function () {
                updateTable();
            }
        });
    }

    function getCatTradefront(cat) {
        $.ajax({
            url: '<?php echo e(url("tradesCatfront")); ?>',
            type: 'post',
            data: {
                category_id:cat,
                _token : $('#t').attr('value')

            },
            success: function (data) {
//                console.log(data);
                var d = JSON.parse(data);
            },
            failure: function(e){

            },
            complete: function () {
                updateTable();
            }
        });
    }

    function prevTrades(){
        var currentPage = parseInt($('#page').val());
        $('#page').val(currentPage-1);
        updateTable();
    }

    function nextTrades(){
        var currentPage = parseInt($('#page').val());
        $('#page').val(currentPage+1);
        updateTable();
    }

    function getTrades(page){
        $('#page').val(page);
        updateTable();
    }

    function updateTable(){
        var zone = $("#city_fil").val();
        var ope = $('#ope').val();
        var cat = $('#cat').val();
        var page = $('#page').val();
        if(zone == undefined){
            zone = 0;
        }
        if(ope == undefined){
            ope = 0;
        }
        if(cat == undefined){
            cat = 0;
        }
        if (page == undefined){
            page = 0;
        }
        /*console.log("zone"+zone);*/
        var url = '<?php echo e(url("ajaxtrade")); ?>';
        url +='/'+zone+'/'+ope+'/'+cat+'/'+page;
        /*console.log("url"+url);*/

        $.ajax({
            url: url,
            type: 'get',
            data: {
            },
            success: function (data) {
                var d = JSON.parse(data);
                $("#trades").html(d.htmlString);
                $('#pagi').children().remove();
                var page = $('#page').val();
                if (page == undefined){
                    page = 0;
                }
                var current = parseInt(page);
                var allTrades = parseInt(d.allTrades);
                $('#pagi').children().remove();
                if(allTrades > 0){
                    if(current>=6){
                        $('#pagi').append('<li><button class="btn btn-default" onclick="prevTrades();"><<</buttonclass></li>');
                        for (var i=1; i<=6;i++){
                            var newValue = current+i;
                            if ((newValue * 6) <= allTrades+6){
                                if((newValue-1) == current)
                                    $('#pagi').append('<li><button class="btn btn-default active" onclick="getTrades(this.value);" value="'+(newValue)+'">'+(newValue)+'</buttonclass></li>');
                                else
                                    $('#pagi').append('<li><button class="btn btn-default" onclick="getTrades(this.value);" value="'+(newValue)+'">'+(newValue)+'</buttonclass></li>');
                            }
                        }
                        if(((current*6)+6) <= allTrades-6)
                            $('#pagi').append('<li><button class="btn btn-default" onclick="nextTrades();">>></buttonclass></li>');
                    }
                    else{
                        if(current-1 > 0)
                            $('#pagi').append('<li><button class="btn btn-default" onclick="prevTrades();"><<</buttonclass></li>');
                        for (var i=0; i<6;i++){
                            if((i*6) <= allTrades){
                                if((i+1) == current)
                                    $('#pagi').append('<li><button class="btn btn-default active" onclick="getTrades(this.value);" value="'+(i+1)+'">'+(i+1)+'</buttonclass></li>');
                                else
                                    $('#pagi').append('<li><button class="btn btn-default " onclick="getTrades(this.value);" value="'+(i+1)+'">'+(i+1)+'</buttonclass></li>');
                            }
                        }
                        if(((((current-1)*6)+6) <= allTrades))
                            $('#pagi').append('<li><button class="btn btn-default" onclick="nextTrades();">>></buttonclass></li>');
                    }
                }
            },
            failure: function(e){

            },
            complete: function () {

            }
        });

    }



</script>

<script>
    $(function () {
        updateTable();
    });
</script>


<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<!--Body-->
<div class="container-fluid">


    <div class="row banner">
        <div class="col-xs-12">
            <img src="<?php echo e(url('img/market-banner.jpg')); ?>" class="img-responsive">
        </div>
    </div>


    <!--Ads Area-->

    <div class="ads-area row">

        <div class="col-xs-12 cus-12">
            <div class="area">

                <div class="trading-area">

                    <div class="filters">
                        <div class="container">
                            <div class="row">
                                <a id="t" name="_token" value="<?php echo e(csrf_token()); ?>" style="display: none"></a>
                                <div class="col-sm-4 col-xs-12 cus-12">
                                    <div class="materialSelect inline empty ">
                                        <ul class="select">
                                            <input id="city_fil" name="city_fil" type="hidden" value="0">
                                            <li data-selected="true"><?php echo e(__('strings.select-gov')); ?></li>
                                            <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li data-value="0" value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <div class="message">Please select something</div>
                                    </div>
                                </div>

                                <div class="col-sm-4 col-xs-12 cus-12">
                                    <div class="materialSelect inline empty ">
                                        <ul class="select">
                                            <input id="ope" name="ope" type="hidden" value="0">
                                            <li data-selected="true"><?php echo e(__('strings.select-ope')); ?></li>
                                            <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li data-value="0" value="<?php echo e($operation->id); ?>"><?php echo e($operation->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <div class="message">Please select something</div>
                                    </div>
                                </div>


                                <div class="col-sm-4 col-xs-12 cus-12">
                                    <div class="materialSelect inline empty ">
                                        <ul class="select">
                                            <input id="cat" name="cat" type="hidden" value="0">
                                            <li data-selected="true"><?php echo e(__('strings.select-cat')); ?></li>
                                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li data-value="0" value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <div class="message">Please select something</div>
                                    </div>
                                </div>



                            </div>
                        </div>
                    </div>



                    <div class="trading-boxes">

                        <div class="container">
                            <div class="row" id="trades">
                                <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 col-sm-6 col-xs-12">
                                        <div class="btm-br">
                                            <div class="media">
                                                <div class="media-left">
                                                    <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($operation->id == $trade->operation_id): ?>
                                                            <a href="<?php echo e('trade/'.$trade->id); ?>" class="<?php echo e($operation->classname); ?>">
                                                                <img class="media-object img-responsive" src="<?php echo e(url('uploads/'.$trade->tradeImg[0]->img_url)); ?>">
                                                            </a>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading pull-left">
                                                        <a href="<?php echo e('trade/'.$trade->id); ?>">
                                                            <?php echo e($trade->name); ?>

                                                        </a>
                                                    </h4>
                                                    <h4 class="media-heading pull-right trade-price">
                                                        <span><?php echo e($trade->price); ?> <?php echo e(__('strings.eg')); ?></span>
                                                    </h4>
                                                    <div class="clearfix"></div>
                                                    <a href="<?php echo e(url('user/'.$trade->user_id)); ?>">@ <?php echo e($trade->user['user_name']); ?></a>
                                                    <h6 class="rate">
                                                        <?php for($i=0;$i<$trade->user->avg_rate();$i++): ?>
                                                            <i class="fa fa-heart" aria-hidden="true"></i>
                                                        <?php endfor; ?>
                                                        <?php for($i;$i<5;$i++): ?>
                                                            <i class="fa fa-heart-o" aria-hidden="true"></i>
                                                        <?php endfor; ?>
                                                        <span>
                                                            <?php echo e('('.$trade->user->number_of_trading_rates().')'); ?>

                                                        </span>
                                                    </h6>
                                                </div>
                                            </div>

                                            <div class="des">
                                                <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($operation->id == $trade->operation_id): ?>
                                                        <div class="type <?php echo e($operation->classname); ?>">
                                                            <?php echo e($operation->name); ?>

                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p>
                                                    <?php echo e($trade->description); ?>

                                                </p>

                                                <div class="gallery">
                                                    <div class="images pull-left">
                                                        <?php $__currentLoopData = $trade->tradeImg->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <img src="<?php echo e(url('uploads/' . $img->img_url)); ?>">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </div>

                                                    <div class="readmore pull-right">
                                                        <a href="<?php echo e('trade/'.$trade->id); ?>">
                                                            <i class="fa fa-circle" aria-hidden="true"></i>
                                                            <i class="fa fa-circle" aria-hidden="true"></i>
                                                            <i class="fa fa-circle" aria-hidden="true"></i>
                                                        </a>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>





                            <div class="row text-center">
                                <nav aria-label="Page navigation">
                                    <input type="hidden" id="page" value="1">
                                    <ul class="pagination" id="pagi">


                                    </ul>
                                </nav>
                            </div>

                            <div class="row text-center">
                                <a href="<?php echo e(url('add_trade')); ?>" class="btn btn-default add-stuff">
                                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

                                    <span>
                                        <?php echo e(__('strings.add_stuff')); ?>

                                    </span>

                                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
                                </a>
                            </div>

                        </div>


                    </div>
                </div>

            </div>
        </div>

    </div>

</div>
<!--Body-->




<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>