<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
</script>


<script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>

<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 6%">
        <div class="col-md-offset-1 col-md-10 col-xs-12">
            <div class="box box-primary">

                <div class="box-header with-border">
                    <h3 class="box-title">
                        Edit New
                    </h3>
                </div>

                <form method="post" action="<?php echo e(url('/update_new/'.$new->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="box-body">

                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab_1" data-toggle="tab" aria-expanded="true">
                                        EN
                                    </a>
                                </li>
                                <li>
                                    <a href="#tab_2" data-toggle="tab" aria-expanded="false">
                                        ع
                                    </a>
                                </li>
                            </ul>
                        </div>


                        <div class="tab-content">

                            <div class="tab-pane active" id="tab_1">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="name">Tittle *</label>
                                        <input type="text" class="form-control" id="name" placeholder="Tittle" name="tittle"   value="<?php echo e($new->translate('en')->tittle); ?>" style="width: 100%">
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="tab_2">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group form-ar">
                                        <label for="name">العنوان *</label>
                                        <input type="text" class="form-control" id="name" placeholder="العنوان" name="tittle_ar" value="<?php echo e($new->translate('ar')->tittle); ?>" style="width: 100%">
                                    </div>
                                </div>
                            </div>

                        </div>


                        <div class="col-xs-12 cus-12">
                            <div class="form-group">
                                <label for="text">article Source *</label>
                                <input type="text" class="form-control" name="source"  value="<?php echo e($new->source); ?>" required>
                            </div>
                        </div>


                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab_3" data-toggle="tab" aria-expanded="true">
                                        EN
                                    </a>
                                </li>
                                <li>
                                    <a href="#tab_4" data-toggle="tab" aria-expanded="false">
                                        ع
                                    </a>
                                </li>
                            </ul>
                        </div>


                        <div class="tab-content">

                            <div class="tab-pane active" id="tab_3">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group">
                                        <label for="name">Description *</label>
                                        <textarea class="form-control" id="name" placeholder="Description" name="description"  rows="5" style="width: 100%"><?php echo e($new->translate('en')->description); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="tab_4">
                                <div class="col-xs-12 cus-12">
                                    <div class="form-group form-ar">
                                        <label for="name">الموضوع *</label>
                                        <textarea class="form-control" id="name" placeholder="الموضوع" name="description_ar" rows="5" style="width: 100%"><?php echo e($new->translate('ar')->description); ?></textarea>
                                    </div>
                                </div>
                            </div>

                        </div>




                        <div class="col-md-6 col-xs-12 cus-12">
                            <div class="form-group reli">
                                <label for="image">Upload image *</label>
                                <input type="file"  class="upload-hidden" name="file" style="width: 100%!important;height: 100%!important;" required onchange="readURL(this);">
                                <button class="btn btn-default upload">
                                    upload
                                </button>
                                <div class="form-group">
                                    <img id="profile-img" src="<?php echo e(url('uploads/'.$new->img_url)); ?>"  alt="" style="width:650px;height: 400px;border: 1px dashed #0080c4"/>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="box-footer">
                        <div class="col-xs-12">
                            <button class="btn btn-primary " type="submit">
                                        <span>
                                                Submit
                                            </span>
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>