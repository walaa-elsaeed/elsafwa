<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
</script>


<script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>

<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 6%">
        <div class="col-md-offset-1 col-md-10 col-xs-12">
            <div class="box box-primary">

                <div class="box-header with-border">
                    <h3 class="box-title">
                        Edit Slide
                    </h3>
                </div>

                <form method="post" action="<?php echo e(url('/update_partner/'.$partner->id)); ?>}}" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="box-body">

                        <div class="form-group">
                            <label for="text">Select Type *</label>
                            <div class="materialSelect inline empty ">
                                <ul class="select">
                                    <input type="hidden" name="tourn" value="<?php echo e($partner->tourn_id); ?>">

                                    <?php $__currentLoopData = $tourns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tourn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($tourn->id ==$partner->tourn_id ): ?>
                                            <li data-selected="true" data-value="0" value="<?php echo e($tourn->id); ?>"><?php echo e($tourn->name); ?></li>
                                        <?php else: ?>
                                            <li data-value="0" value="<?php echo e($tourn->id); ?>"><?php echo e($tourn->name); ?></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                                <div class="message">Please select something</div>
                            </div>
                        </div>

                        <div class="col-xs-12 cus-12">
                            <div class="form-group reli">
                                <label for="image">Upload image *</label>
                                <input type="file"  class="upload-hidden" name="file" style="width: 100%!important;height: 100%!important;"
                                       value="<?php echo e(url('uploads/'.$partner->img_url)); ?>"
                                       onchange="readURL(this);">
                                <button class="btn btn-default upload">
                                    upload
                                </button>
                                <div class="form-group">
                                    <img id="profile-img" src="<?php echo e(url('uploads/'.$partner->img_url)); ?>" alt=""
                                         style="width:100%;height: 500px;border: 1px dashed #0080c4"/>

                                </div>
                            </div>
                        </div>





                    </div>

                    <div class="box-footer">
                        <div class="col-xs-12">
                            <button class="btn btn-primary " type="submit">
                                        <span>
                                                Submit
                                            </span>
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>