<?php $__env->startSection('content'); ?>
    <div class="row" style="padding: 20px 15px 0">
        <div class="col-xs-12">
            <div class="content-header">
                <h1>
                    لوحه التحكم
                    <small>من هنا يمكنك التحكم بكل شئ لموقع الصفوه للانتاج الفنى</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <a href="">
                            <i class="fa fa-dashboard"></i>
                            الرئيسيه
                        </a>
                    </li>
                    <li class="active">
                        <a href="">
                            لوحه التحكم
                        </a>
                    </li>
                </ol>
            </div>
        </div>

    </div>

    
    <!-- /.col -->

    


    



    <div class="row" style="padding: 20px 15px 0">
        <div class="col-xs-12"  style="margin-bottom: 20px">
            <h1>
                الاقسام :
            </h1>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <?php echo e($departs_count); ?>

                    </h3>
                    <p>كل الاقسام</p>
                </div>
                <div class="icon">
                    <i class="fa fa-th-large"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('admin/departs')); ?>">
                    التفاصيل
                    <i class="fa fa-arrow-circle-left"></i>
                </a>
            </div>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-green">
                <div class="inner">
                    <h3>
                        <?php echo e($departs_series_count); ?>

                    </h3>
                    <p>كل الحلقات</p>
                </div>
                <div class="icon">
                    <i class="fa fa-youtube-play"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('admin/serieses')); ?>">
                    التفاصيل
                    <i class="fa fa-arrow-circle-left"></i>
                </a>
            </div>
        </div>


        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3>
                        <?php echo e($departs_articles_count); ?>

                    </h3>
                    <p>كل المقالات</p>
                </div>
                <div class="icon">
                    <i class="fa fa-file"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('admin/articles')); ?>">
                    التفاصيل
                    <i class="fa fa-arrow-circle-left"></i>
                </a>
            </div>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-red">
                <div class="inner">
                    <h3>
                        <?php echo e($departs_books_count); ?>

                    </h3>
                    <p>كل الكتب</p>
                </div>
                <div class="icon">
                    <i class="fa fa-book"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('admin/books')); ?>">
                    التفاصيل
                    <i class="fa fa-arrow-circle-left"></i>
                </a>
            </div>
        </div>
    </div>



    <div class="row" style="padding: 20px 15px 0">
        <div class="col-xs-12"  style="margin-bottom: 20px">
            <h1>
                الاخبار :
            </h1>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <?php echo e($news_count); ?>

                    </h3>
                    <p>كل الاخبار</p>
                </div>
                <div class="icon">
                    <i class="ion ion-android-notifications-none"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('admin/news')); ?>">
                    التفاصيل
                    <i class="fa fa-arrow-circle-left"></i>
                </a>
            </div>
        </div>

    </div>


    <div class="row" style="padding: 0 15px 20px">
        <div class="col-xs-12"  style="margin-bottom: 20px">
            <h1>
                البلوج :
            </h1>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <?php echo e($blogs_count); ?>

                    </h3>
                    <p>كل البلوجات</p>
                </div>
                <div class="icon">
                    <i class="fa fa-edit"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('admin/blogs')); ?>">
                    التفاصيل
                    <i class="fa fa-arrow-circle-left"></i>
                </a>
            </div>
        </div>



        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3>
                        <?php echo e($departs_articles_count); ?>

                    </h3>
                    <p>كل المقالات</p>
                </div>
                <div class="icon">
                    <i class="fa fa-file"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('admin/blog_articles')); ?>">
                    التفاصيل
                    <i class="fa fa-arrow-circle-left"></i>
                </a>
            </div>
        </div>



    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>