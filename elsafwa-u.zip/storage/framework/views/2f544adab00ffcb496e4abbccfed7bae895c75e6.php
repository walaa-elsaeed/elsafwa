<?php $__env->startSection('lay_out'); ?>

    <div class="news">
        <div class="container">
            <div class="row">

                <div class="col-xs-12">
                    <div class="media">
                        <div class="media-left">
                            <a href="#">
                                <div class="img-container">
                                    <img class="media-object img-responsive" src="<?php echo e(url('uploads/'.$user->img_url)); ?>"
                                         alt="profile_img" style="width: 100%">
                                </div>
                            </a>
                        </div>
                        <div class="media-body media-middle">
                            <h4 class="media-heading">
                                الاسم :
                                <?php echo e($user->name); ?>

                            </h4>
                            <p>
                                البريد الالكترونى :
                                <?php echo e($user->email); ?>

                                <br>
                                <?php if(isset($user->phone)): ?>
                                    التليفون :
                                    <?php echo e($user->phone); ?>

                                <?php endif; ?>
                            </p>

                            <?php if(Auth::check()): ?>
                                <?php if(Auth::user()->id ==$user->id ): ?>
                                    <a href="<?php echo e(url('users/'.$user->id.'/edit')); ?>">
                                        تعديل ...
                                    </a>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>