<?php $__env->startSection('lay_out'); ?>

    <div class="departs">
        <div class="container">
            <h2>
                اقسام الموقع :
            </h2>

            <div class="row">
                <?php $__currentLoopData = $departs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6 col-xs-12">

                        <div class="depart_holder">
                            <div class="v-align">
                                <img src="<?php echo e(url('uploads/'.$depart->img_url)); ?>" class="img-responsive">
                                <p class="text-center">
                                    <?php echo e($depart->name); ?>

                                </p>
                            </div>
                            <div class="overlay text-center">
                                <a href="<?php echo e(url('departs/'.$depart->id)); ?>" class="v-align">
                                    المزيد
                                </a>
                            </div>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>