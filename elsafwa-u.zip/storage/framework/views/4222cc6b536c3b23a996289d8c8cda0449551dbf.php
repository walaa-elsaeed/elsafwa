<?php $request = app('Illuminate\Http\Request'); ?>
<!-- Left side column. contains the sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <ul class="sidebar-menu">

            <li class="<?php echo e($request->segment(1) == 'home' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/admin/home')); ?>">
                    <i class="fa fa-wrench"></i>
                    <span class="title"><?php echo app('translator')->getFromJson('global.app_dashboard'); ?></span>
                </a>
            </li>

            <li class="treeview">

                <a href="#">
                    <i class="ion ion-home" aria-hidden="true"></i>
                    <span class="title">Home</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('slider')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Slider
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-primary pull-right">
                                    <?php echo e($allslides); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('marquee')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Home News
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-success pull-right">
                                    <?php echo e($allmarquees); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('messages')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Messages
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-warning pull-right">
                                    <?php echo e($allmsg); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                </ul>
            </li>



            <li class="treeview">

                <a href="#">
                    <i class="ion ion-ios-game-controller-b" aria-hidden="true"></i>
                    <span class="title">Cybers</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('cybers')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                All
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-primary pull-right">
                                    <?php echo e(count($allcybers)); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('cybers-approved')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Approved
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-success pull-right">
                                    <?php echo e(count($approved)); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('cybers-pending')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Pending
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-warning pull-right">
                                    <?php echo e(count($pendings)); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('cybers-decline')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Decline
                            </span>

                            <span class="pull-right-container">
                                <span class="label bg-red pull-right">
                                    <?php echo e(count($decline)); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="treeview">

                <a href="#">
                    <i class="ion ion-android-notifications-none" aria-hidden="true"></i>
                    <span class="title">News</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('news-list')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                News
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-primary pull-right">
                                    <?php echo e(count($allnews)); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('add_new')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Add New
                            </span>
                        </a>
                    </li>

                </ul>
            </li>


            <li class="treeview">

                <a href="#">
                    <i class="ion ion-ios-cart" aria-hidden="true"></i>
                    <span class="title">Market</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('alltrades')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                All
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-primary pull-right">
                                    <?php echo e($alltrades); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('approvetrades')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Approved
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-success pull-right">
                                    <?php echo e($alltradesapproved); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('pendingtrades')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Pending
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-warning pull-right">
                                    <?php echo e($alltradespending); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('declinetrades')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Decline
                            </span>

                            <span class="pull-right-container">
                                <span class="label bg-red pull-right">
                                    <?php echo e($alltradesdecline); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                </ul>
            </li>


            <li class="treeview">

                <a href="#">
                    <i class="ion ion-ipad" aria-hidden="true"></i>
                    <span class="title">Devices</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('devices')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Devices
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-primary pull-right">
                                    <?php echo e(count($alldevices)); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('add-device')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Add Device
                            </span>

                        </a>
                    </li>
                </ul>
            </li>


            <li class="treeview">

                <a href="#">
                    <i class="ion ion-levels" aria-hidden="true"></i>
                    <span class="title">Options</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('options')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Options
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-primary pull-right">
                                    <?php echo e(count($alloptions)); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('add-option')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Add Option
                            </span>

                        </a>
                    </li>
                </ul>
            </li>



            <li class="treeview">

                <a href="#">
                    <i class="ion ion-ios-location" aria-hidden="true"></i>
                    <span class="title">Locations</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('citys')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Citys
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-primary pull-right">
                                    <?php echo e(count($allzones)); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('zones')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Zones
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-primary pull-right">
                                    <?php echo e(count($allcitys)); ?>

                                </span>
                            </span>
                        </a>
                    </li>

                </ul>
            </li>

            <li class="treeview">

                <a href="#">
                    <i class="ion ion-ios-albums" aria-hidden="true"></i>
                    <span class="title">Operations</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('operations')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                operations
                            </span>
                            <span class="pull-right-container">
                                <span class="label label-primary pull-right">
                                    <?php echo e($alloperations); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('add-operation')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Add Operation
                            </span>

                        </a>
                    </li>
                </ul>
            </li>

            <li class="treeview">

                <a href="#">
                    <i class="fa fa-trophy" aria-hidden="true"></i>
                    <span class="title">Tournament</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('alltournaments')); ?>">
                            <i class="fa" aria-hidden="true"></i>
                            <span class="title">
                                All
                            </span>
                        </a>
                    </li>

                    <li class="treeview">

                        <a href="#">
                            <i class="ion ion-ios-albums" aria-hidden="true"></i>
                            <span class="title">Header Slider</span>
                            <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                        </a>

                        <ul class="treeview-menu">

                            <li>
                                <a href="<?php echo e(url('allheader')); ?>">
                                    <i class="fa " aria-hidden="true"></i>
                                    <span class="title">
                                All
                            </span>
                                    <span class="pull-right-container">
                                <span class="label label-primary pull-right">

                                </span>
                            </span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('add_header_slide')); ?>">
                                    <i class="fa " aria-hidden="true"></i>
                                    <span class="title">
                                Add New Slide
                            </span>

                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="treeview">

                        <a href="#">
                            <i class="ion ion-ios-albums" aria-hidden="true"></i>
                            <span class="title">ADS Slider</span>
                            <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                        </a>

                        <ul class="treeview-menu">

                            <li>
                                <a href="<?php echo e(url('alladds')); ?>">
                                    <i class="fa " aria-hidden="true"></i>
                                    <span class="title">
                                All
                            </span>
                                    <span class="pull-right-container">
                                <span class="label label-primary pull-right">

                                </span>
                            </span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('add_adds_slide')); ?>">
                                    <i class="fa " aria-hidden="true"></i>
                                    <span class="title">
                                Add New ADD
                            </span>

                                </a>
                            </li>
                        </ul>
                    </li>


                    <li class="treeview">

                        <a href="#">
                            <i class="ion ion-ios-albums" aria-hidden="true"></i>
                            <span class="title">Partner Slider</span>
                            <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                        </a>

                        <ul class="treeview-menu">

                            <li>
                                <a href="<?php echo e(url('allparts')); ?>">
                                    <i class="fa " aria-hidden="true"></i>
                                    <span class="title">
                                All
                            </span>
                                    <span class="pull-right-container">
                                <span class="label label-primary pull-right">

                                </span>
                            </span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('add_partner_slide')); ?>">
                                    <i class="fa " aria-hidden="true"></i>
                                    <span class="title">
                                Add New Partner
                            </span>

                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="treeview">

                        <a href="#">
                            <i class="ion ion-ios-albums" aria-hidden="true"></i>
                            <span class="title">Joined Cybers</span>
                            <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                        </a>

                        <ul class="treeview-menu">

                            <li>
                                <a href="<?php echo e(url('joined-list')); ?>">
                                    <i class="fa " aria-hidden="true"></i>
                                    <span class="title">
                                All
                            </span>
                                    <span class="pull-right-container">
                                <span class="label label-primary pull-right">

                                </span>
                            </span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('join_cyber')); ?>">
                                    <i class="fa " aria-hidden="true"></i>
                                    <span class="title">
                                Add New cyber
                            </span>

                                </a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a href="<?php echo e(url('reports')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Reports
                            </span>

                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(url('rules')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Rules
                            </span>

                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(url('guides')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                Guides
                            </span>

                        </a>
                    </li>


                </ul>
            </li>




            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users_manage')): ?>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-users"></i>
                    <span class="title"><?php echo app('translator')->getFromJson('global.user-management.title'); ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">

                    <li class="<?php echo e($request->segment(2) == 'permissions' ? 'active active-sub' : ''); ?>">
                        <a href="<?php echo e(route('admin.permissions.index')); ?>">
                            <i class="fa fa-briefcase"></i>
                            <span class="title">
                                <?php echo app('translator')->getFromJson('global.permissions.title'); ?>
                            </span>
                        </a>
                    </li>
                    <li class="<?php echo e($request->segment(2) == 'roles' ? 'active active-sub' : ''); ?>">
                        <a href="<?php echo e(route('admin.roles.index')); ?>">
                            <i class="fa fa-briefcase"></i>
                            <span class="title">
                                <?php echo app('translator')->getFromJson('global.roles.title'); ?>
                            </span>
                        </a>
                    </li>
                    <li class="<?php echo e($request->segment(2) == 'users' ? 'active active-sub' : ''); ?>">
                        <a href="<?php echo e(route('admin.users.index')); ?>">
                            <i class="fa fa-user"></i>
                            <span class="title">
                                <?php echo app('translator')->getFromJson('global.users.title'); ?>
                            </span>
                        </a>
                    </li>
                </ul>
            </li>
            <?php endif; ?>

            <li class="<?php echo e($request->segment(1) == 'change_password' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('auth.change_password')); ?>">
                    <i class="fa fa-key"></i>
                    <span class="title">Change password</span>
                </a>
            </li>

            <li>
                <a href="#logout" onclick="$('#logout').submit();">
                    <i class="fa fa-arrow-left"></i>
                    <span class="title"><?php echo app('translator')->getFromJson('global.app_logout'); ?></span>
                </a>
            </li>
        </ul>
    </section>
</aside>



<?php echo Form::open(['route' => 'auth.logout', 'style' => 'display:none;', 'id' => 'logout']); ?>

<button type="submit"><?php echo app('translator')->getFromJson('global.logout'); ?></button>
<?php echo Form::close(); ?>

