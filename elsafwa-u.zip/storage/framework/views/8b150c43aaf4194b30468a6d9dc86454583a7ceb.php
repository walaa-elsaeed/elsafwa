<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>

</head>
<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<div class="container-fluid">


    <!--Content area-->
    <div class="ads-area row mar-top" style="background: #192231">

        <div class="col-md-offset-2 col-md-8 col-xs-12">
            <div class="area">

                <div class="row">
                    <div class="container cus-contain">
                        <div class="row head-media">
                            <div class="col-xs-12 btm-mar cus-12">
                                <div class="media">
                                    <div class="media-left">
                                        <a href="#" class="blue">
                                            <?php if(count($cyber->cyberImg) > 0): ?>
                                                <img class="media-object img-responsive" src="<?php echo e(url('uploads/'.$cyber->cyberImg[0]->img_url)); ?>">
                                            <?php else: ?>
                                                <img src="<?php echo e(url('img/cyber.jpg')); ?>" class="media-object img-responsive">
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading">
                                            <?php echo e($cyber->name); ?>

                                            <?php if($cyber->tourn_cyber_status() == 0): ?>
                                                <i class="fa fa-trophy join"></i>
                                            <?php elseif($cyber->tourn_cyber_status() == 1): ?>
                                                <i class="fa fa-trophy block"></i>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        </h4>

                                        <p class="mob" style="color:white">
                                            <?php if($cyber->phone != ''): ?>
                                                <?php echo e(__('strings.tel')); ?>   : <span><?php echo e($cyber->phone); ?></span>
                                            <?php endif; ?>
                                        </p>

                                        <a href="<?php echo e('https://www.google.com/maps/search/?api=1&query='.$cyber->lat.','.$cyber->long); ?>"
                                           target="_blank">
                                            <?php echo e($cyber->address); ?>

                                        </a>
                                        <h6 class="rate yellow">
                                            <?php for($i=0;$i<$cyber->rate;$i++): ?>
                                                <i class="fa fa-heart" aria-hidden="true"></i>
                                            <?php endfor; ?>
                                            <?php for($i;$i<5;$i++): ?>
                                                <i class="fa fa-heart-o" aria-hidden="true"></i>
                                            <?php endfor; ?>

                                            <span>
                                                <?php echo e('('.count($cyber->cyberRate).')'); ?>

                                            </span>
                                        </h6>
                                    </div>
                                </div>
                            </div>


                            <div class="col-md-6 col-xs-12 cus-12 galery-slider">
                                <ul id="galery-thumbs">
                                    <?php if(count($cyber->cyberImg) > 0): ?>
                                        <?php $__currentLoopData = $cyber->cyberImg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li data-thumb="<?php echo e(url('uploads/' . $image->img_url)); ?>" data-src="<?php echo e(url('uploads/' . $image->img_url)); ?>">
                                                <img src="<?php echo e(url('uploads/' . $image->img_url)); ?>" class="img-responsive"/>
                                            </li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <li data-thumb="<?php echo e(url('img/cyber.jpg')); ?>" data-src="<?php echo e(url('img/cyber.jpg')); ?>">
                                            <img src="<?php echo e(url('img/cyber.jpg')); ?>" class="img-responsive"/>
                                        </li>
                                    <?php endif; ?>



                                </ul>
                            </div>


                            <div class="col-md-6 col-xs-12 cus-12 galery-box center-details-box">
                                <div class="info">

                                    <div class="center-box">
                                        <h4 class="pull-left">
                                            <?php echo e($cyber->name); ?>

                                        </h4>

                                        <div class="clearfix"></div>
                                        <p class="address">
                                            <a href="<?php echo e('https://www.google.com/maps/search/?api=1&query='.$cyber->lat.','.$cyber->long); ?>"
                                               target="_blank">
                                                <?php echo e($cyber->address); ?>

                                            </a>
                                        </p>

                                        <p class="working-hours">
                                            <?php echo e(__('strings.work-from')); ?> <span> <?php echo e($cyber->working_from); ?></span> <?php echo e(__('strings.to')); ?> <span> <?php echo e($cyber->working_to); ?></span>
                                        </p>

                                        <p class="screens">
                                            <?php echo e(__('strings.screens')); ?> <span><?php echo e($cyber->screens_num); ?>

                                                <?php if($cyber->screens_type == 1): ?>
                                                    <?php echo e(__('strings.open')); ?>

                                                <?php elseif($cyber->screens_type == 0): ?>
                                                    <?php echo e(__('strings.room')); ?>

                                                <?php else: ?>
                                                    <?php echo e(__('strings.open&rooms')); ?>

                                                <?php endif; ?>
                                            </span>
                                        </p>

                                        <?php if(count($cyber->devices)>0): ?>

                                            <table class="device-table">
                                                <tr style="background: transparent!important;">
                                                    <th style="color: #f8d641"><?php echo e(__('strings.devices')); ?></th>
                                                    <th style="color: #f8d641"><?php echo e(__('strings.hour-price')); ?></th>
                                                </tr>
                                                <?php $__currentLoopData = $cyber->devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <?php if($cyber->devices->contains('id',$device->id)): ?>
                                                            <td><?php echo e($device->name); ?></td>
                                                            <?php if($device->price != 0): ?>
                                                                <td><?php echo e($device->price); ?></td>
                                                            <?php else: ?>
                                                                <td></td>
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                    </tr>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </table>
                                        <?php endif; ?>

                                        <div class="heart">
                                            <?php for($i=0;$i<$cyber->rate;$i++): ?>
                                                <i class="fa fa-heart" aria-hidden="true"></i>
                                            <?php endfor; ?>
                                            <?php for($i;$i<5;$i++): ?>
                                                <i class="fa fa-heart-o" aria-hidden="true"></i>
                                            <?php endfor; ?>
                                        </div>

                                        <div class="options pull-left">
                                            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($cyber->options->contains('id',$option->id)): ?>
                                                    <img src="<?php echo e(url('uploads/' . $option->img_url)); ?>">
                                                <?php else: ?>
                                                    <img src="<?php echo e(url('uploads/' . $option->img_url)); ?>" class="grayscale">
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                        
                                        <div class="clearfix"></div>
                                    </div>


                                </div>
                            </div>

                            <div class="col-xs-12 cus-12 stuff-brief">
                                <h3>
                                    <?php echo e($cyber->name); ?>

                                </h3>
                                <p>
                                    <?php echo e($cyber->description); ?>

                                </p>
                            </div>


                            <div class="col-xs-12 stuff-comment cus-12">
                                <?php if(count($cyber->cyberComment)>0): ?>
                                    <div class="coms">
                                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($comment->comment != ''): ?>
                                            <div class="media">
                                                <div class="media-left">
                                                    <a href="<?php echo e(url('user/'.$comment->user->id)); ?>" >
                                                        <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . $comment->user->img_url)); ?>">
                                                    </a>
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading"> <?php echo e('@'.$comment->user->user_name); ?></h4>
                                                    <p>
                                                        <?php echo e($comment->comment); ?>

                                                    </p>
                                                    <hr>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                                <?php endif; ?>

                                <?php if(Auth::check()): ?>

                                        <form  method="post" action=<?php echo e(url ('comment')); ?> enctype="multipart/form-data">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="media add-comment">
                                                <div class="media-left">
                                                    <a href="<?php echo e(url('user/'.Auth::user()->id)); ?>" class="blue">
                                                        <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . Auth::user()->img_url)); ?>">
                                                    </a>
                                                </div>
                                                <div class="media-body">
                                                    <?php if($alreadyRated == 0): ?>
                                                        <div class="col-xs-12 add-rate">
                                                            <div id="stars-default">
                                                                <label><?php echo e(__('strings.add-rate')); ?>: </label>
                                                                <input type=hidden name="rating"/>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>

                                                    <input type="hidden" name="cyber" value="<?php echo e($cyber->id); ?>">
                                                    <input type="hidden" name="user" value="<?php echo e(Auth::user()->id); ?>">
                                                    <textarea class="form-control" name="comment" placeholder="<?php echo e(__('strings.add-comment')); ?>"></textarea>

                                                    <button type="submit" class="btn btn-default add-stuff">
                                                        <?php echo e(__('strings.add-comment')); ?>

                                                    </button>
                                                </div>
                                            </div>
                                        </form>

                                    <?php endif; ?>

                            </div>




                        </div>



                    </div>
                </div>

            </div>
        </div>

    </div>

</div>



<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</body>
</html>
