<!--Start Header Area-->
<header>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-xs-12">
                <a href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(url('front/images/logo.png')); ?>" class="img-responsive">
                </a>
            </div>
            <div class="col-md-2 col-xs-12">
                <div class="social">
                    <a href="<?php echo e($detail->facebook); ?>">
                        <i class="fab fa-facebook-f"></i>
                    </a>

                    <a href="<?php echo e($detail->twitter); ?>">
                        <i class="fab fa-twitter"></i>
                    </a>


                    <a href="<?php echo e($detail->youtube); ?>">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>

            </div>

            <div class="col-md-4 col-xs-12">
                <div class="search_form">
                    <div class="form-group">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="بحث" onfocus="this.placeholder = ''"
                                   onblur="this.placeholder = 'بحث'" id="inputSearch">
                            <span class="input-group-addon" id="search">
                                <button class="btn btn-default" >
                                    <i class="fas fa-search"></i>
                                </button>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <nav class="navbar navbar-default">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li class="<?php echo e(Request::segment(1) === '/' ? 'active' : null); ?>">
                        <a href="<?php echo e(url('/' )); ?>" ></i> الرئيسية</a>
                    </li>

                    <li class="<?php echo e(Request::segment(1) === 'departs' ? 'active' : null); ?>">
                        <a href="<?php echo e(url('departs')); ?>">الاقسام</a>
                    </li>
                    <li class="<?php echo e(Request::segment(1) === 'news' ? 'active' : null); ?>">
                        <a href="<?php echo e(url('news')); ?>">اخبارنا</a>
                    </li>
                    <li class="<?php echo e(Request::segment(1) === 'contact' ? 'active' : null); ?>">
                        <a href="<?php echo e(url('contact')); ?>">اتصل بنا</a></li>
                    <li class="<?php echo e(Request::segment(1) === 'who_we_are' ? 'active' : null); ?>">
                        <a href="<?php echo e(url('who_we_are')); ?>">من نحن</a></li>
                    <li class="<?php echo e(Request::segment(1) === 'blogs' ? 'active' : null); ?>">
                        <a href="<?php echo e(url('blogs')); ?>">البلوج</a></li>
                </ul>

                <ul class="nav navbar-nav navbar-right">
                    <?php if(Auth::check()): ?>
                        <li>
                            <a href="<?php echo e(url('users/'.Auth::user()->id)); ?>" style="display: inline-block"><?php echo e(Auth::user()->name); ?></a>
                            <span style="color: white;font-size: 14px"><?php echo e('/'); ?></span>
                            <a href="<?php echo e(url('logout')); ?>" style="display: inline-block">خروج</a>
                        </li>
                    <?php else: ?>
                        <li><a href="<?php echo e(url('users/create')); ?>">تسجيل الدخول</a></li>
                    <?php endif; ?>

                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
</header>
<!--end Header Area-->
<a  value="<?php echo e(url('search')); ?>" id="loc" style="display: none;"></a>

