<?php $__env->startSection('lay_out'); ?>

    <div class="blog">
        <div class="container">
            <h2>
                البلوج :
            </h2>

            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6 col-xs-12">

                        <div class="blog_holder">
                            <div class="v-align">
                                <p class="text-center">
                                   <?php echo e($blog->name); ?>

                                </p>
                            </div>
                            <div class="overlay text-center">
                                <a href="<?php echo e(url('blogs/'.$blog->id)); ?>" class="v-align">
                                    المزيد
                                </a>
                            </div>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>