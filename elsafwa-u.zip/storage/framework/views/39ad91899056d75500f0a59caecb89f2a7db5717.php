<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 6%">
        <div class="col-md-offset-1 col-md-10 col-xs-12">
            <div class="box box-primary">

                <div class="box-header with-border">
                    <h3 class="box-title">
                        رساله من :
                        <a href="mailto:<?php echo e($message->mail); ?>">
                             <?php echo e($message->mail); ?>

                        </a>

                    </h3>
                </div>

                <div class="box-body">
                    <p>
                        <?php echo e($message->message); ?>

                    </p>

                    <p>
                    <h4> تم الارسال فى : </h4>
                    <?php echo e($message-> created_at); ?>

                    </p>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>