<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>

</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<div class="container-fluid">


    <!--Content area-->
    <div class="ads-area row mar-top">

        <div class="col-xs-12 cus-12">
            <div class="area profile-area">

                <div class="container">
                    <div class="row details">
                        <div class="col-sm-3 col-xs-12 cus-12">
                            <div class="image-full blue">
                                <img src="<?php echo e(url('uploads/' . $user->img_url)); ?>" class="img-responsive">
                            </div>
                        </div>
                        <div class="col-sm-8 col-xs-12 cus-12">
                            <div class="text">
                                <h2>
                                    <?php echo e('@'.$user->user_name); ?>

                                </h2>
                                <p class="mob">
                                    <?php echo e(__('strings.joined')); ?>  : <span><?php echo e($user->created_at); ?></span>
                                </p>
                                <p class="mob">
                                    <?php if($user->phone != ''): ?>
                                        <?php echo e(__('strings.mob')); ?>   : <span><?php echo e($user->phone); ?></span>
                                    <?php endif; ?>
                                </p>
                                <p class="mail">
                                    <a href="<?php echo e('mailto:'.$user->email); ?>"><?php echo e(__('strings.email')); ?> : <?php echo e($user->email); ?></a>
                                </p>

                                <h6 class="profile-rate">
                                    <?php for($i=0;$i<$user->avg_rate();$i++): ?>
                                        <i class="fa fa-heart" aria-hidden="true"></i>
                                    <?php endfor; ?>
                                    <?php for($i;$i<5;$i++): ?>
                                        <i class="fa fa-heart-o" aria-hidden="true"></i>
                                    <?php endfor; ?>
                                        <span>
                                                            <?php echo e('('.$user->number_of_trading_rates().')'); ?>

                                                        </span>

                                </h6>
                                <p class="brief">
                                    <?php echo e($user->description); ?>

                                </p>

                            </div>
                        </div>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->id ==$user->id ): ?>
                                <div class="col-sm-1 col-xs-12">
                                    <a href="<?php echo e($user->id.'/edit'); ?>" class="edit">
                                        <i class="fa fa-pencil-square-o fa-2x"></i>
                                    </a>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>
                </div>

                <div class="trading-area">

                    <?php if(count($user->cyber) > 0): ?>
                        <div class="container">
                            <h2 class="cyber-tittle">
                                <?php echo e(__('strings.cybers')); ?>:
                            </h2>
                            <div class="cybers-slider">
                                <?php $__currentLoopData = $cybers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cyber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <div class="center-box" id="box1">
                                            <h4 class="pull-left">
                                                <a href="<?php echo e(url('cyber/'.$cyber->id)); ?>">
                                                    <?php echo e($cyber->name); ?>

                                                </a>
                                            </h4>
                                            <?php if(Auth::check()): ?>

                                                <?php if(Auth::user()->id ==$user->id ): ?>
                                                    <h4 class="pull-right">
                                                        <a href="<?php echo e(url('frontcyber/'.$cyber->id.'/edit')); ?>">
                                                            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                                        </a>
                                                    </h4>
                                                <?php endif; ?>

                                            <?php endif; ?>

                                            <div class="clearfix"></div>
                                            <p class="address">
                                                <?php echo e($cyber->address); ?>

                                            </p>
                                            <div class="heart">
                                                <i class="fa fa-heart" aria-hidden="true"></i>
                                                <i class="fa fa-heart" aria-hidden="true"></i>
                                                <i class="fa fa-heart" aria-hidden="true"></i>
                                                <i class="fa fa-heart-o" aria-hidden="true"></i>
                                                <i class="fa fa-heart-o" aria-hidden="true"></i>
                                            </div>

                                            

                                            
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="row text-center">
                                <a href="<?php echo e(url('add-cyber')); ?>" class="btn btn-default add-stuff">
                                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

                                    <span>
                                        <?php echo e(__('strings.add-cyber')); ?>

                                    </span>

                                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="container">
                            <div class="row text-center">
                                <a href="<?php echo e(url('add-cyber')); ?>" class="btn btn-default add-stuff">
                                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

                                    <span>
                                        <?php echo e(__('strings.add-cyber')); ?>

                                    </span>

                                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>


                    <?php if(count($user->trade) > 0): ?>
                            <div class="container">
                                <h2 class="cyber-tittle">
                                    Trades:
                                </h2>
                                <div class="trading-slider">
                                    <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <div class="media">
                                                <div class="media-left">
                                                    <a href="" class="blue">
                                                        <img class="media-object img-responsive"src="<?php echo e(url('uploads/'.$trade->tradeImg[0]->img_url)); ?>">
                                                    </a>
                                                </div>
                                                <div class="media-body">
                                                    <h4 class="media-heading pull-left">
                                                        <a href="<?php echo e(url('trade/'.$trade->id)); ?>">
                                                            <?php echo e($trade->name); ?>

                                                        </a>
                                                    </h4>
                                                    <h4 class="media-heading pull-right trade-price">
                                                        <span><?php echo e($trade->price); ?> EG</span>
                                                    </h4>
                                                    <div class="clearfix"></div>
                                                    <h6>@ <?php echo e($trade->user['user_name']); ?></h6>
                                                    <h6 class="rate">
                                                        <?php for($i=0;$i<$trade->user->avg_rate();$i++): ?>
                                                            <i class="fa fa-heart" aria-hidden="true"></i>
                                                        <?php endfor; ?>
                                                        <?php for($i;$i<5;$i++): ?>
                                                            <i class="fa fa-heart-o" aria-hidden="true"></i>
                                                        <?php endfor; ?>
                                                    </h6>
                                                </div>
                                            </div>

                                            <div class="des">
                                                <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($operation->id == $trade->operation_id): ?>
                                                        <div class="type <?php echo e($operation->classname); ?>">
                                                            <?php echo e($operation->name); ?>

                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p>
                                                    <?php echo e($trade->description); ?>

                                                </p>

                                                <div class="gallery">
                                                    <div class="images pull-left">
                                                        <<?php $__currentLoopData = $trade->tradeImg->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <img src="<?php echo e(url('uploads/' . $img->img_url)); ?>">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                    <div class="readmore pull-right">
                                                        <a href="<?php echo e(url('trade/'.$trade->id)); ?>">
                                                            <i class="fa fa-circle" aria-hidden="true"></i>
                                                            <i class="fa fa-circle" aria-hidden="true"></i>
                                                            <i class="fa fa-circle" aria-hidden="true"></i>
                                                        </a>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                                <div class="row text-center">
                                    <a href="<?php echo e(url('add_trade')); ?>" class="btn btn-default add-stuff">
                                        <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

                                        <span>
                                        Add  Your  stuff
                                    </span>

                                        <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
                                    </a>
                                </div>
                            </div>
                    <?php else: ?>
                            <div class="container">
                                <div class="row text-center">
                                    <a href="<?php echo e(url('add_trade')); ?>" class="btn btn-default add-stuff">
                                        <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

                                        <span>
                                        Add  Your  stuff
                                    </span>

                                        <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
                                    </a>
                                </div>
                            </div>
                    <?php endif; ?>




                </div>

            </div>

        </div>
    </div>

</div>




<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>
