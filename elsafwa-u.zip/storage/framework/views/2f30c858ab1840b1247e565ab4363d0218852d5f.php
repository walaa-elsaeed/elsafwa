
<script src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.colVis.min.js"></script>
<script src="https://code.jquery.com/ui/1.11.3/jquery-ui.min.js"></script>
<script src="<?php echo e(url('adminlte/js')); ?>/bootstrap.min.js"></script>
<script src="<?php echo e(url('adminlte/js')); ?>/select2.full.min.js"></script>

<script src="<?php echo e(url('adminlte/js')); ?>/main.js"></script>

<script src="<?php echo e(url('adminlte/plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
<script src="<?php echo e(url('adminlte/plugins/fastclick/fastclick.js')); ?>"></script>
<script src="<?php echo e(url('adminlte/js/app.js')); ?>"></script>
<script>
    window._token = '<?php echo e(csrf_token()); ?>';
</script>

<script src="<?php echo e(url('adminlte/js/jquery.richtext.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('.text').richText();
    });
</script>


<script>
    //Preview img For Register
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#profile-img')
                    .attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

    function readURL2(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#profile-img-ar')
                    .attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    function readURL3(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#video_name').hide();
                $('.file').removeClass('upload-hidden');
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

</script>
<?php echo $__env->yieldContent('javascript'); ?>