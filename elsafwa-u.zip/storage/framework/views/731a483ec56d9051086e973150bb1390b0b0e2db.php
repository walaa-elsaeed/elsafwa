<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 6%">
        <div class="col-md-offset-1 col-md-10 col-xs-12">
            <div class="box box-primary">

                <div class="box-header with-border">
                    <h3 class="box-title">
                        تعديل <?php echo e($slide->name); ?>

                    </h3>
                </div>

                <form method="post" action="<?php echo e(url('admin/homeslides/'.$slide->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="box-body">

                        <div class="col-xs-12 cus-12">
                            <div class="form-group reli form-ar">
                                <label for="image">ارفع الصوره *</label>
                                <input type="file"  class="upload-hidden" name="file" style="width: 100%!important;height: 100%!important;"  onchange="readURL2(this);">
                                <div class="form-group form-ar">
                                    <img id="profile-img-ar" src="<?php echo e(url('uploads/'.$slide->img_url)); ?>" alt=""
                                         style="width: 100%;border: 1px dashed #0080c4"/>

                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="box-footer" style="text-align: left">
                        <div class="col-xs-12">
                            <button class="btn btn-primary " type="submit">
                                        <span>
                                                تعديل
                                            </span>
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>