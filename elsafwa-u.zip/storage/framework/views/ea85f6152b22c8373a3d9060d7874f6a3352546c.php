<?php $__env->startSection('lay_out'); ?>

    <div class="home-slide-container left_direction">
        <div class="home_slider">
            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <img src="<?php echo e(url('uploads/' . $slide->img_url)); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

    <div class="elsafwa_info">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-xs-12">
                    <p class="text">
                        <?php echo e($detail->description); ?>

                    </p>
                </div>
                <div class="col-md-6 col-xs-12">
                    <video playsinline autoplay  muted controls class="section-background-video" width="0" style="min-width: 100%;
   width: 100%">
                        <source src="<?php echo e(url('uploads/'.$detail->video)); ?>">
                    </video>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>