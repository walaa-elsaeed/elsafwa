<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>
</head>

<body>


<?php if($status = session::get('status')): ?>
    <div class="alert alert-info">
        <?php echo e($status); ?>

    </div>
<?php endif; ?>
<!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->

<!-- SLIDER AREA -->
<div class="top-slider">
    <ul class="tournslider">

        <?php $__currentLoopData = $header_slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header_slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <img
                        src="<?php echo e(url ('uploads')); ?>/<?php echo e($header_slide->img_url); ?>"
                        style="width: 100%"

                >
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
</div>


<div class="tourn-info">
    <div class="container">
        <div class="row">
            <div class="col-md-7 col-xs-12">
                <div class="media">
                    <div class="media-left">
                        <a href="#">
                            <img class="media-object img-responsive" src="<?php echo e(url ('uploads')); ?>/<?php echo e($tourn->img_url); ?>">
                        </a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading">
                            <?php echo e($tourn->name); ?>

                        </h4>
                    </div>
                </div>
                <div class="tourn-desc">
                    <p>
                        <?php echo e($tourn->description); ?>

                    </p>

                </div>

            </div>
            <div class="col-md-5 col-xs-12">
                <ul class="ads-slider">
                    <?php $__currentLoopData = $adds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($add->type == 0): ?>
                            <li>
                                <img  class="img-responsive" src="<?php echo e(url ('uploads')); ?>/<?php echo e($add->img_url); ?>">
                            </li>
                        <?php else: ?>
                            <li>
                                <iframe src="<?php echo e($add->src); ?>"></iframe>
                            </li>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                </ul>
            </div>
        </div>
    </div>
</div>

<div class="rules">
    <div class="container">

        <h2 class="tit">
            <span class="right-color"></span>
            <?php echo e(__('strings.tourn_phases')); ?>

        </h2>

        <br>

        <p class="phase">
            <?php echo e(__('strings.Phase_1')); ?>

        </p>

        <ul>
            <?php $__currentLoopData = $rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($rule->text); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <p class="phase">
            <?php echo e(__('strings.Phase_2')); ?>

        </p>

        <ul>
            <?php $__currentLoopData = $rules1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($rule1->text); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <p class="phase">
            <?php echo e(__('strings.Phase_3')); ?>

        </p>

        <ul>
            <?php $__currentLoopData = $rules2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($rule2->text); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>


<div class="sponser-area">
    <h2 class="text-center">
        <span class="bg"></span>
        <span class="text">
           <?php echo e(__('strings.Partners')); ?>

        </span>
    </h2>

    <div class="container">
        <div class="row">
            <div class="sponser-slider">

                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center">
                        <img  src="<?php echo e(url ('uploads')); ?>/<?php echo e($partner->img_url); ?>" class="img-responsive">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

</div>

<!-- SLIDER AREA end -->
<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>

