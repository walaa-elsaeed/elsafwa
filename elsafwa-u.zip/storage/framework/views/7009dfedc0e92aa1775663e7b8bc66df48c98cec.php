<?php $__env->startSection('lay_out'); ?>

    <div class="series_details">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="series-container">
                        <iframe src="<?php echo e($series->url); ?>"
                                frameborder="0" allow="autoplay; encrypted-media" allowfullscreen>

                        </iframe>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-6 col-xs-12">
                    <p class="commenting">
                        <span class="num-font"><?php echo e(count($series->comment)); ?></span>
                        تعليقات
                    </p>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <p class="rating">
                        <?php for($i=0;$i<$series->rate;$i++): ?>
                            <i class="fas fa-star"></i>
                        <?php endfor; ?>
                        <?php for($i;$i<5;$i++): ?>
                                <i class="far fa-star"></i>
                        <?php endfor; ?>
                    </p>
                </div>
            </div>

            <hr>

            <?php if(count($series->comment)>0): ?>
                <div class="comments">
                    <?php $__currentLoopData = $series->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="media">
                            <div class="media-left">
                                <a href="<?php echo e(url('users/'.$comment->user_id)); ?>">
                                    <div class="img-container">
                                        <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . $comment->user->img_url)); ?>" alt="profile_img">
                                    </div>
                                </a>
                            </div>
                            <div class="media-body media-middle">
                                <h4 class="media-heading"><?php echo e($comment->user->name); ?></h4>
                                <p>
                                    <?php echo e($comment->comment); ?>

                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>


            <?php if(Auth::check()): ?>
                <div class="add_comment">
                    <form  method="post" action=<?php echo e(url ('comment')); ?> enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="media">
                            <div class="media-left">
                                <a href="<?php echo e(url('users/'.Auth::user()->id)); ?>">
                                    <div class="img-container">
                                        <img class="media-object img-responsive" src="<?php echo e(url('uploads/'.Auth::user()->img_url)); ?>" alt="profile_img">
                                    </div>
                                </a>
                            </div>
                            <div class="media-body">
                                <?php if($alreadyRated == 0): ?>
                                    <div class="col-xs-12">
                                        <div id="stars-default">
                                            <label>اضف تقييم </label>
                                            <input type=hidden name="rating"/>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <input type="hidden" name="depart_series" value="<?php echo e($series->id); ?>">
                                <textarea class="form-control" name="comment" rows="3"></textarea>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-default submit-comment">
                            تعلييق
                        </button>
                    </form>
                </div>
            <?php endif; ?>



        </div>



    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>