<?php $__env->startSection('lay_out'); ?>

    <div class="depart_details">
        <div class="container">

            <div class="row">
                <div class="col-md-6 col-xs-12">
                    <h2>
                       <?php echo e($depart->name); ?> :
                    </h2>
                </div>
                <?php if(Auth::check()): ?>
                    <?php if($depart_interest): ?>
                        <div class="col-md-6 col-xs-12">
                            <form class="interested" method="post" action="<?php echo e(url('departs/'.$depart->id)); ?>" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <input type="hidden" name="depart_id" value="<?php echo e($depart->id); ?>">
                                <div class="form-group">
                                    <div class="input-group">
                                        <button class="btn btn-default" type="submit">
                                            <i class="fas fa-trash" style="color: #ffda44"></i>
                                            حذف من المفضله
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    <?php else: ?>
                        <div class="col-md-6 col-xs-12">
                            <form class="interested" method="post" action="<?php echo e(url('departs')); ?>" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="depart_id" value="<?php echo e($depart->id); ?>">
                                <div class="form-group">
                                    <div class="input-group">
                                        <button class="btn btn-default" type="submit">
                                            <img src="<?php echo e(url('front/images/add-to-favourites.png')); ?>">
                                            اضف الى المفضله
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    <?php endif; ?>

                <?php endif; ?>

            </div>

            <?php if(count($depart->depart_series)>0): ?>
                <div class="serieses">
                    <h3 class="text-center">
                        الحلقات
                    </h3>
                    <div class="slider-holder">
                        <div class="series_slider">
                            <?php $__currentLoopData = $depart->depart_series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $series): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <iframe src="<?php echo e($series->url); ?>"
                                            frameborder="0" allow="autoplay; encrypted-media" allowfullscreen>

                                    </iframe>

                                    <a href="<?php echo e(url('series/'.$series->id)); ?>">
                                        التفاصيل
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <hr>
            <?php endif; ?>

            <?php if(count($depart->depart_articles)>0): ?>

                <div class="articles">
                    <h3 class="text-center">
                        المقالات
                    </h3>
                    <div class="slider-holder">
                        <div class="article_slider">
                            <?php $__currentLoopData = $depart->depart_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <img src="<?php echo e(url('front/images/article-icon.jpg')); ?>" class="img-responsive">

                                    <div class="content text-center">
                                        <h5 class="text-center">
                                            <?php echo e($article->name); ?>

                                        </h5>
                                        <p class="text-center">
                                            <?php echo html_entity_decode($article->description); ?>

                                        </p>
                                        <a href="<?php echo e(url('depart_articles/'.$article->id)); ?>">
                                            التفاصيل
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>

                <hr>

            <?php endif; ?>

            <?php if(count($depart->depart_books)>0): ?>
                <div class="books">
                    <h3 class="text-center">
                        الكتب
                    </h3>
                    <div class="slider-holder">
                        <div class="article_slider">
                            <?php $__currentLoopData = $depart->depart_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <img src="<?php echo e(url('front/images/article-icon.jpg')); ?>" class="img-responsive">

                                    <div class="content">
                                        <h5 class="text-center">
                                            <?php echo e($book->name); ?>

                                        </h5>
                                        <p class="text-center">
                                            <?php echo e($book->description); ?>

                                        </p>
                                        <a href="<?php echo e(url('books/'.$book->id)); ?>">
                                            التفاصيل
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>




        </div>



    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>