<?php $__env->startSection('lay_out'); ?>

    <div class="news">
        <div class="container">
            <div class="row">

                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12">
                        <div class="media">
                            <div class="media-left">
                                <a href="#">
                                    <div class="img-container">
                                        <img class="media-object img-responsive" src="<?php echo e(url('uploads/'.$new->news_images[0]->img_url)); ?>" alt="new_img">
                                    </div>
                                </a>
                            </div>
                            <div class="media-body media-middle">
                                <h4 class="media-heading"><?php echo e($new->name); ?></h4>
                                <p>
                                    <?php echo html_entity_decode($new->description); ?>

                                </p>
                                <a href="<?php echo e(url('news/'.$new->id)); ?>">
                                    المزيد ...
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>