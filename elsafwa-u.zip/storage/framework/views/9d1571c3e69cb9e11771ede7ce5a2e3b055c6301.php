<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
<title>الصفوه للانتاج الفنى</title>


<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
      integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU"
      crossorigin="anonymous">
<link rel="stylesheet" href="<?php echo e(url('front/css/bootstrap-arabic.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('front/css/jquery.bxslider.css')); ?>">

<link rel="stylesheet" type="text/css" href="<?php echo e(url('front/css/slick.css')); ?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('front/css/slick-theme.css')); ?>"/>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css"/>

<link rel="stylesheet" href="<?php echo e(url('front/css/style.css')); ?>">

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>

<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('front/images/fav-icon.png')); ?>">
<link rel="apple-touch-icon" href="<?php echo e(url('front/images/fav-icon.png')); ?>"/>



