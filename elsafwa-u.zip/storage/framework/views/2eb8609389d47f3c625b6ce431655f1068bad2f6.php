<script>

</script>


<?php $__env->startSection('content'); ?>

    <table class="table table-bordered" id="users-table">
        <thead>
        <tr>
            <th>#</th>
            <th>Cyber Name</th>
            <th>User Name</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        </thead>
    </table>


<script>
        $(function() {
            $('#users-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: '<?php echo e(url('returndata')); ?>',
                columns: [
                    { data: 'rownum', name: 'rownum' },
                    { data: 'name', name: 'name' },
                    { data: 'user_name', name: 'user_name' },
                    { data: 'status', name: 'status' },
                    {data: 'action', name: 'action', orderable: false, searchable: false}
                ]
            });
        });
    </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>