<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
    </script>

    <script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>

</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<div class="container-fluid">
    <div class="row add-cyber">

        <h4 class="text-center join-tittle">
            <?php echo e(__('strings.validate_sms')); ?>

        </h4>

        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There is a problem with Your input:
                <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(url('/user_valid/'.Auth::user()->id)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

            <div class="form-group">
                <input type='hidden' value="<?php echo e(Auth::user()->sms); ?>" name="sms">
                <input type="text" class="form-control"
                       name="sms_input" placeholder="<?php echo e(__('strings.sms')); ?>"
                       maxlength="11" onkeypress="return allowNumbers(event)"
                >
            </div>

            <div class="form-group">
                <label><?php echo e(__('strings.terms')); ?> *</label>
                <textarea placeholder="Description" readonly rows="7" style="color: #555">
<?php echo e(__('strings.tourn_terms')); ?>

<?php echo e(__('strings.tourn_privacy')); ?>

                                                        </textarea>
            </div>
            <div class="checkbox">
                <label style="width: 100%;margin-right: 10px;display: inline;line-height: 44px;color: #999 !important;">
                    <input type="checkbox" required style="width: auto">
                    <?php echo e(__('strings.accept')); ?>

                    <?php echo e(__('strings.terms')); ?>

                </label>
            </div>


            <div class="buttons text-center">
                <button type="submit" class="btn btn-default join-btn"><?php echo e(__('strings.submit')); ?></button>
            </div>
        </form>

    </div>
</div>



<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</body>
</html>
