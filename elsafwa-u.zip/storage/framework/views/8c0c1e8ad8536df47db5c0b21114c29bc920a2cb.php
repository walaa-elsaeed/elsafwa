<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">

<div id="wrapper" style="background: #13486a">

<?php echo $__env->make('partials.topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Main content -->
        <section class="content">

            <div class="row" style="padding-top: 2%;padding-bottom: 4%">

                <div class=" col-md-offset-1 col-md-10 col-xs-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h5>News</h5>
                        </div>

                        <div class="panel-body">

                            <p>
                                <a class="btn btn-success" href="<?php echo e(url('add_new')); ?>">Add New</a>
                            </p>

                            <div class="tabbable">
                                <ul class="nav nav-tabs">
                                    <li class="active"><a href="<?php echo e(url('news-list')); ?>">All</a></li>
                                </ul>


                                <?php if(session()->has('message')): ?>
                                    <h1 class="alert alert-success">
                                        <?php echo e(session()->get('message')); ?>

                                    </h1>
                                <?php endif; ?>

                                <div class="tab-content" style="padding-top: 20px;padding-bottom: 20px">
                                    
                                    <div class="tab-pane active" id="tab1">
                                        <div id="w0" class="grid-view">
                                            <table class="table table-bordered" id="users-table">
                                                <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Tittle</th>
                                                    <th>source</th>
                                                    <th>Actions</th>
                                                </tr>
                                                </thead>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>


                </div>


            </div>

        </section>
    </div>
    <div class="main-footer">
        <div class="pull-right hidden-xs"></div>
        <strong>
            Copyright © 2017-2018
            <a href="http://fumestudio.com/website/" target="_blank">
                Fume Studio
            </a>
        </strong>
        All rights
        reserved.

    </div>
</div>


<?php echo Form::open(['route' => 'auth.logout', 'style' => 'display:none;', 'id' => 'logout']); ?>

<button type="submit">Logout</button>
<?php echo Form::close(); ?>




<?php echo $__env->make('partials.javascripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $('#users-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo e(url('getnews')); ?>',
        columns: [
            { data: 'DT_Row_Index', name: 'DT_Row_Index' },
            { data: 'tittle', name: 'tittle' },
            { data: 'source', name: 'source' },
            {data: 'action', name: 'action', orderable: false, searchable: false}
        ]
    });
</script>


</body>
</html>
