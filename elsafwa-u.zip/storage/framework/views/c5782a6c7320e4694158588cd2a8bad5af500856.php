<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>
</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<!--Body-->
<div class="container-fluid">


    <!--Content area-->
    <div class="ads-area row mar-top">

        <div class="col-xs-12 cus-12">
            <div class="area">

                <div class="trading-area">
                    <div class="trading-boxes">

                        <div class="container cus-width">

                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <strong>Whoops!</strong> There is a problem with Your input:
                                    <br><br>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <div class="row adding-stuff">
                                <div class="col-xs-12 cus-12">
                                    <h2>
                                        <?php echo e(__('strings.add_stuff')); ?>

                                    </h2>

                                    <p>
                                        <?php echo e(__('strings.stuff-brief')); ?>

                                        <br>
                                        <?php echo e(__('strings.stuff-lice')); ?>

                                    </p>
                                </div>

                                <div class="col-xs-12 cus-12">
                                    <form method="post"  action="<?php echo e(url('trades')); ?>" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label ><?php echo e(__('strings.tarde-title')); ?>  *</label>
                                                        <input type="text" class="form-control"  placeholder="<?php echo e(__('strings.tarde-title')); ?> " name="tittle" value="<?php echo e(old('tittle')); ?>">
                                                    </div>
                                                </div>

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('strings.select-cat')); ?>  *</label>
                                                        <div class="materialSelect inline empty ">
                                                            <ul class="select">
                                                                <input type="hidden" name="category" id="Category">
                                                                <li data-selected="true"><?php echo e(__('strings.select-cat')); ?> </li>
                                                                <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li data-value="0" value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                            <div class="message">Please select something</div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label for="government"><?php echo e(__('strings.City')); ?> *</label>
                                                        <div class="materialSelect inline empty ">
                                                            <ul class="select">
                                                                <input type="hidden" name="government" id="government">
                                                                <li data-selected="true"><?php echo e(__('strings.chose-city')); ?></li>

                                                                <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li data-value="0" value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </ul>
                                                            <div class="message">Please select something</div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label for="government"><?php echo e(__('strings.zone')); ?> *</label>
                                                        <div class="materialSelect inline empty ">
                                                            <ul class="select" id="city">
                                                                <input type="hidden" name="zone">
                                                                <a id="t" name="_token" value="<?php echo e(csrf_token()); ?>" style="display: none"></a>
                                                                <a id="u"  value="<?php echo e(url("cityCyber")); ?>" style="display: none"></a>
                                                                <li data-selected="true"><?php echo e(__('strings.chose-zone')); ?></li>


                                                            </ul>
                                                            <div class="message">Please select something</div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('strings.trade-description')); ?>   *</label>
                                                        <textarea placeholder="<?php echo e(__('strings.trade-description')); ?>" name="description"><?php echo e(old('description')); ?></textarea>
                                                    </div>
                                                </div>


                                                <div class="col-md-6 col-xs-12 cus-12">
                                                    <div class="form-group">

                                                        <label><?php echo e(__('strings.price')); ?>  *</label>
                                                        <input type="text" class="form-control"  placeholder="<?php echo e(__('strings.price')); ?>" name="price" onkeypress="return allowNumbers(event)" value="<?php echo e(old('price')); ?>">


                                                        <label class="select-ope"><?php echo e(__('strings.select-ope')); ?>  *</label>
                                                        <div class="materialSelect inline empty ">
                                                            <ul class="select">
                                                                <input type="hidden" name="operation" id="operation">
                                                                <li data-selected="true"><?php echo e(__('strings.select-ope')); ?></li>
                                                                <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li data-value="0" value="<?php echo e($operation->id); ?>"><?php echo e($operation->name); ?></li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                            <div class="message">Please select something</div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-xs-12 cus-12">
                                                    <div class="form-group">
                                                        <label for="image"><?php echo e(__('strings.upload')); ?>  *</label>
                                                        <div class="reli">
                                                            <input type="file" id="gallery-photo-add" class="upload-hidden" name="images[]" accept="jpg, gif, png" multiple>
                                                            <button class="btn btn-default upload" style="color: #999 !important">
                                                                <?php echo e(__('strings.upload')); ?>

                                                            </button>
                                                        </div>
                                                        <div class="gallery"></div>
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="row text-center reg">
                                                <button class="btn btn-default add-stuff" type="submit">
                                                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

                                                    <span>
                                        <?php echo e(__('strings.add_stuff')); ?>

                                    </span>

                                                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
                                                </button>
                                            </div>
                                        </div>
                                    </form>

                                </div>

                            </div>

                        </div>


                    </div>
                </div>

            </div>
        </div>

    </div>


</div>
<!--Body-->




<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<script>

    $(function() {
        // Multiple images preview in browser for add cyber
        var imagesPreview = function(input, placeToInsertImagePreview) {

            if (input.files) {
                var filesAmount = input.files.length;

                for (i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();

                    reader.onload = function(event) {
                        $($.parseHTML('<img>')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
                    }

                    reader.readAsDataURL(input.files[i]);
                }
            }

        };

        $('#gallery-photo-add').on('change', function() {
            imagesPreview(this, 'div.gallery');
        });
    });
</script>

</body>
</html>
