Hi <?php echo e($name); ?>,
<p> You Can change password from here</p>
<a href="<?php echo e(route('reset',$email_token)); ?>" style="color: #016eb5;text-decoration: none">
    <?php echo e('reset Your Password'); ?></a>