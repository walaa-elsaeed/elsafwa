<html>
<body style="text-align: center;background: #f0f2f5;padding:50px 30px;">
<div>
    <img src="http://thegame.com.co/staging/thegame/public/img/mail-banner.png" class="img-responsive" style=" max-width: 100%;margin: auto;">
</div>
<p class="hi-text" style="color: #1b2e3b;font-size: 20px;font-weight: bold">
    Hi <?php echo e($user_name); ?>,
</p>

<p class="info" style="color: #777777;font-size: 18px;line-height: 1.6">
    Thank you for adding your Trade. We are sorry to say that the data entered for your Trade was declined. It seems that it didn’t match the data criteria. Please check below the decline reason and try again.
</p>

<p style="color: #777777;">
    <?php echo e($decline_reason); ?>

</p>


<p class="info" style="color: #777777;font-size: 22px;line-height: 1.6;">
    We are still waiting for you to join The GAME.
</p>
<p style="color: #777777;">
    The GAME Team
</p>

<p style="text-align: center">
    <a href="https://www.facebook.com/gameofficialpage/ " target="_blank" style="text-decoration: none">
        <img src="http://thegame.com.co/staging/thegame/public/img/facebook.png" style="width: 30px;height: 30px;margin: 10px;">
    </a>

    <a href="https://www.instagram.com/gameofficialpage/ " target="_blank" style="text-decoration: none">
        <img src="http://thegame.com.co/staging/thegame/public/img/instgram.png" style="width: 30px;height: 30px;margin: 10px;">
    </a>

    <a href="https://www.youtube.com/channel/UCjcHPe1PzdoRxnl35KxM-VQ" target="_blank" style="text-decoration: none">
        <img src="http://thegame.com.co/staging/thegame/public/img/youtube.png" style="width: 30px;height: 30px;margin: 10px;">
    </a>
</p>

</body>
</html>
