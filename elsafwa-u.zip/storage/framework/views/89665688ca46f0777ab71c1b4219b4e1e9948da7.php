<?php $__env->startSection('lay_out'); ?>

    <div class="series_details">
        <div class="container">

            <div class="row book_info">
                <div class="col-xs-12">
                    <h2>
                        <?php echo e($book->name); ?> :
                    </h2>

                    <p>
                        <?php echo e($book->description); ?>


                        <br>
                        <a href="<?php echo e($book->url); ?>" class="num-font" target="_blank">
                            <i class="fas fa-angle-double-left"></i>
                            <?php echo e($book->url); ?>

                        </a>
                    </p>


                </div>
            </div>

            <div class="row">
                <div class="col-sm-6 col-xs-12">
                    <p class="commenting">
                        <span class="num-font"><?php echo e(count($book->comment)); ?></span>
                        تعليقات
                    </p>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <p class="rating">
                        <?php for($i=0;$i<$book->rate;$i++): ?>
                            <i class="fas fa-star"></i>
                        <?php endfor; ?>
                        <?php for($i;$i<5;$i++): ?>
                            <i class="far fa-star"></i>
                        <?php endfor; ?>
                    </p>
                </div>
            </div>

            <hr>

            <div class="comments">
                <?php $__currentLoopData = $book->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="media">
                        <div class="media-left">
                            <a href="<?php echo e(url('users/'.$comment->user_id)); ?>">
                                <div class="img-container">
                                    <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . $comment->user->img_url)); ?>" alt="profile_img">
                                </div>
                            </a>
                        </div>
                        <div class="media-body media-middle">
                            <h4 class="media-heading"><?php echo e($comment->user->name); ?></h4>
                            <p>
                                <?php echo e($comment->comment); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php if(Auth::check()): ?>
                <div class="add_comment">
                    <form  method="post" action=<?php echo e(url ('book_comment')); ?> enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="media">
                            <div class="media-left">
                                <a href="<?php echo e(url('users/'.Auth::user()->id)); ?>">
                                    <div class="img-container">
                                        <img class="media-object img-responsive" src="<?php echo e(url('uploads/'.Auth::user()->img_url)); ?>" alt="profile_img">
                                    </div>
                                </a>
                            </div>
                            <div class="media-body">
                                <?php if($alreadyRated == 0): ?>
                                    <div class="col-xs-12">
                                        <div id="stars-default">
                                            <label>اضف تقييم </label>
                                            <input type=hidden name="rating"/>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <input type="hidden" name="depart_book" value="<?php echo e($book->id); ?>">
                                <textarea class="form-control" name="comment" rows="3"></textarea>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-default submit-comment">
                            تعلييق
                        </button>
                    </form>
                </div>
            <?php endif; ?>


        </div>



    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>