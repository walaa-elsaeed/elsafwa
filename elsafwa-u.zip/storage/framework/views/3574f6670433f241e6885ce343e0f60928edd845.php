<?php $__env->startSection('lay_out'); ?>

    <div class="depart_details">
        <div class="container">

            <?php if(count($blogs) == 0 && count($blog_articles) == 0 && count($departs) == 0 &&
            count($depart_articles) == 0 && count($depart_books) == 0 && count($news) == 0 &&
            count($users) == 0): ?>

                <div class="row">
                    <p class="text-center">
                        لا يوجد نتائج لبحثك 
                    </p>
                </div>
            <?php else: ?>
                <div class="row">
                    <?php if(count($blogs)>0): ?>
                        <div class="blog">
                            <h2>
                                نتائج البحث فى البلوج :
                            </h2>
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-sm-6 col-xs-12">

                                    <div class="blog_holder">
                                        <div class="v-align">
                                            <p class="text-center">
                                                <?php echo e($blog->name); ?>

                                            </p>
                                        </div>
                                        <div class="overlay text-center">
                                            <a href="<?php echo e(url('blogs/'.$blog->id)); ?>" class="v-align">
                                                المزيد
                                            </a>
                                        </div>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    <?php endif; ?>

                </div>


                <div class="row">
                    <?php if(count($blog_articles)>0): ?>
                        <div class="articles">
                            <h2>
                                نتائج البحث فى مقالات البلوجات :
                            </h2>
                            <?php $__currentLoopData = $blog_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-sm-6 col-xs-12 btm-margin">
                                    <div>
                                        <img src="<?php echo e(url('front/images/article-icon.jpg')); ?>" class="img-responsive">

                                        <div class="content text-center">
                                            <h5 class="text-center">
                                                <?php echo e($article->name); ?>

                                            </h5>
                                            <p class="text-center">
                                                <?php echo html_entity_decode($article->description); ?>

                                            </p>
                                            <a href="<?php echo e(url('blog_articles/'.$article->id)); ?>">
                                                التفاصيل
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    <?php endif; ?>

                </div>


                <div class="row">
                    <?php if(count($departs)>0): ?>
                        <div class="departs">
                            <h2>
                                نتائج البحث فى الاقسام :
                            </h2>
                            <?php $__currentLoopData = $departs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-sm-6 col-xs-12">

                                    <div class="depart_holder">
                                        <div class="v-align">
                                            <img src="<?php echo e(url('uploads/'.$depart->img_url)); ?>" class="img-responsive">
                                            <p class="text-center">
                                                <?php echo e($depart->name); ?>

                                            </p>
                                        </div>
                                        <div class="overlay text-center">
                                            <a href="<?php echo e(url('departs/'.$depart->id)); ?>" class="v-align">
                                                المزيد
                                            </a>
                                        </div>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    <?php endif; ?>

                </div>


                <div class="row">
                    <?php if(count($depart_articles)>0): ?>
                        <div class="departs">
                            <h2>
                                نتائج البحث فى مقالات الاقسام :
                            </h2>
                            <?php $__currentLoopData = $depart_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-sm-6 col-xs-12 btm-margin">
                                    <div>
                                        <img src="<?php echo e(url('front/images/article-icon.jpg')); ?>" class="img-responsive" style="width: 100%">

                                        <div class="content text-center">
                                            <h5 class="text-center">
                                                <?php echo e($article->name); ?>

                                            </h5>
                                            <p class="text-center">
                                                <?php echo html_entity_decode($article->description); ?>

                                            </p>
                                            <a href="<?php echo e(url('blog_articles/'.$article->id)); ?>">
                                                التفاصيل
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    <?php endif; ?>

                </div>



                <div class="row">
                    <?php if(count($depart_books)>0): ?>
                        <div class="books">
                            <h2>
                                نتائج البحث فى كتب الاقسام :
                            </h2>
                            <?php $__currentLoopData = $depart_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-sm-6 col-xs-12 btm-margin">
                                    <div>
                                        <img src="<?php echo e(url('front/images/article-icon.jpg')); ?>" class="img-responsive" style="width: 100%">

                                        <div class="content">
                                            <h5 class="text-center">
                                                <?php echo e($book->name); ?>

                                            </h5>
                                            <p class="text-center">
                                                <?php echo e($book->description); ?>

                                            </p>
                                            <a href="<?php echo e(url('books/'.$book->id)); ?>">
                                                التفاصيل
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    <?php endif; ?>

                </div>


                <div class="row">
                    <?php if(count($news)>0): ?>
                        <div class="books">
                            <h2>
                                نتائج البحث فى الاخبار :
                            </h2>
                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-sm-6 col-xs-12 btm-margin">
                                    <div>
                                        <img src="<?php echo e(url('uploads/'.$new->news_images[0]->img_url)); ?>" class="img-responsive" style="width: 100%">

                                        <div class="content">
                                            <h5 class="text-center">
                                                <?php echo e($new->name); ?>

                                            </h5>
                                            <p class="text-center">
                                                <?php echo html_entity_decode($new->description); ?>

                                            </p>
                                            <a href="<?php echo e(url('news/'.$new->id)); ?>">
                                                التفاصيل
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    <?php endif; ?>

                </div>


                <div class="row">
                    <?php if(count($users)>0): ?>
                        <div class="books">
                            <h2>
                                نتائج البحث فى المستخدمين :
                            </h2>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-sm-6 col-xs-12 btm-margin">
                                    <div>
                                        <img src="<?php echo e(url('uploads/'.$user->img_url)); ?>" class="img-responsive" style="width: 100%">

                                        <div class="content">
                                            <h5 class="text-center">
                                                <?php echo e($user->name); ?>

                                            </h5>
                                            <a href="<?php echo e(url('users/'.$user->id)); ?>">
                                                التفاصيل
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    <?php endif; ?>

                </div>
            <?php endif; ?>




        </div>



    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>