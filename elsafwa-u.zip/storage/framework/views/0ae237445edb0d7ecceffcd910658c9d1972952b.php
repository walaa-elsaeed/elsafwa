<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>

<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Content Area-->
<div>
    <?php if(Session::has('message')): ?>
        <h1 class="alert alert-success">
            <?php echo e(Session::get('message')); ?>

        </h1>
    <?php endif; ?>
    <?php if($errors->count() > 0): ?>
        <div class="note note-danger">
            <ul class="list-unstyled">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('lay_out'); ?>
</div>

<!--Content Area-->

<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>

    var successlocation = $("#loc").attr('value');

    $('#search').click(function () {
        val = $('#inputSearch').val();
        if (val != '')
        {
            window.location.href = successlocation +'/'+ val;
        }
        else
        {
            window.location.reload();
        }

    })

</script>


</body>
</html>