<header>

    <div class="container-fluid">

        <div class="row">

            <div class="col-xs-12">
                <a href="<?php echo e(url('front')); ?>">
                    <img src="<?php echo e(url('img/logo.png')); ?>">
                </a>
            </div>

        </div>

    </div>

</header>


<div class="pm-nav-container">

    <div class="container">

        <div class="row">

            <div class="col-sm-12">

                <nav class="navbar-collapse collapse" id="pm-main-navigation">

                    <ul class="sf-menu pm-nav">

                        <li><a href="<?php echo e(url('front')); ?>" class="fa fa-home" id="pm-home-btn">
                            </a></li>

                        <li>
                            <a href="<?php echo e(url('zone')); ?>"><?php echo e(__('strings.cyberszone')); ?></a>
                        </li>


                        <li><a href="<?php echo e(url('market')); ?>"><?php echo e(__('strings.market')); ?></a></li>

                        <li><a href="<?php echo e(url('news')); ?>"><?php echo e(__('strings.news')); ?></a></li>

                        <li>
                            <?php if(Auth::check()): ?>
                                <?php if(count(Auth::user()->cyber) > 0): ?>
                                <?php else: ?>

                                    <?php if(Auth::user()->joined == 1): ?>
                                        <a href="<?php echo e(url('tournment')); ?>">Tournament</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/user_join/'.Auth::user()->id.'/edit')); ?>">Tournament</a>
                                    <?php endif; ?>
                                <?php endif; ?>


                            <?php else: ?>
                                <a href="<?php echo e(url('tournment')); ?>">Tournament</a>
                            <?php endif; ?>

                            
                        </li>





                        <?php $__currentLoopData = Config::get('languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($lang != App::getLocale()): ?>
                                <li>
                                    <a href="<?php echo e(route('lang.switch', $lang)); ?>"><?php echo e($language); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        <li class="cus-log">
                            <?php if(Auth::check()): ?>
                                <a href="<?php echo e(url('user/'.Auth::user()->id)); ?>" style="display: inline-block!important;padding: 0.75em .5em !important;">@ <?php echo e(Auth::user()->user_name); ?></a>
                                <span style="color: white;font-size: 14px"><?php echo e('/'); ?></span>
                                <a data-toggle="modal" data-target="#logoutmodal" style="display: inline-block!important;padding: 0.75em .5em !important;"><?php echo e(__('strings.logout')); ?></a>
                            <?php else: ?>
                                <a data-toggle="modal" data-target="#myModal" ><?php echo e(__('strings.login')); ?></a>
                            <?php endif; ?>


                        </li>

                    </ul>

                </nav>

            </div>

        </div>

    </div>

</div>