<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">



<?php echo SEOMeta::generate(); ?>

<?php echo OpenGraph::generate(); ?>

<?php echo Twitter::generate(); ?>



<link rel="icon" href="<?php echo e(url('img/favicon.ico')); ?>">


<?php if(App::isLocale('en')): ?>


    <link href="<?php echo e(url('css/front/bootstrap.css')); ?>" rel="stylesheet">

    <!-- main css -->
    <link href="<?php echo e(url('css/front/master.css')); ?>" rel="stylesheet">
    <!-- main css -->
    <link href="<?php echo e(url('css/front/main.css')); ?>" rel="stylesheet">

    <!-- mobile css -->
    <link href="<?php echo e(url('css/front/responsive.css')); ?>" rel="stylesheet">

    <!-- FontAwesome Support -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/front/fontawesome/font-awesome.min.css')); ?>" />
    <!-- FontAwesome Support -->


    <!-- Btns -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/front/btn.css')); ?>" />
    <!-- Btns -->


    <!-- Superfish menu -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/front/superfish/superfish.css')); ?>" />
    <!-- Superfish menu -->


    <!-- Theme Color selector -->
    <link href="<?php echo e(url('js/front/theme-color-selector/theme-color-selector.css')); ?>" type="text/css" rel="stylesheet">
    <!-- Theme Color selector -->

    <!-- Iris Color selector -->
    <link href="<?php echo e(url('css/front/iris.min.css')); ?>" type="text/css" rel="stylesheet">
    <!-- Iris Color selector -->

    <!-- WOW animations -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('js/front/wow/css/libs/animate.css')); ?>" />
    <!-- WOW animations -->

    <!-- Pulse Slider -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('js/front/pulse/pm-slider.css')); ?>" />
    <!-- Pulse Slider -->

    <!-- MeanMenu (mobile) -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('js/front/meanmenu/meanmenu.css')); ?>" />
    <!-- MeanMenu (mobile) -->

    <link rel="stylesheet" href="<?php echo e(url('css/front/slick-theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/front/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/front/jquery.timepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/front/lightslider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/front/lightgallery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/front/bootstrap-datetimepicker.css')); ?>">

    <!-- OWL CSS -->
    <link rel="stylesheet" href="<?php echo e(url('css/front/owl.carousel.css')); ?>" media="all"/>
    <link rel="stylesheet" href="<?php echo e(url('css/front/owl.theme.css')); ?>" media="all"/>
    <!-- mediaelement audio/video js style with playlist  -->

    <!--BX SLIDER-->
    <link rel="stylesheet" href="<?php echo e(url('css/front/jquery.bxslider.css')); ?>" media="all"/>
    <!--BX SLIDER-->

    <!-- Typicons -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/front/typicons/typicons.min.css')); ?>" />
    <!-- Typicons -->



    <!-- CUSTOM  CSS  -->
    <link id="cbx-style" rel="stylesheet" href="<?php echo e(url('css/front/style-default.css')); ?>" media="all"/>

    <!-- Sweet Alert   CSS  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css"/>




    <!-- MeanMenu (mobile) -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/front/style.css')); ?>" />
    <!-- MeanMenu (mobile) -->


    <!-- Development Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300italic,300,400italic,600,600italic,700,700italic,800,800italic%7COpen+Sans+Condensed:300,300italic,700%7CRaleway:400,200,300,100,600,500,700,800,900%7COswald:400,300,700%7CRoboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic%7CRoboto+Condensed:400,300,300italic,400italic,700,700italic%7CRoboto+Slab:400,100,300,700%7CLato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!-- Development Google Fonts -->






<?php elseif(App::isLocale('ar')): ?>

    <link href="<?php echo e(url('css/front/bootstrap-arabic.css')); ?>" rel="stylesheet">

    <!-- main css -->
    <link href="<?php echo e(url('css/front/master-ar.css')); ?>" rel="stylesheet">
    <!-- main css -->
    <link href="<?php echo e(url('css/front/main-ar.css')); ?>" rel="stylesheet">

    <!-- mobile css -->
    <link href="<?php echo e(url('css/front/responsive-ar.css')); ?>" rel="stylesheet">

    <!-- FontAwesome Support -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/front/fontawesome/font-awesome.min.css')); ?>" />
    <!-- FontAwesome Support -->


    <!-- Btns -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/front/btn-ar.css')); ?>" />
    <!-- Btns -->


    <!-- Superfish menu -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/front/superfish/superfish.css')); ?>" />
    <!-- Superfish menu -->


    <!-- Theme Color selector -->
    <link href="<?php echo e(url('js/front/theme-color-selector/theme-color-selector.css')); ?>" type="text/css" rel="stylesheet">
    <!-- Theme Color selector -->

    <!-- Iris Color selector -->
    <link href="<?php echo e(url('css/front/iris.min.css')); ?>" type="text/css" rel="stylesheet">
    <!-- Iris Color selector -->

    <!-- WOW animations -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('js/front/wow/css/libs/animate.css')); ?>" />
    <!-- WOW animations -->

    <!-- Pulse Slider -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('js/front/pulse/pm-slider.css')); ?>" />
    <!-- Pulse Slider -->

    <!-- MeanMenu (mobile) -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('js/front/meanmenu/meanmenu.css')); ?>" />
    <!-- MeanMenu (mobile) -->

    <link rel="stylesheet" href="<?php echo e(url('css/front/slick-theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/front/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/front/jquery.timepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/front/lightslider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/front/lightgallery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/front/bootstrap-datetimepicker.css')); ?>">

    <!-- OWL CSS -->
    <link rel="stylesheet" href="<?php echo e(url('css/front/owl.carousel.css')); ?>" media="all"/>
    <link rel="stylesheet" href="<?php echo e(url('css/front/owl.theme.css')); ?>" media="all"/>
    <!-- mediaelement audio/video js style with playlist  -->

    <!--BX SLIDER-->
    <link rel="stylesheet" href="<?php echo e(url('css/front/jquery.bxslider.css')); ?>" media="all"/>
    <!--BX SLIDER-->

    <!-- Typicons -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/front/typicons/typicons.min.css')); ?>" />
    <!-- Typicons -->



    <!-- CUSTOM  CSS  -->
    <link id="cbx-style" rel="stylesheet" href="<?php echo e(url('css/front/style-default-ar.css')); ?>" media="all"/>

    <!-- Sweet Alert   CSS  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css"/>


    <!-- MeanMenu (mobile) -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/front/style-ar.css')); ?>" />
    <!-- MeanMenu (mobile) -->


    <!-- Development Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300italic,300,400italic,600,600italic,700,700italic,800,800italic%7COpen+Sans+Condensed:300,300italic,700%7CRaleway:400,200,300,100,600,500,700,800,900%7COswald:400,300,700%7CRoboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic%7CRoboto+Condensed:400,300,300italic,400italic,700,700italic%7CRoboto+Slab:400,100,300,700%7CLato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!-- Development Google Fonts -->
<?php endif; ?>







<script src="<?php echo e(url('js/front/jquery-1.11.3.min.js')); ?>"></script>
<script src="<?php echo e(url('js/front/scroll-plugin.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>


