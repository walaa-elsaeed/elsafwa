<script
        src="https://code.jquery.com/jquery-2.2.4.min.js"
        integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
        crossorigin="anonymous"></script>

<script src="<?php echo e(url('front/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(url('front/js/jquery.bxslider.min.js')); ?>"></script>
<script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>

<script type="text/javascript" src="<?php echo e(url('front/js/slick.min.js')); ?>"></script>

<script src="<?php echo e(url('front/js/plugin.js')); ?>"></script>

<script>
    function readURL2(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#profile-img-ar')
                    .attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>