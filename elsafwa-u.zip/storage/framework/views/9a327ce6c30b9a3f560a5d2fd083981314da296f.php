<a class="map-window-holder" href="<?php echo e(url('cyber/'.$cyber['id'])); ?>">
    <div class="mapwrap">
        <div class="floated-left">
            <a href="<?php echo e(url('cyber/'.$cyber['id'])); ?>">
                <img src="uploads/<?php echo e($cyber->cyberImg[0]['img_url']); ?>" style="width: 200px!important;height: 200px!important;">
            </a>
        </div>

        <div class="floated-right">
            <div class="center-box">
                <h4 class="pull-left">
                    <?php echo e($cyber->name); ?>

                </h4>
                <div class="clearfix"></div>
                <p class="address"><?php echo e($cyber['address']); ?></p>
                <div class="heart">
                    <?php for($i=0;$i<$cyber['rate'];$i++): ?>
                        <i class="fa fa-heart" aria-hidden="true"></i>
                    <?php endfor; ?>
                    <?php for($i;$i<5;$i++): ?>
                        <i class="fa fa-heart-o" aria-hidden="true"></i>
                    <?php endfor; ?>
                </div>
                <div class="options pull-left">
                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cyber->options->contains('id',$option->id)): ?>
                            <img src="<?php echo e(url('uploads/' . $option->img_url)); ?>">
                        <?php else: ?>
                            <img src="<?php echo e(url('uploads/' . $option->img_url)); ?>" class="grayscale">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</a>