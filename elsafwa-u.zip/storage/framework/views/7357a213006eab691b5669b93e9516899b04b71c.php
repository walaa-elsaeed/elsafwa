<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>
</head>
<style>
    #cyber-card .col-md-4.col-xs-6
    {
        height: 120px!important;
    }
</style>

<script>
    function ListTourn(){
        var zone = $("#place").val();
        var state = $('#status').val();
        if(zone == undefined){
            zone = 0;
        }
        if(state == undefined){
            state = 2;
        }

        /*console.log("zone"+zone);*/
        var url = '<?php echo e(url("ajaxcyber")); ?>';
        url +='/'+zone+'/'+state;
        /*console.log("url"+url);*/

        $.ajax({
            url: url,
            type: 'get',
            data: {
            },
            success: function (data) {
                var d = JSON.parse(data);
                $("#cyber-card").html(d.htmlString);
            },
            failure: function(e){

            },
            complete: function () {

            }
        });

    }
</script>

<script>
    $(function () {
        ListTourn();
    });
</script>

<body>


<?php if($status = session::get('status')): ?>
    <div class="alert alert-info">
        <?php echo e($status); ?>

    </div>
<?php endif; ?>
<!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->

<!-- SLIDER AREA -->
<div class="top-slider">
    <ul class="tournslider">

        <?php $__currentLoopData = $header_slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header_slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <img
                        src="<?php echo e(url ('uploads')); ?>/<?php echo e($header_slide->img_url); ?>"
                        style="width: 100%"

                >
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
</div>


<div class="tourn-info">
    <div class="container">
        <div class="row">
            <div class="col-md-7 col-xs-12">
                <div class="media">
                    <div class="media-left">
                        <a href="#">
                            <img class="media-object img-responsive" src="<?php echo e(url ('uploads')); ?>/<?php echo e($tourn->img_url); ?>">
                        </a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading">
                            <?php echo e($tourn->name); ?>

                        </h4>
                    </div>
                </div>
                <div class="tourn-desc">
                    <p>
                        <?php echo e($tourn->description); ?>

                    </p>

                    <a href="<?php echo e(url('rules&regulations')); ?>">
                        <?php echo e(__('strings.rules_regulations')); ?>

                        <?php if(App::isLocale('en')): ?>
                            <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                        <?php else: ?>
                            <i class="fa fa-long-arrow-left" aria-hidden="true"></i>
                        <?php endif; ?>

                    </a>
                </div>

            </div>
            <div class="col-md-5 col-xs-12">
                <ul class="ads-slider">
                    <?php $__currentLoopData = $adds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($add->type == 0): ?>
                            <li>
                                <img  class="img-responsive" src="<?php echo e(url ('uploads')); ?>/<?php echo e($add->img_url); ?>">
                            </li>
                        <?php else: ?>
                            <li>
                                <iframe src="<?php echo e($add->src); ?>"></iframe>
                            </li>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                </ul>
            </div>
        </div>
    </div>
</div>



<div class="rank-holder">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-7 col-xs-12">
                <img src="<?php echo e(url('img/coca-cola.png')); ?>" class="img-responsive">
            </div>
            <div class="col-sm-5 col-xs-12">
                <p class="rank">
                    <?php echo e(__('strings.rank')); ?>

                    <span>
                        <?php echo e($userRanking->rank); ?>

                    </span>
                </p>
            </div>
        </div>
        <div class="row top-10">
            <div class="slashed">
            </div>
            <div class="ten-area">
                <div class="cont">
                    
                    <img class="img-responsive" src="<?php echo e(url('img/top-10.png')); ?>">
                </div>
                <div class="imgs">


                        <?php $__currentLoopData = $topTen = array_slice($ranks,0,10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bundle">
                            <div class="img-circle">
                                <a href="">
                                    <img src="<?php echo e(url('uploads/' . $top->img_url)); ?>" class="img-responsive">
                                </a>

                            </div>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                        <div class="bundle">
                            <div class="img-circle">
                                <a href="">
                                    <img src="<?php echo e(url('uploads/' . $top->img_url)); ?>" class="img-responsive">
                                </a>

                            </div>

                        </div>
                        <div class="bundle">
                            <div class="img-circle">
                                <a href="">
                                    <img src="<?php echo e(url('uploads/' . $top->img_url)); ?>" class="img-responsive">
                                </a>

                            </div>

                        </div>
                        <div class="bundle">
                            <div class="img-circle">
                                <a href="">
                                    <img src="<?php echo e(url('uploads/' . $top->img_url)); ?>" class="img-responsive">
                                </a>

                            </div>

                        </div>
                        <div class="bundle">
                            <div class="img-circle">
                                <a href="">
                                    <img src="<?php echo e(url('uploads/' . $top->img_url)); ?>" class="img-responsive">
                                </a>

                            </div>

                        </div>
                        <div class="bundle">
                            <div class="img-circle">
                                <a href="">
                                    <img src="<?php echo e(url('uploads/' . $top->img_url)); ?>" class="img-responsive">
                                </a>

                            </div>

                        </div>
                        <div class="bundle">
                            <div class="img-circle">
                                <a href="">
                                    <img src="<?php echo e(url('uploads/' . $top->img_url)); ?>" class="img-responsive">
                                </a>

                            </div>

                        </div>

                    
                </div>
            </div>
        </div>
    </div>
</div>

<div class="tabs-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-xs-12">
                <div class="tour-profile text-center">
                    <img class="media-object img-circle" src="<?php echo e(url('uploads/' . Auth::user()->img_url)); ?>">
                </div>

                <div class="profile-info">
                    <h4 class="text-center">
                        Personal Info
                    </h4>

                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xs-5">
                                <p class="tit">
                                    User Name
                                </p>
                            </div>
                            <div class="col-xs-7">
                                <p class="desci">
                                    <?php echo e(Auth::user()->user_name); ?>

                                </p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xs-5">
                                <p class="tit">
                                    Joined Date
                                </p>
                            </div>
                            <div class="col-xs-7">
                                <p class="desci">

                                    <?php echo e(Date('Y-m-d',strtotime(Auth::user()->created_at))); ?>

                                </p>
                            </div>
                        </div>

                        <div class="row ranking">
                            <div class="col-xs-5">
                                <p class="text-center">
                                    <?php echo e(__('strings.rank')); ?>

                                </p>
                            </div>
                            <div class="col-xs-7">
                                <p class="text-center">
                                    <?php echo e($userRanking->rank); ?>

                                </p>
                            </div>
                        </div>


                        <div class="result">
                            <div class="row">
                                <div class="col-xs-5">
                                    <p>
                                        Played
                                    </p>
                                </div>
                                <div class="col-xs-7">
                                    <p class="pull-right">
                                        <?php echo e(Auth::user()->score['num_of_matches']); ?>

                                    </p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-5">
                                    <p>
                                        Win
                                    </p>
                                </div>

                                <div class="col-xs-7">
                                    <p class="win pull-right">
                                        <?php echo e(Auth::user()->score['win']); ?>

                                    </p>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-xs-5">
                                    <p>
                                        Lost
                                    </p>
                                </div>
                                <div class="col-xs-7">
                                    <p class="lost pull-right">
                                        <?php echo e(Auth::user()->score['lose']); ?>

                                    </p>
                                </div>
                            </div>

                            <div class="row">

                                <div class="col-xs-5">
                                    <p>
                                        Draw
                                    </p>
                                </div>
                                <div class="col-xs-7">
                                    <p class="draw pull-right">
                                        <?php echo e(Auth::user()->score['draw']); ?>

                                    </p>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-xs-5">
                                    <p>
                                        GD
                                    </p>
                                </div>
                                <div class="col-xs-7">
                                    <p class="pull-right">
                                        <?php echo e(Auth::user()->score['g_d']); ?>

                                    </p>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-xs-5">
                                    <p>
                                        Points
                                    </p>
                                </div>
                                <div class="col-xs-7">
                                    <p class="pull-right">
                                        <?php echo e(Auth::user()->score['points']); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="point-system">
                    <h4 class="text-center">
                        <?php echo e(__('strings.Points_System')); ?>

                    </h4>

                    <div class="container-fluid">

                        <div class="result">

                            <div class="row">
                                <div class="col-xs-9">
                                    <p>
                                        Win
                                    </p>
                                </div>

                                <div class="col-xs-3">
                                    <p class="win pull-right">
                                        5
                                    </p>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-xs-9">
                                    <p>
                                        Lost
                                    </p>
                                </div>
                                <div class="col-xs-3">
                                    <p class="lost pull-right">
                                        1
                                    </p>
                                </div>
                            </div>

                            <div class="row">

                                <div class="col-xs-9">
                                    <p>
                                        Draw
                                    </p>
                                </div>
                                <div class="col-xs-3">
                                    <p class="draw pull-right">
                                        2
                                    </p>
                                </div>

                            </div>

                            <div class="row">

                                <div class="col-xs-9">
                                    <p>
                                        Over 40 match
                                    </p>
                                </div>
                                <div class="col-xs-3">
                                    <p class="draw pull-right">
                                        0
                                    </p>
                                </div>

                            </div>

                        </div>
                    </div>

                </div>

                <div class="match-system">
                    <h4 class="text-center">
                        match System
                    </h4>

                    <div class="container-fluid">

                        <div class="result">

                            <div class="row">
                                <div class="col-xs-5">
                                    <p>
                                        Win
                                    </p>
                                </div>

                                <div class="col-xs-7">
                                    <p class="win pull-right">
                                        15
                                    </p>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-xs-5">
                                    <p>
                                        Lost
                                    </p>
                                </div>
                                <div class="col-xs-7">
                                    <p class="lost pull-right">
                                        10
                                    </p>
                                </div>
                            </div>

                            <div class="row">

                                <div class="col-xs-5">
                                    <p>
                                        Draw
                                    </p>
                                </div>
                                <div class="col-xs-7">
                                    <p class="draw pull-right">
                                        2
                                    </p>
                                </div>

                            </div>

                        </div>
                    </div>

                </div>
            </div>
            <div class="col-md-9 col-xs-12">
                <div class="tabs">
                    <ul class="nav nav-tabs">
                        <li class="active point"><a href="#tab1" data-toggle="tab" class="rank-seeker">Leader Board</a></li>
                        <li class="cyber"><a href="#tab2" data-toggle="tab">Cybers List</a></li>
                        <li class="match"><a href="#tab3" data-toggle="tab">
                                My Matches <span class="count-noti"><?php echo e(Auth::user()->score['num_of_matches']); ?></span>
                            </a></li>
                        <li class="guide"><a href="#tab4" data-toggle="tab">Guide</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="tab1">
                            <div class="rank-table">
                                <table>
                                    <tr class="rank-head hidden-xs">
                                        <th>
                                            Rank
                                        </th>
                                        <th>
                                            User Name
                                        </th>
                                        <th>
                                            Played
                                        </th>
                                        <th>
                                            Win
                                        </th>
                                        <th>
                                            Lost
                                        </th>
                                        <th>
                                            Draw
                                        </th>
                                        <th>
                                            GD
                                        </th>
                                        <th>
                                            Points
                                        </th>
                                    </tr>
                                    <tr class="rank-head visible-xs">
                                        <th>
                                            R
                                        </th>
                                        <th>
                                            Player
                                        </th>
                                        <th>
                                            P
                                        </th>
                                        <th>
                                            W
                                        </th>
                                        <th>
                                            L
                                        </th>
                                        <th>
                                            D
                                        </th>
                                        <th>
                                            GD
                                        </th>
                                        <th>
                                            Pts
                                        </th>
                                    </tr>
                                    <tr></tr>
                                    <tr class="rank-elemet" style="opacity:0;">
                                        <td>
                                            <div class="rank-num">
                                                1
                                            </div>

                                        </td>

                                        <td>
                                            <div class="rank-content first-cont">
                                                <div class="media">
                                                    <div class="media-left">
                                                        <a href="" class="rank-color">
                                                            <img class="media-object img-responsive" src="<?php echo e(url('img/top-10-img.jpg')); ?>">
                                                        </a>
                                                    </div>
                                                    <div class="media-body">
                                                        <h5>
                                                            Admin
                                                        </h5>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="rank-content text-center">
                                                <span>
                                                    25
                                                </span>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="rank-content text-center">
                                                <span class="win">
                                                    15
                                                </span>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="rank-content text-center">
                                                <span class="lose">
                                                    10
                                                </span>
                                            </div>

                                        </td>

                                        <td>
                                            <div class="rank-content text-center">
                                                <span class="draw">
                                                    2
                                                </span>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="rank-content text-center">
                                                <span>
                                                    2
                                                </span>
                                            </div>

                                        </td>

                                        <td>
                                            <div class="rank-content last-cont text-center">
                                                <span>
                                                    2
                                                </span>
                                            </div>

                                        </td>


                                    </tr>
                                </table>
                                <div class="scrollable">
                                    <table style="margin-top: -30px">
                                        <tr class="rank-head hidden-xs" style="opacity:0;">
                                            <th>
                                                Rank
                                            </th>
                                            <th>
                                                User Name
                                            </th>
                                            <th>
                                                Played
                                            </th>
                                            <th>
                                                Win
                                            </th>
                                            <th>
                                                Lost
                                            </th>
                                            <th>
                                                Draw
                                            </th>
                                            <th>
                                                GD
                                            </th>
                                            <th>
                                                Points
                                            </th>
                                        </tr>
                                        <tr class="rank-head visible-xs" style="opacity:0;">
                                            <th>
                                                R
                                            </th>
                                            <th>
                                                Player
                                            </th>
                                            <th>
                                                P
                                            </th>
                                            <th>
                                                W
                                            </th>
                                            <th>
                                                L
                                            </th>
                                            <th>
                                                D
                                            </th>
                                            <th>
                                                GD
                                            </th>
                                            <th>
                                                Pts
                                            </th>
                                        </tr>
                                        <tr></tr>

                                        <?php $__currentLoopData = $ranks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($rank->user_id == Auth::user()->id): ?>
                                                <tr class="current" id="8">
                                                    <td>
                                                        <div class="rank-num">
                                                            <?php echo e($rank->rank); ?>

                                                        </div>

                                                    </td>

                                                    <td>
                                                        <div class="rank-content first-cont">
                                                            <div class="media">
                                                                <div class="media-left">
                                                                    <a href="">
                                                                        <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . $rank->img_url)); ?>">
                                                                    </a>
                                                                </div>
                                                                <div class="media-body">
                                                                    <h5>
                                                                        <?php echo e($rank->user_name); ?>

                                                                    </h5>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <td>
                                                        <div class="rank-content text-center">
                                                <span>
                                                    <?php echo e($rank->num_of_matches); ?>

                                                </span>
                                                        </div>
                                                    </td>

                                                    <td>
                                                        <div class="rank-content text-center">
                                                <span class="win">
                                                    <?php echo e($rank->win); ?>

                                                </span>
                                                        </div>
                                                    </td>

                                                    <td>
                                                        <div class="rank-content text-center">
                                                <span class="lose">
                                                    <?php echo e($rank->lose); ?>

                                                </span>
                                                        </div>

                                                    </td>

                                                    <td>
                                                        <div class="rank-content text-center">
                                                <span class="draw">
                                                    <?php echo e($rank->draw); ?>

                                                </span>
                                                        </div>
                                                    </td>

                                                    <td>
                                                        <div class="rank-content text-center">
                                                <span>
                                                    <?php echo e($rank->g_d); ?>

                                                </span>
                                                        </div>

                                                    </td>

                                                    <td>
                                                        <div class="rank-content last-cont text-center">
                                                <span>
                                                    <?php echo e($rank->points); ?>

                                                </span>
                                                        </div>

                                                    </td>


                                                </tr>
                                            <?php else: ?>
                                                <tr class="rank-elemet">
                                                    <td>
                                                        <div class="rank-num">
                                                            <?php echo e($rank->rank); ?>

                                                        </div>

                                                    </td>

                                                    <td>
                                                        <div class="rank-content first-cont">
                                                            <div class="media">
                                                                <div class="media-left">
                                                                    <a href="" class="rank-color">
                                                                        <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . $rank->img_url)); ?>">
                                                                    </a>
                                                                </div>
                                                                <div class="media-body">
                                                                    <h5>
                                                                        <?php echo e($rank->user_name); ?>

                                                                    </h5>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <td>
                                                        <div class="rank-content text-center">
                                                <span>
                                                    <?php echo e($rank->num_of_matches); ?>

                                                </span>
                                                        </div>
                                                    </td>

                                                    <td>
                                                        <div class="rank-content text-center">
                                                <span class="win">
                                                    <?php echo e($rank->win); ?>

                                                </span>
                                                        </div>
                                                    </td>

                                                    <td>
                                                        <div class="rank-content text-center">
                                                <span class="lose">
                                                    <?php echo e($rank->lose); ?>

                                                </span>
                                                        </div>

                                                    </td>

                                                    <td>
                                                        <div class="rank-content text-center">
                                                <span class="draw">
                                                    <?php echo e($rank->draw); ?>

                                                </span>
                                                        </div>
                                                    </td>

                                                    <td>
                                                        <div class="rank-content text-center">
                                                <span>
                                                    <?php echo e($rank->g_d); ?>

                                                </span>
                                                        </div>

                                                    </td>

                                                    <td>
                                                        <div class="rank-content last-cont text-center">
                                                <span>
                                                    <?php echo e($rank->points); ?>

                                                </span>
                                                        </div>

                                                    </td>


                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        


                                    </table>
                                </div>

                            </div>
                        </div>
                        <div class="tab-pane" id="tab2">
                            <div class="cybers-table">
                                <div class="row">
                                    <div class="col-sm-6 col-xs-12">
                                        <div class="materialSelect inline empty ">
                                            <ul class="select" >
                                                <input type="hidden" name="place" id="place" value="0">
                                                <li data-selected="true"><?php echo e(__('strings.City')); ?></li>
                                                <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li data-value="0" value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                            <div class="message">Please select something</div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-xs-12">
                                        <div class="materialSelect inline empty pull-right">
                                            <ul class="select" >
                                                <input type="hidden" name="status" id="status" value="2">
                                                <li data-selected="true">Status</li>

                                                <li data-value="0" value="0">Joined</li>
                                                <li data-value="0" value="1">Out Of Service</li>
                                            </ul>
                                            <div class="message">Please select something</div>
                                        </div>
                                    </div>
                                </div>


                                <div class="scrollable">
                                    <div id="cyber-card">
                                        <?php $__currentLoopData = $tourn_cybers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tourn_cyber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-4 col-sm-6 col-xs-12">
                                                <div class="cyber-item">
                                                    <div class="media">
                                                        <div class="media-left">
                                                            <a href="<?php echo e('cyber/'.$tourn_cyber->id); ?>">
                                                                <img class="media-object img-responsive" src="<?php echo e(url('uploads/'.$tourn_cyber->cyberImg[0]->img_url)); ?>">
                                                            </a>
                                                        </div>
                                                        <div class="media-body">
                                                            <?php if($tourn_cyber->tourn_cyber_status() == 0): ?>
                                                                <h5>
                                                                    <?php echo e($tourn_cyber->name); ?>

                                                                </h5>
                                                                <p class="rate">
                                                                    <?php for($i=0;$i<$tourn_cyber->tourn_rate();$i++): ?>
                                                                        <i class="fa fa-heart" aria-hidden="true"></i>
                                                                    <?php endfor; ?>
                                                                    <?php for($i;$i<5;$i++): ?>
                                                                        <i class="fa fa-heart-o" aria-hidden="true"></i>
                                                                    <?php endfor; ?>
                                                                    <span>(<?php echo e($tourn_cyber->count_tourn_rates()); ?>)</span>
                                                                </p>

                                                                <p class="add">
                                                                    <?php echo e($tourn_cyber->address); ?>

                                                                    <br>
                                                                    <?php echo e($tourn_cyber->phone); ?>

                                                                </p>
                                                            <?php elseif($tourn_cyber->tourn_cyber_status() == 1): ?>
                                                                <h5 class="cyber-gray">
                                                                    <?php echo e($tourn_cyber->name); ?>

                                                                </h5>
                                                                <p class="block-text">
                                                                    Out Of Service
                                                                </p>
                                                            <?php endif; ?>


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="tab3">
                            <div class="matches-table">
                                <table>
                                    <tr class="match-head">
                                        <th>
                                            Match
                                        </th>
                                        <th>
                                            VS
                                        </th>
                                        <th>
                                            Res
                                        </th>
                                        <th>
                                            Pts
                                        </th>
                                        <th>
                                            Cyber
                                        </th>
                                        <th>
                                            Rate
                                        </th>
                                    </tr>
                                    <tr></tr>
                                    <tr class="match-elemet" style="opacity:0;">
                                        <td>
                                            <div class="match-date">
                                                11-06
                                            </div>

                                        </td>

                                        <td>
                                            <div class="match-content first-cont">
                                                <div class="media">
                                                    <div class="media-left hidden-xs">
                                                        <a href="" class="rank-color">
                                                            <img class="media-object img-responsive" src="<?php echo e(url('img/top-10-img.jpg')); ?>">
                                                        </a>
                                                    </div>
                                                    <div class="media-body">
                                                        <h5>
                                                            Admin
                                                        </h5>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="match-content text-center">
                                                <span class="win hidden-xs">
                                                    Lose
                                                </span>
                                                <span class="win visible-xs">
                                                    L
                                                </span>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="match-content text-center">
                                                <span >
                                                    5
                                                </span>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="match-content  cyber-con text-center">
                                                <p class="cyber-name">
                                                    Cyber
                                                    <span class="rate">
                                                            <i class="fa fa-heart" aria-hidden="true"></i>
                                                            <span>
                                                                (2)
                                                            </span>
                                                        </span>
                                                </p>
                                                <a class="report" data-toggle="modal" data-target="#reportModal">
                                                    <span class="info">!</span>
                                                    report
                                                </a>
                                            </div>
                                        </td>



                                        <td>
                                            <div class="match-content last-cont text-center">
                                                <form>
                                                    <div id="stars-default-no">
                                                        <input type=hidden name="rating"/>
                                                    </div>

                                                    <button class="btn btn-default" type="submit">
                                                        Add
                                                    </button>
                                                </form>

                                            </div>

                                        </td>


                                    </tr>
                                </table>


                                <div class="scrollable">
                                    <table style="margin-top: -40px">
                                        <tr class="match-head" style="opacity:0;">
                                            <th>
                                                Match
                                            </th>
                                            <th>
                                                VS
                                            </th>
                                            <th>
                                                Res
                                            </th>
                                            <th>
                                                Pts
                                            </th>
                                            <th>
                                                Cyber
                                            </th>
                                            <th>
                                                Rate
                                            </th>
                                        </tr>
                                        <tr></tr>

                                        <?php $__currentLoopData = $matchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="match-elemet">
                                                <td>
                                                    <div class="match-date hidden-xs">
                                                        <?php echo e(Date('Y-m-d',strtotime($match->created_at))); ?>

                                                    </div>

                                                    <div class="match-date visible-xs">
                                                        <?php echo e(Date('m-d',strtotime($match->created_at))); ?>

                                                    </div>

                                                </td>

                                                <td>
                                                    <div class="match-content first-cont">
                                                        <div class="media">
                                                            <div class="media-left hidden-xs">
                                                                <?php if(Auth::user()->id == $match->player1_id ): ?>
                                                                <a href="" class="rank-color">
                                                                    <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . $match->player2['img_url'])); ?>">
                                                                </a>
                                                                <?php elseif(Auth::user()->id == $match->player2_id ): ?>
                                                                    <a href="" class="rank-color">
                                                                        <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . $match->player1['img_url'])); ?>">
                                                                    </a>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="media-body">
                                                                <h5>
                                                                    <?php if(Auth::user()->id == $match->player1_id ): ?>
                                                                        <?php echo e($match->player2['user_name']); ?>

                                                                    <?php elseif(Auth::user()->id == $match->player2_id ): ?>
                                                                        <?php echo e($match->player1['user_name']); ?>

                                                                    <?php endif; ?>
                                                                </h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="match-content text-center">

                                                    <?php if(Auth::user()->id == $match->player1_id ): ?>
                                                        <?php if($match->score1 > $match->score2): ?>
                                                            <span class="win hidden-xs">
                                                                <?php echo e('Win'); ?>

                                                            </span>
                                                                <span class="win visible-xs">
                                                                <?php echo e('W'); ?>

                                                            </span>
                                                        <?php elseif($match->score1 < $match->score2): ?>
                                                            <span class="lose hidden-xs">
                                                                <?php echo e('Lose'); ?>

                                                            </span>

                                                                <span class="lose visible-xs">
                                                                <?php echo e('L'); ?>

                                                            </span>

                                                        <?php else: ?>
                                                            <span class="draw hidden-xs">
                                                                <?php echo e('draw'); ?>

                                                            </span>

                                                            <span class="draw visible-xs">
                                                                <?php echo e('d'); ?>

                                                            </span>
                                                        <?php endif; ?>

                                                        <?php elseif(Auth::user()->id == $match->player2_id): ?>
                                                            <?php if($match->score2 > $match->score1): ?>
                                                                <span class="win hidden-xs">
                                                                <?php echo e('Win'); ?>

                                                            </span>

                                                                <span class="win visible-xs">
                                                                <?php echo e('W'); ?>

                                                            </span>
                                                            <?php elseif($match->score2 < $match->score1): ?>
                                                                <span class="lose hidden-xs">
                                                                <?php echo e('Lose'); ?>

                                                            </span>

                                                                <span class="lose visible-xs">
                                                                <?php echo e('L'); ?>

                                                            </span>

                                                            <?php else: ?>
                                                                <span class="draw hidden-xs">
                                                                <?php echo e('draw'); ?>

                                                            </span>

                                                                <span class="draw visible-xs">
                                                                <?php echo e('d'); ?>

                                                            </span>
                                                            <?php endif; ?>

                                                        <?php endif; ?>

                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="match-content text-center">
                                                <span >
                                                    <?php if(Auth::user()->id == $match->player1_id ): ?>
                                                        <?php if($match->score1 > $match->score2): ?>
                                                            <span class="win">
                                                                5
                                                            </span>
                                                        <?php elseif($match->score1 < $match->score2): ?>
                                                            <span class="lose">
                                                                1
                                                            </span>

                                                        <?php else: ?>
                                                            <span class="draw">
                                                                2
                                                            </span>
                                                        <?php endif; ?>

                                                    <?php elseif(Auth::user()->id == $match->player2_id): ?>
                                                        <?php if($match->score2 > $match->score1): ?>
                                                            <span class="win">
                                                                5
                                                            </span>
                                                        <?php elseif($match->score2 < $match->score1): ?>
                                                            <span class="lose">
                                                                1
                                                            </span>

                                                        <?php else: ?>
                                                            <span class="draw">
                                                                2
                                                            </span>
                                                        <?php endif; ?>

                                                    <?php endif; ?>
                                                </span>
                                                    </div>
                                                </td>

                                                <td>
                                                    <?php if(strtotime(Date('Y-m-d H:i')) >= strtotime(Date('Y-m-d H:i',strtotime("+ 24 hours",strtotime($match->created_at))))): ?>
                                                        <div class="match-content text-center">
                                                            <span class="cyber-name" style="font-weight: lighter">
                                                            <?php echo e($match->cyber['name']); ?>

                                                                <span class="rate">

                                                            <span>
                                                                <?php echo e($match->cyber->tourn_rate()); ?>

                                                            </span>
                                                                    <i class="fa fa-heart" aria-hidden="true"></i>
                                                        </span>
                                                        </span>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="match-content  cyber-con text-center">
                                                            <p class="cyber-name">
                                                                <?php echo e($match->cyber['name']); ?>

                                                                <span class="rate">
                                                            <i class="fa fa-heart" aria-hidden="true"></i>
                                                            <span>
                                                                (<?php echo e($match->cyber->tourn_rate()); ?>)
                                                            </span>
                                                        </span>
                                                            </p>
                                                            <a class="report" data-toggle="modal" data-target="#report<?php echo e($match->id); ?>">
                                                                <span class="info">!</span>
                                                                report
                                                            </a>

                                                            <!--reportModal -->
                                                            <div class="modal fade" id="report<?php echo e($match->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mysortModalLabel">
                                                                <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h4 class="modal-title" id="mysortModalLabel">Report Your Result !!</h4>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <!--Selectors Section-->
                                                                            <div class="row">
                                                                                <?php if(count($errors) > 0): ?>
                                                                                    <div class="alert alert-danger">
                                                                                        <strong>Whoops!</strong> There is a problem with Your input:
                                                                                        <br><br>
                                                                                        <ul>
                                                                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                <li><?php echo e($error); ?></li>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </ul>
                                                                                    </div>
                                                                                <?php endif; ?>


                                                                                <form class="cyber_form" method="post" action="<?php echo e(url('store_report')); ?>" enctype="multipart/form-data">
                                                                                    <?php echo e(csrf_field()); ?>


                                                                                    <input type="hidden" name="match" value="<?php echo e($match->id); ?>">

                                                                                    <div class="col-xs-12 cus-12">
                                                                                        <div class="form-group">
                                                                                            <textarea class="form-control report-text" placeholder="type your report" name="report" rows="5"></textarea>
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="col-xs-12 text-center reg">
                                                                                        <button class="btn btn-default add-stuff" type="submit">
                                                                                            <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

                                                                                            <span>
                                        <?php echo e(__('strings.submit')); ?>

                                    </span>

                                                                                            <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
                                                                                        </button>
                                                                                    </div>
                                                                                </form>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    <?php endif; ?>

                                                </td>



                                                <td>
                                                    <div class="match-content last-cont text-center">

                                                        <?php if($match->user_rated() == false): ?>
                                                            <form method="post" action=<?php echo e(url ('match_rate')); ?> enctype="multipart/form-data">
                                                                <?php echo e(csrf_field()); ?>

                                                                <input type="hidden" name="match" value="<?php echo e($match->id); ?>">
                                                                <input type="hidden" name="user" value="<?php echo e(Auth::user()->id); ?>">

                                                                <div id="stars-default<?php echo e($match->id); ?>">
                                                                    <input type=hidden name="rating"/>
                                                                </div>

                                                                <script>
                                                                    $(function ()
                                                                        {
                                                                            $("#stars-default<?php echo e($match->id); ?>").rating();
                                                                        }
                                                                    );

                                                                </script>

                                                                <button class="btn btn-default" type="submit">
                                                                    Add
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>

                                                    </div>

                                                </td>


                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </table>
                                </div>

                            </div>
                        </div>
                        <div class="tab-pane" id="tab4">
                            <div class="scrollable">
                                <ol class="guide_table">
                                    <?php $__currentLoopData = $guides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($guide->text); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>


<div class="sponser-area">
    <h2 class="text-center">
        <span class="bg"></span>
        <span class="text">
           <?php echo e(__('strings.Partners')); ?>

        </span>
    </h2>

    <div class="container">
        <div class="row">
            <div class="sponser-slider">

                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center">
                        <img  src="<?php echo e(url ('uploads')); ?>/<?php echo e($partner->img_url); ?>" class="img-responsive">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

</div>

<!-- SLIDER AREA end -->
<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>

