<script>
    var deletedIds = [];
    function deleteImage(imageId)
    {
        //var fd = new FormData(document.getElementById("updateCyber"));
        //fd.append('deletedImages[]',imageId);
        deletedIds.push(imageId);
        var oldValue = $('#deletedImages').val();
        $('#deletedImages').attr("value",deletedIds.join(', '));
        $('#'+imageId).remove();
    }
</script>





<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 6%">
        <div class="col-md-offset-1 col-md-10 col-xs-12">
            <div class="box box-primary">

                <div class="box-header with-border">
                    <h3 class="box-title">
                        تعديل <?php echo e($new->name); ?>

                    </h3>
                </div>

                <form method="post" action="<?php echo e(url('admin/news/'.$new->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="box-body">

                        <div class="col-xs-12 cus-12">
                            <div class="form-group form-ar">
                                <label for="name">العنوان *</label>
                                <input type="text" class="form-control" id="name"  name="tittle" style="width: 100%" value="<?php echo e($new->name); ?>">
                            </div>
                        </div>

                        <div class="col-xs-12 cus-12">
                            <div class="form-group form-ar">
                                <label for="name">التفاصيل *</label>

                                <textarea class="text" name="message">
                                    <?php echo e($new->description); ?>

                                </textarea>
                            </div>
                        </div>

                    </div>


                    <div class="col-md-6 col-xs-12 cus-12">
                        <div class="form-group reli">
                            <label for="image">ارفع الصور </label>
                            <input type="file" id="gallery-photo-add" class="upload-hidden" name="images[]"
                                   multiple accept="jpg, gif, png" value="<?php echo e(url('uploads/')); ?>.1508533048aqar-test.png"/>
                            <button class="btn btn-default upload">
                                رفع
                            </button>

                            <input type="hidden" name="deletedImages[]" id="deletedImages" />

                            <div class="gallery">
                                <?php $__currentLoopData = $new->news_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div style="position: relative;display: inline-block" id="<?php echo e($image->id); ?>">
                                        <img src="<?php echo e(url('uploads/' . $image->img_url)); ?>" style="width: 100px;height: 100px">
                                        <button type="button" class="delete-btn" value="<?php echo e($image->id); ?>" onclick="deleteImage(this.value)" style="position: absolute;top: 0;right: 0;z-index: 99999">
                                            X
                                        </button>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>



                    <div class="box-footer" style="text-align: left">
                        <div class="col-xs-12">
                            <button class="btn btn-primary " type="submit">
                                        <span>
                                                تعديل
                                            </span>
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>