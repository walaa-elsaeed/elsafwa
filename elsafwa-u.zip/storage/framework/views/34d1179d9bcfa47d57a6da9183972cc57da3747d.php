<div class="col-md-12 col-sm-6 col-xs-12">
    <div class="center-box" id="box1">
        <h4 class="pull-left">
            <a href="<?php echo e('cyber/'.$cyber->id); ?>">
                <?php echo e($cyber->name); ?>

            </a>
        </h4>
        <div class="clearfix"></div>
        <p class="address">
            <?php echo e($cyber->address); ?>

        </p>
        <div class="heart">
            <i class="fa fa-heart" aria-hidden="true"></i>
            <i class="fa fa-heart" aria-hidden="true"></i>
            <i class="fa fa-heart" aria-hidden="true"></i>
            <i class="fa fa-heart-o" aria-hidden="true"></i>
            <i class="fa fa-heart-o" aria-hidden="true"></i>
        </div>

        <div class="options pull-left">

            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cyber->options->contains('id',$option->id)): ?>
                    <img src="<?php echo e(url ('img')); ?>/<?php echo e($option->name); ?>.png">
                <?php else: ?>
                    <img src="<?php echo e(url ('img')); ?>/<?php echo e($option->name); ?>.png" class="grayscale">
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div class="price pull-right">
            <p><?php echo e($cyber->hour_price); ?><span>/ Hour</span></p>
        </div>
        <div class="clearfix"></div>
    </div>
</div>