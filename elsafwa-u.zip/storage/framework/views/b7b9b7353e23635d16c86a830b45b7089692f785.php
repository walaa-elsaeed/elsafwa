<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>
</head>

<body>


<?php if($status = session::get('status')): ?>
    <div class="alert alert-info">
        <?php echo e($status); ?>

    </div>
<?php endif; ?>
<div class="">
    <!-- Header area -->

    <!-- /Header area end -->

    <!-- Navigation area -->
    <?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Navigation area end -->

    <!-- SLIDER AREA -->

    <ul class="bxslider">
        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <img
                        src="<?php echo e(url('uploads/' . $slide->img_url)); ?>"
                        style="width: 100%"
                >
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <!-- SLIDER AREA end -->

    <!--Marque area-->
    <div class="marque-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12">
                    <?php if((App::isLocale('ar'))): ?>
                        <marquee direction="right">
                            <?php $__currentLoopData = $marquees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marquee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e($marquee->tittle); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </marquee>
                    <?php else: ?>
                        <marquee>
                            <?php $__currentLoopData = $marquees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marquee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e($marquee->tittle); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </marquee>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!--Marque area-->



</div>

<!--Body-->
<div class="animated-select">
    <div class="container-fluid">
        <div class="row">

            <?php if(Auth::check()): ?>
                <div class="col-md-4 col-xs-12 visible-xs">
                    <div class="animated">
                        <img src="<?php echo e(url('img/home/animated-4.jpg')); ?>" class="img-responsive">
                        <div class="overlay text-center">
                            <div class="hovers">
                                <a href="<?php echo e(url('tournament')); ?>" class="base">
                                    <img src="<?php echo e(url('img/home/animated-icon-4.png')); ?>" class="img-icon">
                                    <span><?php echo e(__('strings.tournament')); ?></span>
                                    <p class="disc">

                                    </p>
                                </a>
                                <a href="<?php echo e(url('tournament')); ?>" class="added">
                                    Join Now
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="col-md-4 col-xs-12 visible-xs">
                    <div class="animated">
                        <img src="<?php echo e(url('img/home/animated-4.jpg')); ?>" class="img-responsive">
                        <div class="overlay text-center">
                            <div class="hovers">
                                <a data-toggle="modal" data-target="#myModal" class="base">
                                    <img src="<?php echo e(url('img/home/animated-icon-4.png')); ?>" class="img-icon">
                                    <span><?php echo e(__('strings.tournament')); ?></span>
                                    <p class="disc">

                                    </p>
                                </a>
                                <a data-toggle="modal" data-target="#myModal" class="added">
                                    Join Now
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>



            <div class="col-md-4 col-xs-12">
                <div class="animated">
                    <img src="<?php echo e(url('img/home/animated-1.jpg')); ?>" class="img-responsive">
                    <div class="overlay text-center">
                        <div class="hovers">
                            <a href="<?php echo e(url('zone')); ?>" class="base">
                                <img src="<?php echo e(url('img/home/animated-icon-1.png')); ?>" class="img-icon">
                                <span><?php echo e(__('strings.cybersmap')); ?></span>
                                <p class="disc">
                                    <?php echo e(__('strings.find-map')); ?>

                                </p>
                            </a>
                            <a href="<?php echo e(url('zone')); ?>" class="added">
                                <?php echo e(__('strings.locate')); ?>

                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-12">
                <div class="animated">
                    <img src="<?php echo e(url('img/home/animated-2.jpg')); ?>" class="img-responsive">
                    <div class="overlay text-center">
                        <div class="hovers">
                            <a href="<?php echo e(url('market')); ?>" class="base">
                                <img src="<?php echo e(url('img/home/animated-icon-2.png')); ?>" class="img-icon">
                                <span><?php echo e(__('strings.market')); ?></span>
                                <p class="disc">
                                    <?php echo e(__('strings.find-market')); ?>

                                    <br>
                                    <?php echo e(__('strings.start_tarde')); ?>

                                </p>
                            </a>
                            <a href="<?php echo e(url('market')); ?>" class="added">
                                <?php echo e(__('strings.trade')); ?>

                            </a>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-12">
                <div class="animated">
                    <img src="<?php echo e(url('img/home/animated-3.jpg')); ?>" class="img-responsive">
                    <div class="overlay text-center">
                        <div class="hovers">
                            <a href="<?php echo e(url('news')); ?>" class="base">
                                <img src="<?php echo e(url('img/home/animated-icon-3.png')); ?>" class="img-icon">
                                <span><?php echo e(__('strings.news')); ?></span>
                                <p class="disc">
                                    <?php echo e(__('strings.find-news')); ?>

                                </p>
                            </a>
                            <a href="<?php echo e(url('news')); ?>" class="added">
                                <?php echo e(__('strings.what-new')); ?>

                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Body-->




<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
