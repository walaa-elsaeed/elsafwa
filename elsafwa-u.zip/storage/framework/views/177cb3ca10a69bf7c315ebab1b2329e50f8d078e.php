<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>

</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<div class="container-fluid">


    <p>
        Some Thing Went Wrong,Be right back Soon
    </p>

</div>



<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>
