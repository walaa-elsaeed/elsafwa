<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>
</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<div class="container">

    <!--Zone Section-->
    <div class="row zone mar-top">
        <div class="col-md-4 col-xs-12">
            <div class="row boxses">
                <div class="col-xs-12 ">
                    <div class="left-selects">

                        <h3 class="pull-left"><?php echo e(__('strings.search')); ?></h3>
                        
                        <div class="clearfix"></div>
                        <div class="materialSelect inline empty pull-left">
                            <ul class="select" name="governmentSearch">
                                <input type="hidden" name="government" id="government" value="0">
                                <li data-selected="true"><?php echo e(__('strings.City')); ?></li>
                                <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li data-value="0" value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <div class="message">Please select something</div>
                        </div>
                        <div class="materialSelect inline empty pull-left second-select">
                            <ul class="select" id="city" name="citySearch">
                                <input type="hidden" id="zone" name="zone" value="0">

                                <a id="t" name="_token" value="<?php echo e(csrf_token()); ?>" style="display: none"></a>

                                <a id="u"  value="<?php echo e(url("cityCyber")); ?>" style="display: none"></a>

                                <li data-selected="true"><?php echo e(__('strings.zone')); ?></li>
                            </ul>
                            <div class="message">Please select something</div>
                        </div>
                        <div class="clearfix"></div>
                    </div>

                </div>
                <div class="col-xs-12">
                    <a id="uC"  value="<?php echo e(url("cyberSearch")); ?>" style="display: none"></a>
                    <input type="hidden" id="lat" value="30.062593">
                    <input type="hidden" id="lng" value="31.360670">
                    <input type="hidden" id="rad" value="5000">
                    <div class="row" id="cybers">

                        

                    </div>
                </div>

            </div>

            <div class="row pagi" >
                <nav aria-label="Page navigation">
                    <input type="hidden" id="page" value="0">
                    <ul class="pagination" id="pagi">
                    </ul>


                </nav>
            </div>
        </div>



        <div class="col-md-8 col-xs-12 map" style="min-height: 500px!important;">
            <div class="map-fixed">
                <div id="mapContainer">
                    <div id="map_canvas"></div>
                </div>
            </div>
        </div>
    </div>


    <div class="row text-center">
        <a href="<?php echo e(url('add-cyber')); ?>" class="btn btn-default add-stuff">
            <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

            <span>
                                        <?php echo e(__('strings.add-cyber')); ?>

                                    </span>

            <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
        </a>
    </div>
</div>



<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
