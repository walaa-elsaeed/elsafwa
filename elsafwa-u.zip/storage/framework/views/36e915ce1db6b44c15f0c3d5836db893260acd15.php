<!--Login Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel"><?php echo e(__('strings.member')); ?></h4>
            </div>
            <div class="modal-body">

                <form method="post" action=<?php echo e(url ('log')); ?>>
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <input type="text" class="form-control" name="username" placeholder="&#xf2c0; <?php echo e(__('strings.username')); ?>">
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="Password" placeholder="&#xf023; <?php echo e(__('strings.password')); ?>">
                    </div>

                    <div class="checkbox">
                        <label>
                            <input type="checkbox"> <span><?php echo e(__('strings.remember')); ?></span>
                        </label>
                    </div>
                    <div class="buttons text-center">
                        <button type="submit" class="btn btn-default login"><?php echo e(__('strings.login')); ?></button>
                        <a class="btn btn-default" href="<?php echo e(url('registration')); ?>"><?php echo e(__('strings.sign_up')); ?></a>
                    </div>
                </form>
                <div class="forget-pass">
                        <span>
                            <?php echo e(__('strings.forget')); ?>

                        </span>
                    <form class="password-form" action="<?php echo e('send_password'); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="email" placeholder="<?php echo e(__('strings.enter_mail')); ?>" name="forget_pass_mail">
                        <button  type="submit" class="btn btn-default">OK</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>


<!--Logout Modal -->
<div class="modal fade" id="logoutmodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabe2">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel"><?php echo e(__('strings.logout-model')); ?></h4>
            </div>
            <div class="modal-body">
                <div class="buttons text-center">
                    <a href="<?php echo e(url('out')); ?>" class="btn btn-default login"><?php echo e(__('strings.logout')); ?>

                    </a>
                    <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">
                        <?php echo e(__('strings.exit')); ?>

                    </button>
                </div>
            </div>

        </div>
    </div>
</div>

