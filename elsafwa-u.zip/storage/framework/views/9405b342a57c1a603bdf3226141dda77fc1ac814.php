<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>
</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<!--Body-->
<div class="container-fluid">


    <!--Content area-->
    <div class="row  mar-top">

        <div class="col-xs-12">
            <div class="cbx-top-background">
                <div class="cbx-breaking">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="cbx-breaking-inner-full">
                                    <div class="cbx-breaking-heading">
                                        <span><?php echo e(__('strings.news')); ?></span>
                                    </div>
                                    <div class="cbx-breaking-inner">
                                        <ul id="nt-example2">
                                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li data-infos="<?php echo e($new->tittle); ?>">
                                                    <?php if(App::isLocale('en')): ?>
                                                        <i class="fa fa-fw fa-play state"></i>
                                                    <?php elseif(App::isLocale('ar')): ?>
                                                        <i class="fa fa-fw fa-play state fa-rotate-180"></i>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(url('new/'.$new['id'])); ?>"><?php echo e($new->tittle); ?></a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!--//.col-->
                        </div>
                        <!--//.Row-->
                    </div>
                    <!--//.CONTAINER-->
                </div>
                <!--//.BREAKING-->


                <div id="cbx-slider" class="cbx-section cbx-slider">
                    <div class="cbx-inner cbx-slider-inner">
                        <div class="container">
                            <div class="row">
                                <div class="col-xs-12">
                                    <div id="home-slider" class="owl-carousel custom-owl">
                                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="item" data-title="<?php echo e($new->tittle); ?>"
                                                 data-thumb="<?php echo e(url('uploads/' . $new->img_url)); ?>">
                                                <div class="row">
                                                    <div class="col-xs-12 col-md-7">
                                                        <figure>
                                                            <a href="<?php echo e(url('new/'.$new['id'])); ?>">
                                                                <img src="<?php echo e(url('uploads/' . $new->img_url)); ?>"
                                                                     alt="<?php echo e($new->tittle); ?>">
                                                            </a>
                                                            <figcaption>
                                                        <span>
                                                            <a class="category-icon" href="#">
                                                                <i class="fa fa-file-text" aria-hidden="true"></i>
                                                            </a>
                                                        </span>
                                                            </figcaption>
                                                        </figure>
                                                    </div>
                                                    <!--COl-->
                                                    <div class="col-xs-12 col-md-5">
                                                        <h2 class="cpmedium-header">
                                                            <a href="<?php echo e(url('new/'.$new['id'])); ?>"><?php echo e($new->tittle); ?></a>
                                                        </h2>

                                                        <div class="slider-text">
                                                            <p>
                                                                <?php echo e($new->description); ?>

                                                            </p>
                                                        </div>

                                                        <p class="sub-heading"><?php echo e(__('strings.from')); ?>

                                                            <span>
                                                                <a href="<?php echo e($new->source); ?>" target="_blank">
                                                                    <?php echo e($new->source); ?>

                                                                </a>
                                                            </span>
                                                        </p>

                                                    </div>
                                                    <!--//Col-->
                                                </div>
                                                <!--ROW-->
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <!-- //owl-carousel-->
                                </div>
                                <!-- //COL12 -->
                            </div>
                            <!-- //ROW -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="container">
        <div class="row blog-content">
            <!-- Blog post area -->
            <?php $__currentLoopData = $paginews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paginew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-xs-12">
                    <!-- Blog post -->
                    <article>
                        <div class="pm-blog-post-container">

                            <div class="pm-blog-post-img-container" style="background-image:url(<?php echo e(url('uploads/' . $paginew->img_url)); ?>)">

                                <div class="pm-blog-post-date">

                                    <p class="pm-month">
                                        <?php echo e($paginew->created_at->format('M')); ?>

                                    </p>
                                    <p class="pm-day">
                                        <?php echo e($paginew->created_at->format('d')); ?>

                                    </p>

                                    <div class="pm-blog-post-comment-count">
                                        <p><?php echo e(count($paginew->newsComment)); ?></p>
                                    </div>

                                </div>
                                <div class="pm-blog-post-title">
                                    <h2 class="pm-post-title"><?php echo e($paginew->tittle); ?></h2>
                                    <p class="pm-post-hover-excerpt"><?php echo e($paginew->description); ?></p>
                                    <a href="<?php echo e(url('new/'.$paginew['id'])); ?>"><?php echo e(__('strings.read_more')); ?> &rarr;</a>
                                </div>

                            </div>

                            <div class="pm-blog-post-details-container">

                                <p class="pm-blog-post-published">
                                    <?php echo e($paginew->created_at); ?>

                                </p>

                                <div class="pm-blog-post-divider"></div>


                                <div class="pm-rounded-btn pm-blog-post-btn">
                                    <a href="<?php echo e(url('new/'.$paginew['id'])); ?>"><?php echo e(__('strings.read_more')); ?></a>
                                </div>

                            </div>

                        </div>
                    </article>
                    <!-- Blog post end -->
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Blog post area end -->
        </div>





        <div class="row pagi">
            <nav aria-label="Page navigation">
                <?php echo e($paginews->links()); ?>

            </nav>
        </div>

    </div>





</div>
<!--Body-->



<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>
