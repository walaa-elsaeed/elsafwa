<?php $request = app('Illuminate\Http\Request'); ?>
<!-- Left side column. contains the sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <ul class="sidebar-menu">

            <li class="<?php echo e($request->segment(1) == 'home' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/admin/home')); ?>">
                    <i class="fa fa-wrench"></i>
                    <span class="title">لوحه التحكم</span>
                </a>
            </li>


            <li class="treeview">

                <a href="#">
                    <i class="ion ion-home" aria-hidden="true"></i>
                    <span class="title">الصفحه الرئيسيه</span>
                    <i class="fa fa-angle-left pull-left"></i>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('admin/homeslides')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                الاسليدر
                            </span>
                            <span class="pull-left-container">
                                <span class="label label-primary pull-left">
                                    <?php echo e($departs_count); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('admin/homedetails')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                التفاصيل
                            </span>

                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('admin/messages')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                           الرسائل
                            </span>
                            <span class="pull-left-container">
                                <span class="label label-yellow pull-left">

                                </span>
                            </span>
                        </a>
                    </li>



                </ul>
            </li>



            <li class="treeview">

                <a href="#">
                    <i class="ion ion-home" aria-hidden="true"></i>
                    <span class="title">الاقسام</span>
                    <i class="fa fa-angle-left pull-left"></i>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('admin/departs')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                كل الاقسام
                            </span>
                            <span class="pull-left-container">
                                <span class="label label-primary pull-left">
                                    <?php echo e($departs_count); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('admin/serieses')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                كل الحلقات
                            </span>
                            <span class="pull-left-container">
                                <span class="label label-success pull-left">
                                    <?php echo e($departs_series_count); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('admin/articles')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                كل المقالات
                            </span>
                            <span class="pull-left-container">
                                <span class="label label-yellow pull-left">
                                    <?php echo e($departs_articles_count); ?>

                                </span>
                            </span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(url('admin/books')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                كل الكتب
                            </span>
                            <span class="pull-left-container">
                                <span class="label label-red pull-left">
                                    <?php echo e($departs_books_count); ?>

                                </span>
                            </span>
                        </a>
                    </li>


                </ul>
            </li>



            <li class="treeview">

                <a href="#">
                    <i class="ion ion-ios-game-controller-b" aria-hidden="true"></i>
                    <span class="title">الاخبار</span>
                    <i class="fa fa-angle-left pull-left"></i>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('admin/news')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                كل الاخبار
                            </span>
                            <span class="pull-left-container">
                                <span class="label label-primary pull-left">
                                    <?php echo e($news_count); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="treeview">

                <a href="#">
                    <i class="ion ion-android-notifications-none" aria-hidden="true"></i>
                    <span class="title">البلوج</span>
                    <i class="fa fa-angle-left pull-left"></i>
                </a>

                <ul class="treeview-menu">

                    <li>
                        <a href="<?php echo e(url('admin/blogs')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                كل البلوج
                            </span>
                            <span class="pull-left-container">
                                <span class="label label-primary pull-left">
                                    <?php echo e($blogs_count); ?>

                                </span>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('admin/blog_articles')); ?>">
                            <i class="fa " aria-hidden="true"></i>
                            <span class="title">
                                كل المقالات
                            </span>
                            <span class="pull-left-container">
                                <span class="label label-yellow pull-left">
                                    <?php echo e($blogs_article_count); ?>

                                </span>
                            </span>
                        </a>
                    </li>

                </ul>
            </li>


            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users_manage')): ?>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-users"></i>
                    <span class="title"><?php echo app('translator')->getFromJson('global.user-management.title'); ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">

                    <li class="<?php echo e($request->segment(2) == 'permissions' ? 'active active-sub' : ''); ?>">
                        <a href="<?php echo e(route('admin.permissions.index')); ?>">
                            <i class="fa fa-briefcase"></i>
                            <span class="title">
                                <?php echo app('translator')->getFromJson('global.permissions.title'); ?>
                            </span>
                        </a>
                    </li>
                    <li class="<?php echo e($request->segment(2) == 'roles' ? 'active active-sub' : ''); ?>">
                        <a href="<?php echo e(route('admin.roles.index')); ?>">
                            <i class="fa fa-briefcase"></i>
                            <span class="title">
                                <?php echo app('translator')->getFromJson('global.roles.title'); ?>
                            </span>
                        </a>
                    </li>
                    <li class="<?php echo e($request->segment(2) == 'users' ? 'active active-sub' : ''); ?>">
                        <a href="<?php echo e(route('admin.users.index')); ?>">
                            <i class="fa fa-user"></i>
                            <span class="title">
                                <?php echo app('translator')->getFromJson('global.users.title'); ?>
                            </span>
                        </a>
                    </li>
                </ul>
            </li>
            <?php endif; ?>

            

            <li>
                <a href="#logout" onclick="$('#logout').submit();">
                    <i class="fa fa-arrow-left"></i>
                    <span class="title">تسجيل الخروج</span>
                </a>
            </li>
        </ul>
    </section>
</aside>



<?php echo Form::open(['route' => 'auth.logout', 'style' => 'display:none;', 'id' => 'logout']); ?>

<button type="submit"><?php echo app('translator')->getFromJson('global.logout'); ?></button>
<?php echo Form::close(); ?>

