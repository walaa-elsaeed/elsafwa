<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>

</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<div class="container-fluid">


    <!--Content area-->
    <div class="ads-area row mar-top trading-details" style="background: #192231">

        <div class="col-md-offset-2 col-md-8 col-xs-12">
            <div class="area">

                <div class="row">
                    <div class="container cus-contain">
                        <div class="row head-media">
                            <div class="col-xs-12 btm-mar">
                                <div class="media">
                                    <div class="media-left">
                                        <a href="#" class="blue">
                                            <img class="media-object img-responsive" src="<?php echo e(url('uploads/'.$trade->tradeImg[0]->img_url)); ?>">
                                        </a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading">
                                            <?php echo e($trade->name); ?>

                                            <span class="trade-price">
                                                <?php echo e($trade->price); ?> EG
                                            </span>
                                        </h4>
                                        <a href="<?php echo e(url('user/'.$trade->user_id)); ?>">@ <?php echo e($trade->user_name); ?></a>

                                        <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($operation->id == $trade->operation_id): ?>
                                                <div class="type <?php echo e($operation->classname); ?>">
                                                    <?php echo e($operation->name); ?>

                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($zone->id == $trade->city_id): ?>
                                                <div class="city">
                                                    <?php echo e($zone->name); ?>

                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($device->id == $trade->category_id): ?>
                                                <div class="city">
                                                    <?php echo e($device->name); ?>

                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <h6 class="rate">
                                            <?php for($i=0;$i<$trade->user->avg_rate();$i++): ?>
                                                <i class="fa fa-heart" aria-hidden="true"></i>
                                            <?php endfor; ?>
                                            <?php for($i;$i<5;$i++): ?>
                                                <i class="fa fa-heart-o" aria-hidden="true"></i>
                                            <?php endfor; ?>
                                                <span>
                                                            <?php echo e('('.$trade->user->number_of_trading_rates().')'); ?>

                                                        </span>
                                        </h6>
                                        </h6>
                                    </div>
                                </div>
                            </div>


                            <div class="col-md-6 col-xs-12 galery-box">
                                <img src="<?php echo e(url('uploads/'.$trade->tradeImg[0]->img_url)); ?>" class="img-responsive" id="ownslider">
                            </div>


                            <div class="col-md-6 col-xs-12 galery-box">
                                <div class="galery-thums">
                                    <?php $__currentLoopData = $trade->tradeImg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(url('uploads/' . $image->img_url)); ?>" onclick="slide(this);">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>

                            <div class="col-xs-12 stuff-brief">
                                <h3>
                                    <?php echo e($trade->name); ?>

                                </h3>
                                <p>
                                    <?php echo e($trade->description); ?>

                                </p>
                            </div>

                            <div class="col-xs-12 stuff-comment cus-12">
                                <?php if(count($trade->tradeComment)>0): ?>
                                    <div class="coms">
                                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($comment->comment != ''): ?>
                                                <div class="media">
                                                    <div class="media-left">
                                                        <a href="<?php echo e(url('user/'.$comment->user->id)); ?>" >
                                                            <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . $comment->user->img_url)); ?>">
                                                        </a>
                                                    </div>
                                                    <div class="media-body">
                                                        <h4 class="media-heading"> <?php echo e('@'.$comment->user->user_name); ?></h4>
                                                        <p>
                                                            <?php echo e($comment->comment); ?>

                                                        </p>
                                                        <hr>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>
                                <?php endif; ?>

                                <?php if(Auth::check()): ?>

                                    <form  method="post" action=<?php echo e(url ('trade_comment')); ?> enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="media add-comment">
                                            <div class="media-left">
                                                <a href="<?php echo e(url('user/'.Auth::user()->id)); ?>" class="blue">
                                                    <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . Auth::user()->img_url)); ?>">
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <?php if($alreadyRated == 0): ?>
                                                    <div class="col-xs-12 add-rate">
                                                        <div id="stars-default">
                                                            <label><?php echo e(__('strings.add-rate')); ?>: </label>
                                                            <input type=hidden name="rating"/>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <input type="hidden" name="trade" value="<?php echo e($trade->id); ?>">
                                                <input type="hidden" name="user" value="<?php echo e(Auth::user()->id); ?>">
                                                <textarea class="form-control" name="comment" placeholder="<?php echo e(__('strings.add-comment')); ?>"></textarea>

                                                <button type="submit" class="btn btn-default add-stuff">
                                                    <?php echo e(__('strings.add-comment')); ?>

                                                </button>
                                            </div>
                                        </div>
                                    </form>

                                <?php endif; ?>

                            </div>



                        </div>


                    </div>
                </div>

            </div>
        </div>

    </div>

</div>



<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<script>
    function slide(e) {
        x = e.getAttribute("src");
        $('#ownslider').attr("src",x);

    }
</script>

</body>
</html>
