<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<script>
    var dataTable;
    function gettradesAdmin(zone) {
        $.ajax({
            url: '<?php echo e(url("citytradesAdmin")); ?>',
            type: 'post',
            data: {
                city_id: zone,
                _token : $('#t').attr('value')

            },
            success: function (data) {
                console.log(data);
                var d = JSON.parse(data);
                $('#cities_filter').children('option').remove();
                $('#cities_filter').append("<option disabled selected>select city</option>");
                for (var i = 0; i < d.length; i++) {
                    $('#cities_filter').append("<option  value='"+d[i].id+"'>"+d[i].name+"</option>");
                }
            },
            failure/*error*/: function(e){

            },
            complete: function () {
                updateTable();
            }
        });
    }



    function getoperationTrade(ope) {
        $.ajax({
            url: '<?php echo e(url("tradesAdmin")); ?>',
            type: 'post',
            data: {
                operation_id:ope,
                _token : $('#t').attr('value')

            },
            success: function (data) {
                console.log(data);
                var d = JSON.parse(data);
            },
            failure/*error*/: function(e){

            },
            complete: function () {
                updateTable();
            }
        });
    }

    function getCatTrade(cat) {
        $.ajax({
            url: '<?php echo e(url("tradesCat")); ?>',
            type: 'post',
            data: {
                category_id:cat,
                _token : $('#t').attr('value')

            },
            success: function (data) {
                console.log(data);
                var d = JSON.parse(data);
            },
            failure/*error*/: function(e){

            },
            complete: function () {
                updateTable();
            }
        });
    }
    function updateTable(){
        var zone = $("#zone_filter").val();
        var city = $("#cities_filter").val();
        var ope = $('#operation_filter').val();
        var cat = $('#category_filter').val();
        if(zone == undefined){
            zone = 0;
        }
        if (city == undefined){
            city = 0;
        }
        if(ope == undefined){
            ope = 0;
        }
        if(cat == undefined){
            cat = 0;
        }
        console.log("zone"+zone);
        console.log("city"+city);
        var url = '<?php echo e(url("returntradesdecline")); ?>';
        url +='/'+zone+'/'+city+'/'+ope+'/'+cat;
        console.log("url"+url);
        dataTable.ajax.url( url ).load();
    }


</script>


<body class="hold-transition skin-blue sidebar-mini">

<div id="wrapper" style="background: #13486a">

<?php echo $__env->make('partials.topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Main content -->
        <section class="content">
            <div class="row" style="padding-top: 2%;padding-bottom: 4%">

                <div class="col-md-offset-1 col-md-10 col-xs-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h5>Trades</h5>
                        </div>

                        <div class="panel-body">

                            <div class="tabbable">
                                <ul class="nav nav-tabs">
                                    <li ><a href="<?php echo e(url('alltrades')); ?>">All</a></li>
                                    <li ><a href="<?php echo e(url('pendingtrades')); ?>">Pending</a></li>
                                    <li ><a href="<?php echo e(url('approvetrades')); ?>">Approved</a></li>
                                    <li class="active"><a href="<?php echo e(url('declinetrades')); ?>">Decline</a></li>
                                </ul>

                                <?php if(session()->has('message')): ?>
                                    <h1 class="alert alert-success">
                                        <?php echo e(session()->get('message')); ?>

                                    </h1>
                                <?php endif; ?>


                                <div class="tab-content" style="padding-top: 20px;padding-bottom: 20px">

                                    <div class="search-inputs">
                                        <a id="t" name="_token" value="<?php echo e(csrf_token()); ?>" style="display: none"></a>
                                        <div class="col-md-2 col-xs-4">
                                            <span>Filter By:</span>
                                        </div>
                                        <div class="clearfix"></div>

                                        <div class="col-md-3 col-xs-4">
                                            <select id="zone_filter" onchange="gettradesAdmin(this.value)">
                                                <option disabled selected>Select a government</option>
                                                <?php $__currentLoopData = $allzones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-3  col-xs-4">
                                            <select id="cities_filter" onchange="updateTable()">
                                                <option disabled selected>Select a city</option>
                                            </select>
                                        </div>


                                        <div class="col-md-3 col-xs-4">
                                            <select id="operation_filter" onchange="getoperationTrade(this.value)">
                                                <option disabled selected>Select an Operation</option>
                                                <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($operation->id); ?>"><?php echo e($operation->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-3  col-xs-4">
                                            <select id="category_filter" onchange="getCatTrade(this.value)">
                                                <option disabled selected>Select a Category</option>
                                                <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="tab-pane active" id="tab1">
                                        <div id="w0" class="grid-view">
                                            <table class="table table-bordered" id="users-table">
                                                <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Trade Name</th>
                                                    <th>User Name</th>
                                                    <th>Price</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                                </thead>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>


                </div>


            </div>

        </section>
    </div>
    <div class="main-footer">
        <div class="pull-right hidden-xs"></div>
        <strong>
            Copyright © 2017-2018
            <a href="http://fumestudio.com/website/" target="_blank">
                Fume Studio
            </a>
        </strong>
        All rights
        reserved.

    </div>
</div>


<?php echo Form::open(['route' => 'auth.logout', 'style' => 'display:none;', 'id' => 'logout']); ?>

<button type="submit">Logout</button>
<?php echo Form::close(); ?>




<?php echo $__env->make('partials.javascripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(function() {
        dataTable = $('#users-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: '<?php echo e(url('returntradesdecline')); ?>'+'/0/0/0/0',
            columns: [
                { data: 'DT_Row_Index', name: 'DT_Row_Index' },
                { data: 'name', name: 'name' },
                { data: 'user_name', name: 'user_name' },
                { data: 'price', name: 'price' },
                { data: 'status', name: 'status', orderable: false, searchable: false },
                {data: 'action', name: 'action', orderable: false, searchable: false}
            ]
        });
        updateTable();
    });
</script>



</body>
</html>
