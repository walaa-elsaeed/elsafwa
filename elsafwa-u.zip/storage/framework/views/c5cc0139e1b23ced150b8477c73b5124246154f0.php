<script src="<?php echo e(url('js/front/scroll-plugin.js')); ?>"></script>
<script src="<?php echo e(url('js/front/plugin.js')); ?>"></script>
<script src="<?php echo e(url('js/front/thegame.js')); ?>"></script>