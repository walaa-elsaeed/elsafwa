<?php $__env->startSection('lay_out'); ?>

    <div class="news">
        <div class="container new_details">

            <div class="new-slider_container left_direction">
                <div class="new_slider">
                    <?php $__currentLoopData = $imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <img src="<?php echo e(url('uploads/'.$img->img_url)); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>


        <div class="new_info">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="article-container">
                            <?php echo html_entity_decode($info->description); ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>



    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>