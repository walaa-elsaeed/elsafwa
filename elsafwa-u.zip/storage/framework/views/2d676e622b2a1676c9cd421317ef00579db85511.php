<div class="container-fluid">

    <p style="color: red">
        Some Thing Went Wrong,Be right back Soon
    </p>

</div>