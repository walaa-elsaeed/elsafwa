
<script src="<?php echo e(url('js/front/jquery.viewport.mini.js')); ?>"></script>
<script src="<?php echo e(url('js/front/jquery.easing.1.3.js')); ?>"></script>
<script src="<?php echo e(url('js/front/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('js/front/modernizr.custom.js')); ?>"></script>
<script src="<?php echo e(url('js/front/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(url('js/front/jquery.bxslider.min.js')); ?>"></script>
 <script src="<?php echo e(url('js/front/main.js')); ?>"></script>



<script src="<?php echo e(url('js/front/jquery.tooltip.js')); ?>"></script>
<script src="<?php echo e(url('js/front/jquery.hoverPanel.js')); ?>"></script>
<script src="<?php echo e(url('js/front/superfish/superfish.js')); ?>"></script>
<script src="<?php echo e(url('js/front/superfish/hoverIntent.js')); ?>"></script>
<script src="<?php echo e(url('js/front/tinynav.js')); ?>"></script>
<script src="<?php echo e(url('js/front/stellar/jquery.stellar.js')); ?>"></script>
<script src="<?php echo e(url('js/front/pulse/jquery.PMSlider.js')); ?>"></script>
<script src="<?php echo e(url('js/front/meanmenu/jquery.meanmenu.min.js')); ?>"></script>
<script src="<?php echo e(url('js/front/theme-color-selector/theme-color-selector.js')); ?>"></script>
<script src="<?php echo e(url('js/front/wow/wow.min.js')); ?>"></script>

<script src="<?php echo e(url('js/front/search-map.js')); ?>"></script>
<script src="<?php echo e(url('js/front/slick.js')); ?>"></script>
<script src="<?php echo e(url('js/front/dropzone.js')); ?>"></script>
<script src="<?php echo e(url('js/front/moment.js')); ?>"></script>
<script src="<?php echo e(url('js/front/bootstrap-datetimepicker.js')); ?>"></script>

<script src="<?php echo e(url('js/front/jquery.smooth-scroll.min.js')); ?>"></script>
<!-- News Ticker -->
<script src="<?php echo e(url('js/front/jquery.newsTicker.min.js')); ?>"></script>
<script src="<?php echo e(url('js/front/newsz.js')); ?>"></script>
<script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('js/front/jquery.timepicker.js')); ?>"></script>
<script src="<?php echo e(url('js/front/lightslider.js')); ?>"></script>
<script src="<?php echo e(url('js/front/lightgallery.js')); ?>"></script>
<script src="<?php echo e(url('js/front/jquery.nicescroll.js')); ?>"></script>
<script src="<?php echo e(url('js/front/plugin.js')); ?>"></script>
<script src="<?php echo e(url('js/front/thegame.js')); ?>"></script>

