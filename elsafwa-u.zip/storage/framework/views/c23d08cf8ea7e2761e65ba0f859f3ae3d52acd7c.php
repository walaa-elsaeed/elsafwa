<?php $__env->startSection('content'); ?>
    <div class="row" style="margin-top: 2%">

        <div class=" col-xs-offset-1 col-xs-10">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h5>Cybers</h5>
                </div>

                <div class="panel-body">

                    <p>
                        <a class="btn btn-success" href="<?php echo e(url('cyber')); ?>">Add Cyber</a>
                    </p>

                    <table class="table table-bordered" id="users-table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Cyber Name</th>
                            <th>User Name</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                    </table>

                </div>
            </div>


        </div>


    </div>

    <script>
        $(function() {
            $('#users-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: '<?php echo e(url('returndata')); ?>',
                columns: [
                    { data: 'rownum', name: 'rownum' },
                    { data: 'name', name: 'name' },
                    { data: 'user_name', name: 'user_name' },
                    { data: 'status', name: 'status' },
                    {data: 'action', name: 'action', orderable: false, searchable: false}
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>