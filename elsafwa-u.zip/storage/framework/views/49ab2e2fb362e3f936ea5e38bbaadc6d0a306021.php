<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&callback=initialize&libraries=places">
    </script>
</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<!--Body-->
<div class="container-fluid">


    <!--Content area-->
    <div class="ads-area row mar-top">

        <div class="col-md-offset-3 col-md-6 col-xs-12 details-con cus-12">
            <!-- Single Blog post -->
            <div class="pm-single-blog-post-img-container" style="background-image:url(<?php echo e(url('uploads/' . $new->img_url)); ?>)">
                <div class="pm-single-blog-post-date">
                    <p class="pm-month">
                        <?php echo e($new->created_at->format('M')); ?>

                    </p>
                    <p class="pm-day">
                        <?php echo e($new->created_at->format('d')); ?>

                    </p>
                </div>
                <div class="pm-single-blog-post-title">
                    <p class="pm-post-title"><?php echo e($new->tittle); ?></p>
                </div>
            </div>


            <blockquote class="comunity-block">
                <p><?php echo e($new->description); ?></p>
            </blockquote>

            <p class="comunity-details-p">
                <?php echo e(__('strings.from')); ?>

                <span>
                    <a href="<?php echo e($new->source); ?>" target="_blank"><?php echo e($new->source); ?></a>
                </span>
            </p>


            <!-- Single Blog post content end -->


        </div>

    </div>
    <div class="container det-container">
        <div class="row">
            <div class="col-xs-12 stuff-comment cus-12">
                <?php if(count($new->newsComment)>0): ?>
                    <div class="coms">
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($comment->comment != ''): ?>
                                <div class="media">
                                    <div class="media-left">
                                        <a href="<?php echo e(url('user/'.$comment->user->id)); ?>" >
                                            <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . $comment->user->img_url)); ?>">
                                        </a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading"> <?php echo e('@'.$comment->user->user_name); ?></h4>
                                        <p>
                                            <?php echo e($comment->comment); ?>

                                        </p>
                                        <hr>
                                    </div>
                                </div>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                <?php endif; ?>

                <?php if(Auth::check()): ?>

                    <form  method="post" action=<?php echo e(url ('new-comment')); ?> enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="media add-comment">
                            <div class="media-left">
                                <a href="<?php echo e(url('user/'.Auth::user()->id)); ?>" class="blue">
                                    <img class="media-object img-responsive" src="<?php echo e(url('uploads/' . Auth::user()->img_url)); ?>">
                                </a>
                            </div>
                            <div class="media-body">

                                <input type="hidden" name="new" value="<?php echo e($new->id); ?>">
                                <input type="hidden" name="user" value="<?php echo e(Auth::user()->id); ?>">
                                <textarea class="form-control" name="comment" placeholder="<?php echo e(__('strings.add-comment')); ?>"></textarea>

                                <button type="submit" class="btn btn-default add-stuff">
                                    <?php echo e(__('strings.add-comment')); ?>

                                </button>
                            </div>
                        </div>
                    </form>

                <?php endif; ?>
            </div>


        </div>
    </div>

</div>
<!--Body-->



<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</body>
</html>
