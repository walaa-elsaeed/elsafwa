<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 2%;padding-bottom: 4%">

        <div class="col-md-offset-1 col-md-10 col-xs-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h5>تفاصيل الصفحه الرئيسيه</h5>
                </div>

                <div class="panel-body">
                    <div class="tabbable">

                        <div class="tab-content" style="padding-top: 20px;padding-bottom: 20px">
                            <div class="tab-pane active" id="tab1">
                                <div id="w0" class="grid-view">
                                    <table class="table table-bordered" style="overflow-x: auto">
                                        <thead>
                                        <tr>
                                            <th>الوصف</th>
                                            <th>الفديو</th>
                                            <th>العنوان</th>
                                            <th>الموقع</th>
                                            <th>فيس بوك</th>
                                            <th>تويتر</th>
                                            <th>يوتيوب</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($detail->description); ?></td>
                                                <td>
                                                    <a target="_blank" href="<?php echo e(url('uploads/'.$detail->video)); ?>">
                                                        <?php echo e($detail->video); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e($detail->address); ?></td>
                                                <td style="
                                                overflow-wrap: break-word;
                                                  word-wrap: break-word;
                                                  -ms-word-break: break-all;
                                                  word-break: break-all;
                                                  word-break: break-word;
                                                  -ms-hyphens: auto;
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  hyphens: auto;

                                                 ">
                                                    <?php echo e($detail->location); ?>

                                                </td>
                                                <td>
                                                    <a target="_blank" href="<?php echo e($detail->facebook); ?>">
                                                        <?php echo e($detail->facebook); ?>

                                                    </a>
                                                </td>
                                                <td>
                                                    <a target="_blank" href="<?php echo e($detail->twitter); ?>">
                                                        <?php echo e($detail->twitter); ?>

                                                    </a>
                                                </td>
                                                <td>
                                                    <a target="_blank" href="<?php echo e($detail->youtube); ?>">
                                                        <?php echo e($detail->youtube); ?>

                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(url('/admin/homedetails/'.$detail->id.'/edit')); ?>" class="btn btn-primary">
                                                        تعديل
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>


    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>