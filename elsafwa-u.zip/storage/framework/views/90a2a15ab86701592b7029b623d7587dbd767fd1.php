<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
    </script>

    <script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>

</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<div class="container-fluid">
    <div class="row add-cyber">

        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There is a problem with Your input:
                <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

            <?php if(Auth::user()->phone == null): ?>
                <h4 class="text-center join-tittle">You must enter your phone number</h4>
            <?php else: ?>
                <h4 class="text-center join-tittle"><?php echo e(__('strings.sure_number')); ?></h4>
            <?php endif; ?>

            <form method="post" action="<?php echo e(url('/user_join/'.Auth::user()->id)); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <div class="form-group">
                    <input type="text" class="form-control"
                           name="phone" placeholder="<?php echo e(__('strings.Phone')); ?>"
                           value="<?php echo e(Auth::user()->phone); ?>"
                           maxlength="11" onkeypress="return allowNumbers(event)"
                    >
                </div>
                <div class="buttons text-center">
                    <button type="submit" class="btn btn-default join-btn"><?php echo e(__('strings.submit')); ?></button>
                </div>
            </form>

    </div>
</div>



<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</body>
</html>
