<?php $__env->startSection('content'); ?>
    <div class="row" style="padding: 20px 15px 0">
        <div class="col-xs-12">
            <div class="content-header">
                <h1>
                    Dashboard
                    <small>Control panel</small>
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <a href="">
                            <i class="fa fa-dashboard"></i>
                            Home
                        </a>
                    </li>
                    <li class="active">
                        <a href="">
                            Dashboard
                        </a>
                    </li>
                </ol>
            </div>
        </div>

    </div>

    <div class="row" style="padding: 20px 15px 0">
        <div class="col-xs-12"  style="margin-bottom: 20px">
            <h1>
                Accounts :
            </h1>
        </div>
        <div class="col-md-6 col-xs-12">
            <!-- USERS LIST -->
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h3 class="box-title">Latest Members</h3>

                    <div class="box-tools pull-right">
                        <span class="label label-danger">8 New Members</span>
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                        </button>
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body no-padding">
                    <ul class="users-list clearfix">

                        <?php $__currentLoopData = $members->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>

                                <img src="<?php echo e(url('uploads/'.$member->img_url)); ?>" alt="User Image" style="width: 112px;height: 112px">
                                <a class="users-list-name" href="#"><?php echo e($member->user_name); ?></a>
                                <span class="users-list-date"><?php echo e(Date('Y-m-d',strtotime($member->created_at))); ?></span>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <!-- /.users-list -->
                </div>
                <!-- /.box-body -->
                <div class="box-footer text-center">
                    <a href="<?php echo e(url('members')); ?>" class="uppercase">View All Users</a>
                </div>
                <!-- /.box-footer -->
            </div>
            <!--/.box -->
        </div>
        <!-- /.col -->

        <div class="col-md-6 col-xs-12">

            <!-- TABLE: LATEST ORDERS -->
            <div class="box box-info">
                <div class="box-header with-border">
                    <h3 class="box-title">Latest Admins</h3>

                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table no-margin">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Mail</th>
                                    <th>Role</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $admins->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><a href=""><?php echo e($admin->user_name); ?></a></td>
                                        <td><?php echo e($admin->email); ?></td>

                                        <?php if($admin->user_type == 1): ?>
                                            <td><span class="label label-success"><?php echo e('Admin'); ?></span></td>
                                        <?php elseif($admin->user_type == 2): ?>
                                            <td><span class="label label-warning"><?php echo e('Cyber Admin'); ?></span></td>
                                        <?php elseif($admin->user_type == 3): ?>
                                            <td><span class="label label-info"><?php echo e('Trade Admin'); ?></span></td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.table-responsive -->
                </div>
                <!-- /.box-body -->
                <div class="box-footer clearfix">
                    <a href="<?php echo e(url('add_account')); ?>" class="btn btn-sm btn-info btn-flat pull-left">Add New Admin</a>
                    <a href="<?php echo e(url('admins')); ?>" class="btn btn-sm btn-default btn-flat pull-right">View All Admins</a>
                </div>
                <!-- /.box-footer -->
            </div>
            <!-- /.box -->

        </div>

    </div>
    <!-- /.col -->

    <div class="row" style="padding: 20px 15px 0">
        <div class="col-xs-12"  style="margin-bottom: 20px">
            <h1>
                Tournament :
            </h1>
        </div>
        <div class="col-md-6 col-xs-12">
            <!-- Widget: user widget style 1 -->
            <div class="box box-widget widget-user">
                <!-- Add the bg color to the header using any of the bg-* classes -->
                <div class="widget-user-header bg-black" style="background: url('<?php echo e(url('img/photo1.jpg')); ?>') center center;">

                </div>
                <div class="widget-user-image">
                    <img class="img-circle" src="<?php echo e(url('img/user3-128x128.png')); ?>" alt="User Avatar">
                </div>
                <div class="box-footer">
                    <div class="row">
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                                <h5 class="description-header"><?php echo e($players); ?></h5>
                                <span class="description-text">Player</span>
                                <br>
                                <a href="<?php echo e(url('players')); ?>" class="uppercase">
                                    View All Players
                                </a>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                                <h5 class="description-header"><?php echo e($tourn_cybers); ?></h5>
                                <span class="description-text">Cyber</span>
                                <br>
                                <a href="<?php echo e(url('joined-list')); ?>" class="uppercase">
                                    View All Cybers
                                </a>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4">
                            <div class="description-block">
                                <h5 class="description-header"><?php echo e($matches); ?></h5>
                                <span class="description-text">Match</span>
                                <br>
                                <a href="<?php echo e(url('matches-list')); ?>" class="uppercase">
                                    View All Matches
                                </a>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->

                </div>
            </div>
            <!-- /.widget-user -->
        </div>
        <!-- /.col -->
    </div>


    <div class="row" style="padding: 20px 15px 0">
        <div class="col-xs-12"  style="margin-bottom: 20px">
            <h1>
                Home :
            </h1>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <?php echo e($allslides); ?>

                    </h3>
                    <p>All Slides</p>
                </div>
                <div class="icon">
                    <i class="ion ion-ios-browsers"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('slider')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-green">
                <div class="inner">
                    <h3>
                        <?php echo e($allmarquees); ?>

                    </h3>
                    <p>All News</p>
                </div>
                <div class="icon">
                    <i class="ion ion-arrow-move"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('marquee')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>


        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3>
                        <?php echo e($allmsg); ?>

                    </h3>
                    <p>All Messages</p>
                </div>
                <div class="icon">
                    <i class="ion ion-email-unread"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('messages')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

    </div>



    <div class="row" style="padding: 20px 15px 0">
        <div class="col-xs-12"  style="margin-bottom: 20px">
            <h1>
                Cybers :
            </h1>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <?php echo e(count($allcybers)); ?>

                    </h3>
                    <p>All Cybers</p>
                </div>
                <div class="icon">
                    <i class="ion ion-ios-game-controller-b"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('cybers')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-green">
                <div class="inner">
                    <h3>
                        <?php echo e(count($approved)); ?>

                    </h3>
                    <p>Approved Cybers</p>
                </div>
                <div class="icon">
                    <i class="ion ion-checkmark-round"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('cybers-approved')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>


        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3>
                        <?php echo e(count($pendings)); ?>

                    </h3>
                    <p>Pending Cybers</p>
                </div>
                <div class="icon">
                    <i class="ion ion-load-a"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('cybers-pending')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-red">
                <div class="inner">
                    <h3>
                        <?php echo e(count($decline)); ?>

                    </h3>
                    <p>Decline Cybers</p>
                </div>
                <div class="icon">
                    <i class="ion ion-close-round"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('cybers-decline')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
    </div>


    <div class="row" style="padding: 20px 15px 0">
        <div class="col-xs-12"  style="margin-bottom: 20px">
            <h1>
                Market :
            </h1>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <?php echo e($alltrades); ?>

                    </h3>
                    <p>All Stuffs</p>
                </div>
                <div class="icon">
                    <i class="ion ion-ios-cart"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('alltrades')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-green">
                <div class="inner">
                    <h3>
                        <?php echo e($alltradesapproved); ?>

                    </h3>
                    <p>Approved Stuffs</p>
                </div>
                <div class="icon">
                    <i class="ion ion-checkmark-round"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('approvetrades')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>


        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3>
                        <?php echo e($alltradespending); ?>

                    </h3>
                    <p>Pending Stuffs</p>
                </div>
                <div class="icon">
                    <i class="ion ion-load-a"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('pendingtrades')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-red">
                <div class="inner">
                    <h3>
                        <?php echo e($alltradesdecline); ?>

                    </h3>
                    <p>Decline Stuffs</p>
                </div>
                <div class="icon">
                    <i class="ion ion-close-round"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('declinetrades')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
    </div>

    <div class="row" style="padding: 20px 15px 0">
        <div class="col-xs-12"  style="margin-bottom: 20px">
            <h1>
                News :
            </h1>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <?php echo e(count($allnews)); ?>

                    </h3>
                    <p>All News</p>
                </div>
                <div class="icon">
                    <i class="ion ion-android-notifications-none"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('news-list')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

    </div>


    <div class="row" style="padding: 0 15px 20px">
        <div class="col-xs-12"  style="margin-bottom: 20px">
            <h1>
                Locations :
            </h1>
        </div>

        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <?php echo e(count($allzones)); ?>

                    </h3>
                    <p>All Citys</p>
                </div>
                <div class="icon">
                    <i class="ion ion-ios-location"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('citys')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>



        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <?php echo e(count($allcitys)); ?>

                    </h3>
                    <p>All Zones</p>
                </div>
                <div class="icon">
                    <i class="ion ion-ios-location"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('zones')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>



    </div>

    <div class="row" style="padding: 0 15px 20px">
        <div class="col-xs-12"  style="margin-bottom: 20px">
            <h1>
                Others :
            </h1>
        </div>



        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>
                        <?php echo e(count($alloptions)); ?>

                    </h3>
                    <p>All Options</p>
                </div>
                <div class="icon">
                    <i class="ion ion-levels"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('options')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>


        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-green">
                <div class="inner">
                    <h3>
                        <?php echo e(count($alldevices)); ?>

                    </h3>
                    <p>All Devices</p>
                </div>
                <div class="icon">
                    <i class="ion ion-ipad"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('devices')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>



        <div class="col-md-3 col-xs-6">
            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3>
                        <?php echo e($alloperations); ?>

                    </h3>
                    <p>All operations</p>
                </div>
                <div class="icon">
                    <i class="ion ion-ios-albums"></i>
                </div>
                <a class="small-box-footer" href="<?php echo e(url('operations')); ?>">
                    More info
                    <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>