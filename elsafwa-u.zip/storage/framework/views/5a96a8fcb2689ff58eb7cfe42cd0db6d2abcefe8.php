<?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 col-sm-6 col-xs-12">
        <div class="btm-br">
            <div class="media">
                <div class="media-left">
                    <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($operation->id == $trade->operation_id): ?>
                            <a href="<?php echo e('trade/'.$trade->id); ?>" class="<?php echo e($operation->classname); ?>">
                                <img class="media-object img-responsive" src="<?php echo e(url('uploads/'.$trade->tradeImg[0]->img_url)); ?>">
                            </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="media-body">
                    <h4 class="media-heading pull-left">
                        <a href="<?php echo e('trade/'.$trade->id); ?>">
                            <?php echo e($trade->name); ?>

                        </a>
                    </h4>
                    <h4 class="media-heading pull-right trade-price">
                        <span><?php echo e($trade->price); ?> <?php echo e(__('strings.eg')); ?></span>
                    </h4>
                    <div class="clearfix"></div>
                    <a href="<?php echo e(url('user/'.$trade->user_id)); ?>">@ <?php echo e($trade->user['user_name']); ?></a>
                    <h6 class="rate">
                        <?php for($i=0;$i<$trade->user->avg_rate();$i++): ?>
                            <i class="fa fa-heart" aria-hidden="true"></i>
                        <?php endfor; ?>
                        <?php for($i;$i<5;$i++): ?>
                            <i class="fa fa-heart-o" aria-hidden="true"></i>
                        <?php endfor; ?>
                            <span>
                               <?php echo e('('.$trade->user->number_of_trading_rates().')'); ?>

                            </span>
                    </h6>
                </div>
            </div>

            <div class="des">
                <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($operation->id == $trade->operation_id): ?>
                        <div class="type <?php echo e($operation->classname); ?>">
                            <?php echo e($operation->name); ?>

                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <p>
                    <?php echo e($trade->description); ?>

                </p>

                <div class="gallery">
                    <div class="images pull-left">
                        <?php $__currentLoopData = $trade->tradeImg->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(url('uploads/' . $img->img_url)); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                    <div class="readmore pull-right">
                        <a href="<?php echo e('trade/'.$trade->id); ?>">
                            <i class="fa fa-circle" aria-hidden="true"></i>
                            <i class="fa fa-circle" aria-hidden="true"></i>
                            <i class="fa fa-circle" aria-hidden="true"></i>
                        </a>
                    </div>
                    <div class="clearfix">
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>