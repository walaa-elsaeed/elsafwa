<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('front.common.heading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <span style="display: none">;</span>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
    </script>

    <script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>

</head>

<body>

<div >

    <!-- Navigation area -->
<?php echo $__env->make('front.common.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation area end -->



</div>

<div class="container-fluid">
    <div class="row add-cyber">

        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There is a problem with Your input:
                <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


        <form class="cyber_form" method="post" action="<?php echo e('zone'); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                    <label for="name"><?php echo e(__('strings.name')); ?> *</label>
                    <input type="text" class="form-control" id="name" placeholder="<?php echo e(__('strings.name')); ?>" name="name" value="<?php echo e(old('name')); ?>">
                </div>
            </div>

            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                    <label for="Phone"><?php echo e(__('strings.Phone')); ?></label>
                    <input type="text" class="form-control" id="Phone" placeholder="<?php echo e(__('strings.Phone')); ?>"
                           name="phone" maxlength="11" onkeypress="return allowNumbers(event)" value="<?php echo e(old('phone')); ?>">
                </div>
            </div>


            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                <label for="government"><?php echo e(__('strings.City')); ?> *</label>
                <div class="materialSelect inline empty ">
                    <ul class="select">
                        <input type="hidden" name="government" id="government">
                        <li data-selected="true"><?php echo e(__('strings.chose-city')); ?></li>

                        <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-value="0" value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                    <div class="message">Please select something</div>
                </div>
            </div>
            </div>

            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                <label for="government"><?php echo e(__('strings.zone')); ?> *</label>
                <div class="materialSelect inline empty ">
                    <ul class="select" id="city">
                        <input type="hidden" name="zone">
                        <a id="t" name="_token" value="<?php echo e(csrf_token()); ?>" style="display: none"></a>
                        <a id="u"  value="<?php echo e(url("cityCyber")); ?>" style="display: none"></a>
                        <li data-selected="true"><?php echo e(__('strings.chose-zone')); ?></li>


                    </ul>
                    <div class="message">Please select something</div>
                </div>
            </div>
            </div>


            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                    <label><?php echo e(__('strings.working-from')); ?> *</label>
                    <input type="text" class="form-control" id="workhourfrom" placeholder="<?php echo e(__('strings.working-from')); ?>" name="hourFrom" value="<?php echo e(old('hourFrom')); ?>">
                </div>
            </div>

            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                    <label> <?php echo e(__('strings.working-to')); ?> *</label>
                    <input type="text" class="form-control" id="workhourto" placeholder="<?php echo e(__('strings.working-to')); ?>" name="hourTo" value="<?php echo e(old('hourTo')); ?>">
                </div>
            </div>




            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                    <label for="screens"><?php echo e(__('strings.screens-num')); ?> *</label>
                    <input type="text" placeholder="<?php echo e(__('strings.screens-num')); ?>" class="screen-num form-control" name="screenNum" onkeypress="return allowNumbers(event)" value="<?php echo e(old('screenNum')); ?>">
                    <label class="radio-inline">
                        <input type="radio" name="screens" value="1"><?php echo e(__('strings.open')); ?>

                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="screens" value="0"><?php echo e(__('strings.room')); ?>

                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="screens" value="2"><?php echo e(__('strings.both')); ?>

                    </label>
                </div>

            </div>

            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                    <label><?php echo e(__('strings.options')); ?> *</label>
                    <div class="checkbox">
                        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label>
                                <input type="checkbox" name="<?php echo e($option->translate('en')->name); ?>"> <?php echo e($option->name); ?>

                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="clearfix"></div>

            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                    <label for="exampleInputEmail1"><?php echo e(__('strings.devices')); ?> *</label>
                    <div class="checkbox">
                        <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label style="display: block;margin-bottom: 10px">
                                <input type="checkbox" name="<?php echo e($device->translate('en')->name); ?>" class="device" > <?php echo e($device->name); ?>

                                <input name="<?php echo e($device->translate('en')->name); ?>_price"
                                       type="text" placeholder="<?php echo e(__('strings.price')); ?>"
                                       style="display: none"
                                       class="price" onkeypress="return allowNumbers(event)"
                                >
                                <div class="clearfix"></div>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>

            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                    <label for="description"><?php echo e(__('strings.description')); ?> *</label>
                    <textarea class="form-control" id="description" placeholder="<?php echo e(__('strings.description')); ?> " name="desc" rows="5"></textarea>
                </div>
                <div class="form-group">
                    <label for="address"><?php echo e(__('strings.address')); ?>*</label>
                    <input type="text" class="form-control" id="address" placeholder="<?php echo e(__('strings.address')); ?>" name="address" value="<?php echo e(old('address')); ?>">
                </div>
            </div>
            <div class="clearfix"></div>


            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group">
                    <label for="image"><?php echo e(__('strings.upload')); ?>  *</label>
                    <div class="reli">
                        <input type="file" id="gallery-photo-add" class="upload-hidden" name="images[]" accept="jpg, gif, png" multiple>
                        <button class="btn btn-default upload" style="color: #999 !important">
                            <?php echo e(__('strings.upload')); ?>

                        </button>
                    </div>
                    <div class="gallery"></div>
                </div>
            </div>



            <div class="col-md-6 col-xs-12 cus-12">
                <div class="form-group map">
                    <label class="control-label"><?php echo e(__('strings.location')); ?> *</label>

                    <input type="text" class="form-control" id="us3-address"/>


                    <div id="us3" style="width: 96%; height: 400px;"></div>

                    <div class="m-t-small">
                        <input type="hidden" class="form-control"  id="us3-lat" name="lat" />

                        <input type="hidden" class="form-control"  id="us3-lon" name="lng" />
                    </div>


                </div>
            </div>


            <div class="col-xs-12 text-center reg">
                <button class="btn btn-default add-stuff" type="submit">
                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">

                    <span>
                                        <?php echo e(__('strings.submit')); ?>

                                    </span>

                    <img src="<?php echo e(url('img/area-border.png')); ?>" class="img-responsive">
                </button>
            </div>
        </form>
    </div>
</div>



<!--Footer-->
<?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--Footer-->

<?php echo $__env->make('front.common.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php echo $__env->make('front.common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    //Location Picker Script


    $('#us3').locationpicker({
        enableAutocomplete: true,
        enableReverseGeocode: true,
        location: {
            latitude: 30.063401,
            longitude: 31.360905
        },
        radius: 0,
        inputBinding: {
            latitudeInput: $('#us3-lat'),
            longitudeInput: $('#us3-lon'),
            radiusInput: $('#us3-radius'),
            locationNameInput: $('#us3-address')
        },
        onchanged: function (currentLocation, radius, isMarkerDropped) {
            var addressComponents = $(this).locationpicker('map').location.addressComponents;
            /*console.log(currentLocation); */ //latlon
            updateControls(addressComponents); //Data
        }
    });


    $(function() {
        // Multiple images preview in browser for add cyber
        var imagesPreview = function(input, placeToInsertImagePreview) {

            if (input.files) {
                var filesAmount = input.files.length;

                for (i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();

                    reader.onload = function(event) {
                        $($.parseHTML('<img>')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
                    }

                    reader.readAsDataURL(input.files[i]);
                }
            }

        };

        $('#gallery-photo-add').on('change', function() {
            imagesPreview(this, 'div.gallery');
        });
    });
</script>

<script>

    if ($('input.device').is(':checked')) {
        $(this).siblings('.price').toggle();
    }

    $('input.device').change(function(){

        $(this).siblings('.price').toggle();

    });
</script>

</body>
</html>
