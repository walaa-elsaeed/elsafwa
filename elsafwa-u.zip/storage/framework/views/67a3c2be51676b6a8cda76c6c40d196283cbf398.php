<script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBl7gZbf_aXumi-xEIr2U6Df9aWqO92fx8&libraries=places">
</script>


<script src="<?php echo e(url('js/front/locationpicker.jquery.min.js')); ?>"></script>

<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 6%">
        <div class="col-md-offset-1 col-md-10 col-xs-12">
            <div class="box box-primary">

                <div class="box-header with-border">
                    <h3 class="box-title">
                        <a href="mailto:<?php echo e($message->email); ?>">
                            <?php echo e($message->email); ?>

                        </a>

                    </h3>
                </div>

                <div class="box-body">
                    <p>
                        <?php echo e($message->message); ?>

                    </p>

                    <p>
                        <h4> Sent At:</h4>
                        <?php echo e($message-> created_at); ?>

                    </p>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>