<?php return array (
  'app' => 
  array (
    'name' => 'Elsafwa',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'timezone' => 'UTC',
    'date_format' => 'Y-m-d',
    'date_format_js' => 'yy-mm-dd',
    'locales' => 
    array (
      0 => 'en',
      1 => 'ar',
    ),
    'fallback_locale' => 'ar',
    'key' => 'base64:30a67osF3NxqFmAygCAhTvMypHMBed4aoawlXiBBEq8=',
    'cipher' => 'AES-256-CBC',
    'log' => 'single',
    'log_level' => 'debug',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Laravel\\Tinker\\TinkerServiceProvider',
      23 => 'Intervention\\Image\\ImageServiceProvider',
      24 => 'Collective\\Html\\HtmlServiceProvider',
      25 => 'App\\Providers\\AppServiceProvider',
      26 => 'App\\Providers\\AuthServiceProvider',
      27 => 'App\\Providers\\EventServiceProvider',
      28 => 'App\\Providers\\RouteServiceProvider',
      29 => 'Spatie\\Permission\\PermissionServiceProvider',
      30 => 'UxWeb\\SweetAlert\\SweetAlertServiceProvider',
      31 => 'Yajra\\DataTables\\DataTablesServiceProvider',
      32 => 'Dimsav\\Translatable\\TranslatableServiceProvider',
      33 => 'Artesaos\\SEOTools\\Providers\\SEOToolsServiceProvider',
      34 => 'Laravel\\Socialite\\SocialiteServiceProvider',
      35 => 'Laravel\\Scout\\ScoutServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Alert' => 'UxWeb\\SweetAlert\\SweetAlert',
      'Datatables' => 'Yajra\\DataTables\\Facades\\DataTables',
      'SEOMeta' => 'Artesaos\\SEOTools\\Facades\\SEOMeta',
      'OpenGraph' => 'Artesaos\\SEOTools\\Facades\\OpenGraph',
      'Twitter' => 'Artesaos\\SEOTools\\Facades\\TwitterCard',
      'Image' => 'Intervention\\Image\\Facades\\Image',
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
      ),
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'D:\\xampp\\htdocs\\elsafwa\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
    ),
    'prefix' => 'laravel',
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'database' => 'elsafwa',
        'prefix' => '',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'elsafwa',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'strict' => false,
        'engine' => NULL,
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'elsafwa',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'default' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 0,
      ),
    ),
  ),
  'datatables' => 
  array (
    'search' => 
    array (
      'smart' => true,
      'multi_term' => true,
      'case_insensitive' => true,
      'use_wildcards' => false,
    ),
    'index_column' => 'DT_Row_Index',
    'engines' => 
    array (
      'eloquent' => 'Yajra\\DataTables\\EloquentDataTable',
      'query' => 'Yajra\\DataTables\\QueryDataTable',
      'collection' => 'Yajra\\DataTables\\CollectionDataTable',
    ),
    'builders' => 
    array (
    ),
    'nulls_last_sql' => '%s %s NULLS LAST',
    'error' => NULL,
    'columns' => 
    array (
      'excess' => 
      array (
        0 => 'rn',
        1 => 'row_num',
      ),
      'escape' => '*',
      'raw' => 
      array (
        0 => 'action',
      ),
      'blacklist' => 
      array (
        0 => 'password',
        1 => 'remember_token',
      ),
      'whitelist' => '*',
    ),
    'json' => 
    array (
      'header' => 
      array (
      ),
      'options' => 0,
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'D:\\xampp\\htdocs\\elsafwa\\storage\\app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'D:\\xampp\\htdocs\\elsafwa\\storage\\app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
      ),
    ),
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'languages' => 
  array (
    'en' => 'En',
    'ar' => 'ع',
  ),
  'mail' => 
  array (
    'driver' => 'smtp',
    'host' => 'smtp.gmail.com',
    'port' => '587',
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Example',
    ),
    'encryption' => 'tls',
    'username' => '',
    'password' => '',
    'sendmail' => '/usr/sbin/sendmail -bs',
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'D:\\xampp\\htdocs\\elsafwa\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'permission' => 
  array (
    'models' => 
    array (
      'permission' => 'Spatie\\Permission\\Models\\Permission',
      'role' => 'Spatie\\Permission\\Models\\Role',
    ),
    'table_names' => 
    array (
      'roles' => 'roles',
      'permissions' => 'permissions',
      'model_has_permissions' => 'model_has_permissions',
      'model_has_roles' => 'model_has_roles',
      'role_has_permissions' => 'role_has_permissions',
    ),
    'cache_expiration_time' => 1440,
    'log_registration_exception' => true,
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => 'your-public-key',
        'secret' => 'your-secret-key',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
      ),
    ),
    'failed' => 
    array (
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'seotools' => 
  array (
    'meta' => 
    array (
      'defaults' => 
      array (
        'title' => 'THE GAME',
        'description' => 'The GAME is the first online platform that serves all the gaming industry elements. A website where gamers can find all what they need to gear-up their gaming experience, build their community, and get rewarded',
        'separator' => ' - ',
        'keywords' => 
        array (
          0 => 'thegame.com',
          1 => 'thegamecom',
          2 => 'thegame',
          3 => 'thegames',
          4 => 'thegamers',
          5 => 'game',
          6 => 'games',
          7 => 'gamers',
          8 => 'gaming',
          9 => 'gaming event',
          10 => 'game event',
          11 => 'game competition',
          12 => 'game tournament',
          13 => 'gaming tournament',
          14 => 'gaming competition',
          15 => 'gaming website',
          16 => 'gaming laptop',
          17 => 'joystick',
          18 => 'gaming association for multimedia entertainment',
          19 => 'gamers community',
          20 => 'Gaming community',
          21 => 'Gaming market',
          22 => 'electronic games',
          23 => 'multimedia games',
          24 => 'gaming association',
          25 => 'multimedia entertainment',
          26 => 'electronic entertainment',
          27 => 'gaming in egypt',
          28 => 'games in egypt',
          29 => 'game egypt',
          30 => 'playstation',
          31 => 'playstation4',
          32 => 'VR egypt',
          33 => 'xbox',
          34 => 'xbox egypt',
          35 => 'PS',
          36 => 'PS 4',
          37 => 'wii',
          38 => 'wii egypt',
          39 => 'cyber',
          40 => 'cybers',
          41 => 'cybercafe',
          42 => 'playstationcafe',
          43 => 'buy sell games',
          44 => 'request games',
          45 => 'gaming market in egypt',
          46 => 'games market in egypt',
          47 => 'cybers in egypt',
          48 => 'gaming spots',
          49 => 'best game spot',
          50 => 'best gaming spot',
          51 => 'best cyber',
          52 => 'games news in egypt',
          53 => 'gaming news in egypt',
          54 => 'trade games',
          55 => 'nintendo switch',
          56 => 'nintendo Wii',
          57 => 'nintendo',
          58 => 'gaming tournament',
          59 => 'fifa tournament',
          60 => 'fanta tournament',
          61 => 'fifa',
          62 => 'ea sports',
          63 => 'call of duty',
          64 => 'activision ',
          65 => 'blizzard',
          66 => 'war craft',
          67 => 'dota',
          68 => 'league of legends ',
          69 => 'Worldcup playstation',
          70 => 'worldcup tournament',
          71 => 'cocacola worldcup',
          72 => 'copa cocacola',
          73 => 'ecopa cocacola',
          74 => 'جيمز ',
          75 => 'العالب اكترونية',
          76 => 'بلاي ستيشن ',
          77 => 'اكس بوكس ',
          78 => 'فيفا',
          79 => 'برو ',
          80 => 'بيس',
          81 => 'دراع ',
          82 => 'لعبة',
          83 => 'جيمر',
          84 => 'جيمرز ',
          85 => 'اخبار الجيمز ',
          86 => 'بطولة بلاي ستيشن ',
          87 => 'ايفينت جيمز',
          88 => 'مجال الجيمز ',
          89 => 'العاب الكترونية في مصر',
          90 => 'بطولة كاس العالم ',
          91 => 'مسابقة كاس العالم فيفا',
          92 => 'فيفا 2018',
          93 => 'بطولة بلاي ستيشن مصر',
          94 => 'مسابقة بلاي ستيشن مصر',
          95 => 'بطولة سايبرات',
          96 => 'بلاي ستيشن كافيه ',
          97 => 'أماكن لعب بلاي ستيشن ',
          98 => 'أماكن لعب كمبيوتر',
          99 => 'سوق الجيمز ',
          100 => 'سوق الألعاب في مصر ',
          101 => 'اخبار الجيمز',
          102 => 'اخبار الألعاب ',
          103 => 'اخبار الألعاب الالكترونية مصر',
          104 => 'تصنيف العاب البلاي ستيشن ',
          105 => 'العاب الكمبيوتر ',
        ),
        'canonical' => NULL,
      ),
      'webmaster_tags' => 
      array (
        'google' => NULL,
        'bing' => NULL,
        'alexa' => NULL,
        'pinterest' => NULL,
        'yandex' => NULL,
      ),
    ),
    'opengraph' => 
    array (
      'defaults' => 
      array (
        'title' => 'THE GAME',
        'description' => 'The GAME is the first online platform that serves all the gaming industry elements. A website where gamers can find all what they need to gear-up their gaming experience, build their community, and get rewarded ',
        'url' => 'http://thegame.com.co',
        'type' => 'website',
        'site_name' => 'THE GAME',
        'images' => 
        array (
          0 => 'http://thegame.com.co/img/logo.png',
          1 => 'http://thegame.com.co/img/2d-final.png',
          2 => 'http://thegame.com.co/img/home/animated-2.jpg',
          3 => 'http://thegame.com.co/img/home/animated-1.jpg',
          4 => 'http://thegame.com.co/img/home/animated-3.jpg',
          5 => '',
        ),
      ),
    ),
    'twitter' => 
    array (
      'defaults' => 
      array (
        'card' => 'THE GAME',
        'site' => '@accountTheGame3laTwitter',
      ),
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
    'stripe' => 
    array (
      'model' => 'App\\User',
      'key' => NULL,
      'secret' => NULL,
    ),
    'facebook' => 
    array (
      'client_id' => '173063836916452',
      'client_secret' => '5c52fbedf3ce716b8c6c3e3ca5917d94',
      'redirect' => 'http://localhost/elsafwa/public/login/facebook/callback',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'D:\\xampp\\htdocs\\elsafwa\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
  ),
  'sweet-alert' => 
  array (
    'autoclose' => 1800,
  ),
  'translatable' => 
  array (
    'locales' => 
    array (
      0 => 'en',
      1 => 'fr',
      'es' => 
      array (
        0 => 'MX',
        1 => 'CO',
      ),
    ),
    'locale_separator' => '-',
    'locale' => NULL,
    'use_fallback' => true,
    'use_property_fallback' => true,
    'fallback_locale' => 'en',
    'translation_suffix' => 'Translation',
    'locale_key' => 'locale',
    'to_array_always_loads_translations' => true,
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'D:\\xampp\\htdocs\\elsafwa\\resources\\views',
    ),
    'compiled' => 'D:\\xampp\\htdocs\\elsafwa\\storage\\framework\\views',
  ),
  0 => 'config/sweet-alert.php',
);
