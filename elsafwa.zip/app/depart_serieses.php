<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class depart_serieses extends Model
{
    public function depart()
    {
        return $this->belongsTo(departs::class);
    }
}
