<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class depart_serie_comments extends Model
{
    public function depart_series()
    {
        return $this->belongsTo(depart_serieses::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
