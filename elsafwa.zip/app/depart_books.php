<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class depart_books extends Model
{
    public function depart()
    {
        return $this->belongsTo(departs::class);
    }
}
