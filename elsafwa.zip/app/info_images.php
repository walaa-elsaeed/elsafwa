<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class info_images extends Model
{
    //
}
